# Developing on fdrs_calcs

## Code of Conduct

This project has adopted the [Contributor Covenant Code of
Conduct](https://www.contributor-covenant.org/version/2/0/code_of_conduct/).

Full details of the code of conduct can be found in link above, but the
following is a summary:

>> All contributors to this project are expected to treat others with respect
>> and to help create a positive environment for everyone. This includes being
>> respectful of differing viewpoints, accepting constructive criticism, and
>> showing empathy towards other community members. Contributors are expected to
>> focus on not only what is best for them individually, but also what is best
>> for the community as a whole.

Instances of abusive, harassing, or otherwise unacceptable behavior may be
reported by contacting the project team at afdrs@rfs.nsw.gov.au.

## Repository Overview

This repository contains code for the calculations for the Australian Fire
Danger Rating System. The code is organized into the following directories:

- `fdrs_calcs`: Python package containing the code for the calculations
    - `calc.py`: The main entry point for the calculations
    - `spread_models`: The main code for the spread models
        - `{model_name}.py`: The code for the *model_name* spread model
        - `fire_behaviour_index.py`: The code for taking the spread model
          outputs and calculating the fire behaviour index
        - `fire_danger_rating.py`: The code for taking the fire behaviour index
          and calculating the fire danger rating
    - `tests`: Unit tests for the code
        - `spread_models`: Unit tests for the spread models
        - `test_data`: Test data containing both input variables and expected
          output
            - `fresh_data`: Freshly generated test data using your code (if
              tests have been run - see below)
            - `generators`: Code for generating the test data
- `docs/_build`: Documentation for the code

## Checking out the code

To check out the code, clone the repository:

```bash
git clone git@gitlab.com:afdrs/fdrs_calcs.git
```

## Setting up a development environment

To set up a development environment, first install the dependencies:

```bash
pip install -r requirements.txt
pip install -r requirements-dev.txt
```

## Code testing

To run the unit tests, run the following command from the root of the
repository:

```bash
pytest --cov
```

As well as running the unit tests, this will also generate a coverage report
showing which lines of code are covered by the tests. We aim to keep the
coverage high, so please ensure that any new code you add is covered by tests.

At present most testing is done as regression tests, where the output of the
code is compared to previously generated output. This is done by comparing the
output to the expected output in the `tests/test_data` directory.

If you need to make a change to the expected output (e.g. because you have
changed the code), a fresh version of the expected output will be generated when
you run the tests. This will be placed in the `tests/test_data/fresh_data`
folder. You can then copy this to the `tests/test_data` folder to replace the
old expected output. This should cause your tests to pass. Having done this, you
should check that the changes match what you expected and commit the change in
expected output to the repository.

## Code documentation

To build the documentation, run the following command from the root of the
repository:

```bash
cd docs
./make html
```

The documentation will be built in the `docs/build/html` directory. To view the
documentation, open the `index.html` file in your browser.

Documentation of functions is in the docstrings of the functions themselves
using the [MyST](https://myst-parser.readthedocs.io/en/latest/) markdown
format. Please ensure that any new functions you add are documented in this
way. You can compare your docstrings to those of existing functions to see how
they should be formatted.

### Updating the documentation structure

If you add new modules, you may need to use `sphinx-apidoc` to update the
documentation structure. To do this, run the following command from the root of
the repository:

```bash
cd docs
sphinx-apidoc -e -o source ../fdrs_calcs
```

You can now rebuild the documentation as described above.

## Code formatting

Please ensure that any new code is consistently formatted to be similar to that
of the existing code. All new code should attempt to keep lines shorter than
80 characters.

## Code review and merge requests

All changes to the codebase will be reviewed by another developer before they
are merged into the main branch. This is to ensure that the code is of a high
quality and that it is consistent with the rest of the codebase. This review
process will be done through a merge request.

To create a merge request:

1. Either checkout the repository or create your own fork of the repository
2. Create a new branch for your changes
3. Make your changes and commit them to your branch
4. Create a merge request from your branch to the main branch of the original
   repository
5. Wait for a code review and approval or feedback from the reviewer
    - If you receive feedback, make the requested changes and commit them to
      your branch
6. Once approved, you will be able to merge your changes into the main branch.
   If you need assistance with this, please contact the maintainers. If you
   haven't done so within a few days, a maintainer may merge your changes for
   you.
    - Merge requests will generally be merged as a squashed commit to keep the
      commit history clean. If you would like to keep the commit history, please
      let the reviewer know.
    - Merge requests will also delete the branch after merging. If you would
      like to keep the branch, please let the reviewer know.

Please ensure that your merge request includes a clear description of the
changes you made and why they are necessary. The code review process will also
ensure that your code is well documented and testing with high coverage, so it
would be advised to ensure that these are done before creating the merge
request.

Feel free to create a merge request even if you are unsure whether your changes
will be accepted. The code review process is intended to be a collaborative
process, so if there are any issues with your changes, the reviewer will work
with you to resolve them. If you don't believe a merge request is ready for
review yet but you want to share your changes with others, you can create a
draft merge request instead.

We expect to be able to start the review process of requests within a few days
of them being created. If you have not received a response within a week, please
contact the maintainers.

## Branching strategy

This project is using both feature and release branches in our branching
strategy. The main branch is the `master` branch and all development should
branch off into feature branches, which will be merged into the `master` branch
when complete. The `master` branch should always be in a working state, but it
may contain changes to the functionality that have not yet been released. 

Releases are done by creating a release branch from the `master` branch. This
branch is then used to make any changes necessary for the release. Once the
release is ready, it is merged into the `master` branch and tagged with the
version number. The release branch is then deleted.

An example of this is shown here, where `v1.0.0` can be seen to have `changex`
and `changey` included in it. `changez` is not included in the release, but is
merged into the `master` branch after the release, and will be included in the
next release.

```mermaid
%%{init: { 'gitGraph': {
    'mainBranchName': 'master',
    'mainBranchOrder': 1,
    'showCommitLabel': false
}}}%%
gitGraph
    commit

    # changex
    branch changex order: 1
    checkout changex
    commit
    commit
    checkout master
    merge changex

    # start release branch with changex
    branch v_1_0 order: 0
    commit

    # changey starts
    checkout master
    branch changey order: 2
    commit

    # changez starts
    checkout master
    branch changez order: 3
    commit

    # changey is finished and merged
    checkout changey
    commit
    checkout master
    merge changey
    checkout v_1_0
    merge master
    commit

    # merge hotfix back into master
    checkout master
    merge v_1_0
    commit tag: "v1.0.0"

    # changez is finished and merged, but not yet released
    checkout changez
    commit
    commit
    checkout master
    merge changez
```