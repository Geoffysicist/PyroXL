# AFDRS -  Fire Weather Output Computation

AFDRS Fire Weather, Fire Behaviour Index, and Fire Danger Rating computation to
provide operational services continuity


## Disclaimer 
This code should be used with caution. The accuracy of calculations will be
impacted by the accuracy of the input data. Potential sources of error in these
calculations could include (but are not limited to): 

* Incorrect or invalid weather observations, 
* Incorrect or invalid fuel observations, 
* Missing or unknown antecedent conditions (e.g. previous rainfall or time since
  fire).


Calculating the AFDRS Fire Behaviour Index can require highly detailed
information about fuel condition, arrangement and load. Users should be aware
that small differences in this information can produce significantly different
calculations of FBI and care should be taken to ensure that the values used are
not only accurate but area also representative of the broader landscape. Please
also be aware that these calculations are not a substitute for official products
of Fire Behaviour Indices and Fire Danger Ratings calculated by the Bureau of
Meteorology. The FDR_Calcs Code is still being developed and tested. Updated
versions of this will be provided at a later date with error corrections or
updated functionality. It is the users responsibility to ensure they have the
most up-to-date version when using the calculator. If you identify a bug or
error in the calculator or its equations please contact the Australian Fire
Danger Rating Team at [afdrs@afac.com.au](afdrs@afac.com.au) 


## Links
You can find out more information about the AFDRS, FBI and other information
through the following links (some of these will require user access):

* [RFS Science Review JIRA Project Agile Board](https://afdrs.atlassian.net/jira/software/c/projects/ASR/boards/11)
* [frds_calcs GitLab Repo Link](https://gitlab.com/nsw_predictive_services/fdrs_calcs)
* [AFAC AFDRS Page](https://www.afac.com.au/initiative/afdrs/)
* [AFDRS Fire Danger Viewer](https://www.fdv.afdrs.org.au/)
* [AFDRS Fuel State Editor](https://www.fse.afdrs.org.au/)

# Table of Contents
1. [Overview](#overview)
2. [Running Locally](#running-locally)
3. [Contributing to the code](#contributing-to-the-code)
4. [How to produce FBI?](#how-to-produce-fbi?)
5. [How to produce FDR?](#how-to-produce-fdr?)
6. [Products/Variables Table](#products/variables-table)
7. [Metadata Table](#metadata-table)
8. [Model Inputs Table](#model-inputs-table)
9. [FBI categories for fire danger ratings](#fbi-categories-for-fire-danger-ratings)

# Overview 

The AFDRS Calcs are a set of functions intended to calculate the Fire Behaviour
Index (FBI) and the Fire Danger Rating (FDR) for the below fuel types
categorised under the 8 Fire Behaviour Models.

No calculations are made for fuel labelled as “unburnable” eg: areas of water,
sand, rock etc. 

Also, no calculations are made for Horticulture as crops have very low
flammability eg: vegetables, herbs and irrigated crops.

<details>
  <summary>Grassland</summary>

  1. Chenopod
  2. Csiro Grassland
  3. Gamba
  4. Grass
  5. Low Wetland
  6. Pasture
</details>

<details>
  <summary>Savanna</summary>

  1. Acacia Woodland
  2. Savanna
  3. Rural
</details>

<details>
  <summary>Spinnifex</summary>

  1. Spinnifex
</details>

<details>
  <summary>Buttongrass</summary>

  1. Buttongrass
</details>  

<details>
  <summary>Mallee Heath</summary>

  1. Mallee Heath
</details>

<details>
  <summary>Heathland (Shrubland)</summary>

  1. Heathland
  2. Wet Heathland
</details>

<details>
  <summary>Pine</summary>

  1. Pine
</details>

<details>
  <summary>Forest</summary>

  1. Dry Forest
  2. Wet Forest
</details>


<details>
  <summary>Non-combustible</summary>

  1. Unburnable
  2. Horticulture
</details>

**NOTE:**
> ⚠️ For more detailed documentation on the fire behaviour models please see either: \
> https://www.afac.com.au/initiative/afdrs/article/afdrs-quick-guides\
> https://www.afac.com.au/initiative/afdrs/article/bom-fire-behaviour-model-guides

# Running Locally

## Requirements

In order to run this locally you must have **Python** installed (python>=3.10).

You will need to install the required packages from `requirements.txt` in order
to run the code.

Install the following packages in your python environment eg.
```shell
> pip install -r requirements.txt
```

**NOTE:**
> ⚠️ To install python and necessary packages/libraries please contact your
> agency's IT department.

## Excecuting calculate_indices() through fdrs_calcs.py

In order to produce the Fire Weather Outputs and FBI/FDR you will need to
execute a script similar to the following. Alternatively, you can call the
individual models scripts. However, this will require a deeper understanding of
both python and the models in this repo:

```python

import pandas as pd
import numpy as np
from pathlib import Path
import re
import sys

# Need to update the location of fdrs_calcs repo path if not in the parent dir
# to import fdrs_calcs functions
CWD = Path().absolute()
FRDS_CALCS_PATH = CWD / "fdrs_calcs"
sys.path.append(str(FRDS_CALCS_PATH))
sys.path.insert(0, str(FRDS_CALCS_PATH))
import fdrs_calcs

# Open the AFDRS Fuel Lookup Table
FLUT = pd.read_csv(
  FRDS_CALCS_PATH / "metadata\IDZ10163_AUS_FSE_fuel_type_table_SFC.csv"
)

# Parse Values into named function variables
fdrs_output = fdrs_calcs.calculate_indicies(temp = np.array([]),
                                windmag10m = np.array([]),
                                rh = np.array([]),
                                td = np.array([]),
                                df = np.array([]),
                                curing = np.array([]),
                                grass_fuel_load = np.array([]),
                                precip = np.array([]),
                                time_since_rain = np.array([]),
                                time_since_fire = np.array([]),
                                ground_moisture = np.array([]),
                                kbdi = np.array([]),
                                sdi = np.array([]),
                                fuel_type = np.array([]),
                                fuel_table = FLUT,
                                hours = np.array([]),
                                months = np.array([]))
```

# Contributing to the code

For more information on contributing to the code, please see the
[CONTRIBUTING.md](CONTRIBUTING.md) file.

# How to produce FBI? 

The Fire Behaviour Index (FBI) is a scale used to predict the potential fire
danger based on the expected rate of fire spread. The FBI is made up of
different categories or steps that are triggered by changes in fire behaviour,
suppression response, or potential impacts. Each category is defined based on
indicative fire behaviour and weather, implications for prescribed burning, fire
suppression and containment, and potential impacts.

The FBI ranges from zero to 100-plus.

Fire agencies use the FBI to inform decisions about the fire danger rating for a
district, along with information about other conditions.

## Calculating the fire behaviour index 

We use mathematical models to predict potential fire behaviour characteristics,
based on weather and fuel information. For example, the models can predict:

* fire intensity
* flame height
* rate of spread
* spotting potential.

**NOTE:**
> ⚠️ For more detailed documentation please see:
> https://www.afac.com.au/initiative/afdrs/article/fire-behaviour-index-technical-guide

# How to produce FDR?

Within the index, there are number ranges (categories). Each category aligns to
a level of the fire danger rating scale. See [FBI categories for fire danger
ratings](#fbi-categories-for-fire-danger-ratings) on this page.

The FBI number for a district will be in one of these categories. This indicates
the fire danger rating for that district.

It also means the fire danger rating reflects expected fire behaviour. This
supports organisations making operational decisions about, for example:

* fire preparedness, including community safety messages and advice
* prescribed burning
* bushfire suppression.

**NOTE:**
> ⚠️ For more detailed documentation please see:
> https://www.afac.com.au/initiative/afdrs/article/fire-behaviour-index-technical-guide

# Products/Variables Table

<details>
  <summary>Click to expand table!</summary>

| Product                   | Variable Name                  | Variable Description                                  | Variable                         | Units              | Temporal Resolution | Product Code | Filename                                                  |
| ------------------------- | ------------------------------ | ----------------------------------------------------- | -------------------------------- | ------------------ | ------------------- | ------------ | --------------------------------------------------------- |
| ADFD Weather Input        | Temperature                    | Temperature (Degrees celcius)                         | T_SFC                            | Deg C              | Hourly              | IDZ71000     | IDZ71000_AUS_T_SFC.nc.gz                                  |
| ADFD Weather Input        | Dew Point Temperature          | Dew Point Temperature (Degrees celcius)               | Td_SFC                           | Deg C              | Hourly              | IDZ71001     | IDZ71001_AUS_Td_SFC.nc.gz                                 |
| ADFD Weather Input        | Wind Speed                     | Wind Magnitude (Max in hour)                          | WindMaxInHourMagKmh_SFC          | Km/H               | Hourly              | IDZ71073     | IDZ71073_AUS_WindMaxInHourMagKmh_SFC.nc.gz                |
| ADFD Weather Input        | Wind Direction                 | Wind direction (e.g SSW)                              | Wind_Dir                         | Deg                | Hourly              | IDZ71089     | IDZ71089_AUS_Wind_Dir.nc.gz                               |
| ADFD Weather Input        | Wind Gust                      | Wind gust (Kilometers per hour)                       | WindGustKmh_SFC                  | Km/H               | Hourly              | IDZ71072     | IDZ71072_AUS_WindGustKmh_SFC.nc.gz                        |
| ADFD Weather Input        | Relative Humidity              | Relative Humidity (percentage)                        | RH_SFC                           | %                  | Hourly              | IDZ71081     | IDZ71081_AUS_RH_SFC.nc.gz                                 |
| ADFD Weather Input        | Precipitation                  | Precipitation                                         | Precip_SFC                       | mm                 | Hourly              | IDZ71004     | IDZ71004_AUS_Precip_SFC.nc.gz                             |
| ADFD Weather Input        | Drought Factor                 | Drought Factor                                        | DF_SFC                           | no units (0-10)    | Hourly              | IDZ71127     | IDZ71127_AUS_DF_SFC.nc.gz                                 |
| ADFD Weather Input        | KBDI                           | Keetch-Byram Drought Index                            | KBDI_SFC                         | no units (0-203.2) | Hourly              | IDZ71147     | IDZ71147_AUS_KBDI_SFC.nc.gz                               |
| ADFD Weather Input        | SDI                            | Mount's Soil Dryness Index                            | SDI_SFC                          | no units (0-203.2) | Hourly              | IDZ71235     | IDZ71235_AUS_SDI_SFC.nc.gz                                |
| ADFD AFDRS Weather Input  | AWRA Upper                     | AWRA Upper Level Soil Moisture 0-10cm                 | awap_upper_soil_moisture_SFC     | %                  | Hourly              | IDZ10145     | IDZ10145_AUS_AFDRS_awap_upper_soil_moisture_SFC.nc.gz     |
| ADFD AFDRS Weather Input  | AWRA Root Zone                 | AWRA Root Zone Soil Moisture 10-100cm                 | awap_root_zone_soil_moisture_SFC | %                  | Hourly              | IDZ10XXX     | IDZ10XXX_AUS_AFDRS_awap_root_zone_soil_moisture_SFC.nc.gz |
| ADFD AFDRS Weather Input  | Time Since Last Rainfall       | Hours since last rainfall                             | time_since_rain_SFC              | hours              | Hourly              | IDZ10XXX     | IDZ10XXX_AUS_AFDRS_time_since_rain_SFC.nc                 |
| ADFD AFDRS Weather Input  | Precip Reanlysis               | Precipitation Reanalysis                              | precip_reanalysis_SFC            | hours              | Hourly              | IDZ10XXX     | IDZ10XXX_AUS_AFDRS_precip_reanalysis_SFC.nc               |
| ADFD AFDRS Weather Input  | C-Haines flag                  | C-Haines flag                                         | chaines_flag_SFC                 | binary             | Hourly              | IDZ10142     | IDZ10142_AUS_AFDRS_chaines_flag_SFC.nc                    |
| ADFD AFDRS Weather Input  | C-Haines 95th Percentile       | C-Haines 95th Percentile                              | chaines_95_SFC                   | percentile         | Hourly              | IDZ10143     | IDZ10143_AUS_AFDRS_chaines_95_SFC.nc                      |
| ADFD AFDRS Weather Input  |                                | Wind Change Danger Index                              | wcdi_SFC                         | no units           | Hourly              | IDZ10146     | IDZ10146_AUS_AFDRS_wcdi_SFC.nc                            |
| ADFD AFDRS Weather Input  |                                | Wind Change Danger Index Flag                         | wcdi_flag_SFC                    | binary             | Hourly              | IDZ10147     | IDZ10147_AUS_AFDRS_wcdi_flag_SFC.nc                       |
| FSE Fuel Inputs           | Grass Curing                   | Grassland curing (percentage)                         | curing_SFC                       | %                  | Daily               | IDZ10148     | IDZ10148_AUS_FSE_curing_SFC.nc.gz                         |
| FSE Fuel Inputs           | Grass Fuel Load                | Grass fuel load (tonnes per hectare)                  | grass_fuel_load_SFC              | t/ha               | Daily               | IDZ10159     | IDZ10159_AUS_FSE_grass_fuel_load_SFC.nc.gz                |
| FSE Fuel Inputs           | Fuel Type                      | AFDRS Main fuel type                                  | fuel_type_SFC                    | no units           | Daily               | IDZ10161     | IDZ10161_AUS_FSE_fuel_type_SFC.nc.gz                      |
| FSE Fuel Inputs           | Grass Fuel Condition           | AFDRS Grassland condition (eatenout, grazed, natural) | grass_condition_SFC              | no units           | Daily               | IDZ10149     | IDZ10149_AUS_FSE_grass_condition_SFC.nc.gz                |
| FSE Fuel Inputs           | Time Since Fire                | Years since last burn/fire                            | time_since_fire_SFC              | years              | Daily               | IDZ10162     | IDZ10162_AUS_FSE_time_since_fire_SFC.nc.gz                |
| AFDRS Fire Weather Output | Fire Danger Rating             | AFDRS Fire Danger Rating                              | fdr_SFC                          | no units           | Hourly              | IDZ10134     | IDZ10134_AUS_AFDRS_fdr_SFC.nc                             |
| AFDRS Fire Weather Output | Fire Behaviour Index           | AFDRS Fire Behaviour Index                            | fbi_SFC                          | no units           | Hourly              | IDZ10135     | IDZ10135_AUS_AFDRS_fbi_SFC.nc                             |
| AFDRS Fire Weather Output | Max Daily Fire Danger Rating   | AFDRS Max Daily Fire Danger Rating                    | max_fdr_SFC                      | no units           | Daily               | IDZ10136     | IDZ10136_AUS_AFDRS_max_fdr_SFC.nc                         |
| AFDRS Fire Weather Output | Max Daily Fire Behaviour Index | AFDRS Max Daily Fire Behaviour Index                  | max_fbi_SFC                      | no units           | Daily               | IDZ10137     | IDZ10137_AUS_AFDRS_max_fbi_SFC.nc                         |
| AFDRS Fire Weather Output | AFDRS Rate of Spread           | AFDRS Rate of Spread                                  | ros_SFC                          | m/hr               | Hourly              | IDZ10138     | IDZ10138_AUS_AFDRS_ros_SFC.nc                             |
| AFDRS Fire Weather Output | AFDRS Intensity                | AFDRS Intensity                                       | intensity_SFC                    | kw                 | Hourly              | IDZ10139     | IDZ10139_AUS_AFDRS_intensity_SFC.nc                       |
| AFDRS Fire Weather Output | AFDRS Flame Height             | AFDRS Flame Height                                    | flame_height_SFC                 | m                  | Hourly              | IDZ10141     | IDZ10141_AUS_AFDRS_flame_height_SFC.nc                    |
| AFDRS Fire Weather Output | AFDRS Spotting Distance        | AFDRS Spotting Distance                               | spotting_distance_SFC            | m                  | Hourly              | IDZ10142     | IDZ10142_AUS_AFDRS_spotting_distance_SFC.nc               |

</details>

**NOTE:**
> ⚠️ For more detailed documentation please see: https://www.afac.com.au/initiative/afdrs/article/bom-product-guides


# Metadata Table

<details>
  <summary>Click to expand table!</summary>

| Product   | Variable Name              | Variable Description                                  | Variable                         | Variable in frds_calcs call | Varible in spread_models | Units           | Required |
| --------- | -------------------------- | ----------------------------------------------------- | -------------------------------- | --------------------------- | ------------------------ | --------------- | -------- |
| Dimension | Time                       | Time in UTC (ns or ms)                                | time                             | N/A                         | N/A                      | utc since epoch | no       |
| Dimension | Latitude                   | Latitude in WGS84                                     | latitude                         | N/A                         | N/A                      | deg             | no       |
| Dimension | Longitude                  | Longitude in WGS84                                    | longitude                        | N/A                         | N/A                      | deg             | no       |
| Input     | Temperature                | Temperature (Degrees celcius)                         | T_SFC                            | temp                        | T_SFC                    | Deg C           | yes      |
| Input     | Dew Point Temperature      | Dew Point Temperature (Degrees celcius)               | Td_SFC                           | td                          | Td_SFC                   | Deg C           | yes      |
| Input     | Wind Speed                 | Wind Magnitude (kmh)                                  | WindMagKmh_10m          | windmag10m                     | WindMagKmh_10m           | Km/H            | yes      |
| Input     | Relative Humidity          | Relative Humidity (percentage)                        | RH_SFC                           | rh                          | RH_SFC                   | %               | yes      |
| Input     | Precipitation              | Precipitation                                         | Precip_SFC                       | precip                      | precipitation            | mm              | yes      |
| Input     | Drought Factor             | Drought Factor (0-10)                                 | DF_SFC                           | df                          | DF_SFC                   | unitless        | yes      |
| Input     | KBDI                       | Keetch-Byram Drought Index (0-203.2)                  | KBDI_SFC                         | kbdi                        | KBDI_SFC                 | mm        | yes      |
| Input     | SDI                        | Mount's Soil Dryness Index (0-203.2)                  | SDI_SFC                          | sdi                         | SDI_SFC                  | mm        | yes      |
| Input     | Months                     | Integer value of month (1-12)                         | months                           | months                      | months                   | unitless        | yes      |
| Input     | Hours                      | Integer value of hour (1-24)                          | hours                            | hours                       | hours                    | unitless        | yes      |
| Input     | AWRA Upper                 | AWRA Upper Level Soil Moisture 0-10cm                 | awap_upper_soil_moisture_SFC     | ground_moisture             | AWAP_uf                  | %               | yes      |
| Input     | AWRA Root Zone             | AWRA Root Zone Soil Moisture 10-100cm                 | awap_root_zone_soil_moisture_SFC | ground_moisture             | AWAP_uf                  | %               | yes      |
| Input     | Time Since Last Rainfall   | Hours since last rainfall                             | time_since_rain_SFC              | time_since_rain             | time_since_rain          | hours           | no       |
| Input     | Grass Curing               | Grassland curing (percentage)                         | curing_SFC                       | curing                      | curing_SFC               | %               | yes      |
| Input     | Grass Fuel Load            | Grass fuel load (tonnes per hectare)                  | grass_fuel_load_SFC              | grass_fuel_load             | GrassFuelLoad_SFC        | t/ha            | yes      |
| Input     | Fuel Type                  | AFDRS Main fuel type                                  | fuel_type_SFC                    | fuel_type                   | N/A                      | unitless        | yes      |
| Input     | Fuel Look Up Table         | AFDRS Fuel Look Up Table CSV                          | FLUT                             | fuel_table                  | N/A                      | unitless        | yes      |
| Input     | Grass Fuel Condition       | AFDRS Grassland condition (eatenout, grazed, natural) | grass_condition_SFC              | grass_condition             | grass_condition          | unitless        | yes      |
| Input     | Time Since Fire            | Years since last burn/fire                            | time_since_fire_SFC              | time_since_fire             | time_since_fire          | years           | yes      |
| Output    | Fire Danger Rating         | AFDRS Fire Danger Rating                              | fdr_SFC                          | rating_1                    | rating_1                 | unitless        | N/A      |
| Output    | Fire Behaviour Index       | AFDRS Fire Behaviour Index                            | fbi_SFC                          | index_1                     | index_1                  | unitless        | N/A      |
| Output    | AFDRS Rate of Spread       | AFDRS Rate of Spread                                  | ros_SFC                          | rate_of_spread              | rate_of_spread           | m/hr            | N/A      |
| Output    | AFDRS Intensity            | AFDRS Intensity                                       | intensity_SFC                    | intensity                   | intensity                | kW/m              | N/A      |
| Output    | AFDRS Flame Height         | AFDRS Flame Height                                    | flame_height_SFC                 | flame_height                | flame_height             | m               | N/A      |
| Output    | AFDRS Spotting Distance    | AFDRS Spotting Distance                               | spotting_distance_SFC            | spotting_distance           | spotting_distance        | m               | N/A      |
| Output    | Fine Fuel Moisture (%)     | Dead/Fine Fuel Moisture (%)                           | ffmc_SFC                         | dead_fuel_moisture          | dead_fuel_moisture       | %               | N/A      |
| Output    | Crown Fire Probability (%) | Crown Fire Probability (%)                            | crown_probability                | crown_probability           | crown_probability        | %               | no       |
| Output    | Spread Probability (%)     | Spread Probability (%)                                | spread_probability               | spread_probability          | spread_probability       | %               | no       |
| Output    | Spread Index               | Spread Index                                          | spread_index                     | spread_index                | spread_index             | unitless        | no       |

</details>


# Model Inputs Table

<details>
  <summary>Click to expand table!</summary>

| Model        | T_SFC    | Td_SFC   | RH_SFC   | WindMaxInHourMagKmh_SFC | Precip_SFC | DF_SFC   | KBDI_SFC | SDI_SFC  | awap_root_zone_soil_moisture_SFC | time_since_rain_SFC | curing_SFC | grass_fuel_load_SFC | grass_condition_SFC | time_since_fire_SFC | hours    | months   |
| ------------ |:--------:|:--------:|:--------:|:-----------------------:|:----------:|:--------:|:--------:|:--------:|:--------------------------------:|:-------------------:|:----------:|:-------------------:|:-------------------:|:-------------------:|:--------:|:--------:|
| Grassland    | &#x2611; |          | &#x2611; | &#x2611;                |            |          |          |          |                                  |                     | &#x2611;   | &#x2611;            | &#x2611;            |                     |          |          |
| Savanna      | &#x2611; |          | &#x2611; | &#x2611;                |            |          |          |          |                                  |                     | &#x2611;   | &#x2611;            | &#x2611;            |                     |          |          |
| Spinifex     | &#x2611; |          | &#x2611; | &#x2611;                |            |          |          |          | &#x2611;                         |                     |            |                     |                     | &#x2611;            |          |          |
| Buttongrass  | &#x2611; | &#x2611; | &#x2611; | &#x2611;                | &#x2611;   |          |          |          |                                  | &#x2611;            |            |                     |                     | &#x2611;            |          |          |
| Mallee Heath | &#x2611; |          | &#x2611; | &#x2611;                | &#x2611;   |          |          |          |                                  | &#x2611;            |            |                     |                     | &#x2611;            | &#x2611; | &#x2611; |
| Heathland (Shrubland)    | &#x2611; |          | &#x2611; | &#x2611;                | &#x2611;   |          |          |          |                                  | &#x2611;            |            |                     |                     | &#x2611;            |          |          |
| Pine         | &#x2611; |          | &#x2611; | &#x2611;                |            | &#x2611; | &#x2611; | &#x2611; |                                  |                     |            |                     |                     | &#x2611;            |          |          |
| Forest       | &#x2611; |          | &#x2611; | &#x2611;                |            | &#x2611; | &#x2611; | &#x2611; |                                  |                     |            |                     |                     | &#x2611;            | &#x2611; | &#x2611; |

</details>

# FBI categories for fire danger ratings

| Index number range (category) | Fire danger rating    | 
| ------------------------------| ----------------------| 
| 0 to 11                       | No rating             |
| 12 to 23                      | Moderate              |
| 24 to 49                      | High                  |
| 50 to 99                      | Extreme               |
| 100-plus                      | Catastrophic          |