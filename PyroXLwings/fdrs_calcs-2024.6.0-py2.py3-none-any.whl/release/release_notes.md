## Release 2024.6.0

Released on 2024-06-27.

This release includes a collection of changes focussed on consolidating the
testing approaches taken to ensure that fdrs_calcs is always producing the
expected results, as well as improvements to the documentation based on the
helpful feedback of many people. Functional improvements have been made to the
pine model to better match the research, and updates to the FBI thresholds for
the spinifex model in consultation with jurisdictions.

More details on these changes are included below.

### Major Changes

- Consolidated testing approaches betweeen `fdrs_calcs.calc` and
  `fdrs_calcs.spread_models` to use the same test cases [Merges !46]. This
  includes:

  - adding type hints to the `fdrs_calcs.spread_models.{model}.calculate`
    functions that allow the dataset variables and fuel parameters used to be
    collected programatically
    
  - added testing data to `fdrs_calcs.tests.test_data.TESTING_VALUES` to allow
    for common testing ranges to be used and retrieved from the same place.

  - fuel parameters are now intended to be passed as dictionaries of scalars,
    though Pandas Series still work.

  - `SPREAD_MODEL_LOOKUP` on `fdrs_calcs.calc` has been renamed to
    `FUEL_FDR_TO_MODEL` to better reflect its purpose. The old name
    (`SPREAD_MODEL_LOOKUP`) is still available but is deprecated and will be
    removed in a future release.
    
  - In addition, `FUEL_FDR_TO_MODEL_NAME` has been added to `fdrs_calcs.calc` to
    allow for the retrieval of the model name and `MODEL_NAME_TO_FUEL_FDRS` has
    been added to allow for the retrieval of the list of fuel FDRs for a given
    model name. 

  - Added a new `fdrs_calcs.calc.get_unique_fuel_parameters_for_model()`
    function to allow for the retrieval of the unique fuel parameter sets for a
    particular model from a fuel lookup table.

  - `fdrs_calc.calc.calculate_indicies` can now return which model was used
    alongside the indices to provide more information on how they were
    calculated.

- The latest fuel type table is no longer distributed with the fdrs_calcs
  library. Please contact the AFDRS team or your local jurisdiction for the
  latest version of the fuel type table, and provide it to the
  `fdrs_calcs.calc.calculate_indicies` function.

- Updated pine wind coefficient calculation to match @rothermel1972, with a
  change in the $B$ coefficient, resulting in a reduction of two danger ratings
  (from 3 - Extreme to 1 - Moderate) in some circumstances [Fixes #17]. Thanks
  to Billy Tan @ NSW RFS for pointing this out.

- The `fdrs_calcs.spread_models.savannah` module has been renamed to `savanna`
  to match the standard spelling of the fuel type. The old module name is still
  available but is deprecated and will be removed in a future release.

- The thresholds used for the interpolation of `rate_of_spread` to `index_1` in
  `fdrs_calcs.spread_models.fire_behaviour_index` have been updated for the
  `spinifex` model. This has generally produced minor reductions in the expected
  FBI output with only increases to moderate ratings. This change is a result of
  consultation with jurisdictions and in reference to @burrows2015 [Fixes #94]

- The `fdrs_calcs.spread_models.spinifex` model now returns a continuous
  spread-index between 0.0 and 1.0 rather than only 0 and 1. To accommodate
  this, the spread-index threshold for an FBI of 0 has been changed from <= 0.0
  to <= 0.5. This will result in no change in the FBI, but allow for access to
  more fine-grained spread-index values. [Fixes #22]

### Minor Changes

- Updated pine flame height calculations with reference to research, with a
  minor change in a coefficient, resulting in a maximum difference of less than
  1 cm in flame height [Fixes #91]

- Documentation fixes based on feedback from Billy Tan, Geoff Goldrick and
  others.

- Made it clear that near-surface fuel heights are in centimetres in the
  documentation.

- Minor changes to the technical guide to be consistent about equation
  numbering and table captions.

- Internal changes to continuous integration pipelines to test documentation
  rendering and save on build time.

- Updated the documentation for Spinifex. Resolves multiple minor issues, 
  including the use of overstory and understory terms in the fuel load and
  fuel cover calculations.    
  
