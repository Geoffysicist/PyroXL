# Changelog

All notable changes to this project will be documented in this file.

This project uses [Calendar Versioning](https://calver.org/) where the version
number is in the format `YYYY.MM.MINOR` where `YYYY` and `MM` are the date of
the release. Initial date-based releases will have the `MINOR` version of 0, but
minor changes may be released with higher `MINOR` versions between major
date-based releases.

## Upcoming Release

These changes are in the current development version, but have not yet been
released.

## Release 2024.6.0

Released on 2024-06-27.

This release includes a collection of changes focussed on consolidating the
testing approaches taken to ensure that fdrs_calcs is always producing the
expected results, as well as improvements to the documentation based on the
helpful feedback of many people. Functional improvements have been made to the
pine model to better match the research, and updates to the FBI thresholds for
the spinifex model in consultation with jurisdictions.

More details on these changes are included below.

### Major Changes

- Consolidated testing approaches betweeen `fdrs_calcs.calc` and
  `fdrs_calcs.spread_models` to use the same test cases [Merges !46]. This
  includes:

  - adding type hints to the `fdrs_calcs.spread_models.{model}.calculate`
    functions that allow the dataset variables and fuel parameters used to be
    collected programatically
    
  - added testing data to `fdrs_calcs.tests.test_data.TESTING_VALUES` to allow
    for common testing ranges to be used and retrieved from the same place.

  - fuel parameters are now intended to be passed as dictionaries of scalars,
    though Pandas Series still work.

  - `SPREAD_MODEL_LOOKUP` on `fdrs_calcs.calc` has been renamed to
    `FUEL_FDR_TO_MODEL` to better reflect its purpose. The old name
    (`SPREAD_MODEL_LOOKUP`) is still available but is deprecated and will be
    removed in a future release.
    
  - In addition, `FUEL_FDR_TO_MODEL_NAME` has been added to `fdrs_calcs.calc` to
    allow for the retrieval of the model name and `MODEL_NAME_TO_FUEL_FDRS` has
    been added to allow for the retrieval of the list of fuel FDRs for a given
    model name. 

  - Added a new `fdrs_calcs.calc.get_unique_fuel_parameters_for_model()`
    function to allow for the retrieval of the unique fuel parameter sets for a
    particular model from a fuel lookup table.

  - `fdrs_calc.calc.calculate_indicies` can now return which model was used
    alongside the indices to provide more information on how they were
    calculated.

- The latest fuel type table is no longer distributed with the fdrs_calcs
  library. Please contact the AFDRS team or your local jurisdiction for the
  latest version of the fuel type table, and provide it to the
  `fdrs_calcs.calc.calculate_indicies` function.

- Updated pine wind coefficient calculation to match @rothermel1972, with a
  change in the $B$ coefficient, resulting in a reduction of two danger ratings
  (from 3 - Extreme to 1 - Moderate) in some circumstances [Fixes #17]. Thanks
  to Billy Tan @ NSW RFS for pointing this out.

- The `fdrs_calcs.spread_models.savannah` module has been renamed to `savanna`
  to match the standard spelling of the fuel type. The old module name is still
  available but is deprecated and will be removed in a future release.

- The thresholds used for the interpolation of `rate_of_spread` to `index_1` in
  `fdrs_calcs.spread_models.fire_behaviour_index` have been updated for the
  `spinifex` model. This has generally produced minor reductions in the expected
  FBI output with only increases to moderate ratings. This change is a result of
  consultation with jurisdictions and in reference to @burrows2015 [Fixes #94]

- The `fdrs_calcs.spread_models.spinifex` model now returns a continuous
  spread-index between 0.0 and 1.0 rather than only 0 and 1. To accommodate
  this, the spread-index threshold for an FBI of 0 has been changed from <= 0.0
  to <= 0.5. This will result in no change in the FBI, but allow for access to
  more fine-grained spread-index values. [Fixes #22]

### Minor Changes

- Updated pine flame height calculations with reference to research, with a
  minor change in a coefficient, resulting in a maximum difference of less than
  1 cm in flame height [Fixes #91]

- Documentation fixes based on feedback from Billy Tan, Geoff Goldrick and
  others.

- Made it clear that near-surface fuel heights are in centimetres in the
  documentation.

- Minor changes to the technical guide to be consistent about equation
  numbering and table captions.

- Internal changes to continuous integration pipelines to test documentation
  rendering and save on build time.

- Updated the documentation for Spinifex. Resolves multiple minor issues, 
  including the use of overstory and understory terms in the fuel load and
  fuel cover calculations.    
  
## Release 2024.2.0

Released on 2024-04-03.

This release has primarily focussed on improving the code quality and
documentation of all models, including a name change for wind speed to
`WindMaxInHourKmh_SFC` to better reflect the data it represents.

It also includes some changes to the behaviour of the grasslands models,
primarily in wind conditions under 5 km/h. Because of the low wind speeds, these
changes only have an impact of lowering the FBI in the affected models by up to
3 point in already low FBI conditions.

More details on these changes are included below.

### Major Changes

- Improvements in code quality and documentation for all models. [Merges !27]

  - For this change, each of the `model.calculate()` functions can still be used
    in the same way, but some lower level model functions have been changed and
    new ones have been added. This should not affect the user unless they are
    using the lower level functions directly.

- Wind speed for each of the `model.calculate()` functions is now taken from the
  *WindMaxInHourKmh_SFC* field instead of the *WindMagKmh_SFC* field. The old
  value will still work but is deprecated, and will be removed in a future
  release. [Fixes #18]
  
  In addition, if you are calling `calc.calculate_indicies()` with wind-speed as
  the second argument, you will not need to change anything, but if you are
  passing it by name, you will need to use `windmaxinhour=...` instead of
  `windmag=...`. In this case, the old name will not work.

- Acacia Woodland, Chenopod, Low Wetland, Woody Horticulture all now explicitly
  use the CSIRO Grassland Eaten-Out model when wind speeds are below 5 km/h
  instead of the Grazed model. [Fixes #4]

- Savanna now explicitly uses the CSIRO Grassland model in eaten-out and below
  5km/h wind conditions instead of the Grazed model. [Fixes #2]

- Rate of Spread for grass-based models in eaten-out conditions below 5 km/h is
  now calculated as half that in grazed conditions, as suggested in @cheney1998.
  In previous releases it was the same as grazed conditions in winds below 5
  km/h. This change affects the Acacia Woodland, Chenopod, Grass, Low Wetland,
  Pasture, Pine, Savanna and Woody Horticulture models. [Fixes #6]

- Rural now explicitly uses the CSIRO Grassland Grazed model in below 5km/h wind
  conditions instead of the Natural model. [Fixes #8]

- Flame height in Grass, Pasture and Savanna models is now calculated from the
  reported grass condition, rather than calculating grass condition from the
  reported fuel load. [Fixes #7]

## Release 2023.12.3

Released on 2024-02-22.

This release contains some documentation updates and improvements in spinifex
for high FBI conditions to match a recent hotfix in the BoM implementation.

### Major Changes

- Updated the Spinifex model so that a FBI of 100 starts at 8,000 m/hr instead
  of 6,000 m/hr and a FBI of 200 is at a rate-of-spread of 20,000 m/hr not 8,000
  m/hr. [Fixes #35]

### Minor Changes

- Updates to documentation to support pdf rendering on Danger Pages.

## Release 2023.12.2

Released on 2024-02-19.

This release updates the documentation and code quality of the fdrs_calcs
library without any changes in functionality.

### Major Changes

- Improvements in code quality and documentation for all models.

  - There are no changes in use of the `model.calculate()` functions, but some
    lower level model functions have been changed and new ones have been added.
    This should not affect the user unless they are using the lower level
    functions directly.

## Release 2023.12.1

Released on 2024-01-12.

### Minor Changes

- Moved document strings to markdown format to help improve the documentation
  and production of the Technical Guide.
- Added `requirements.txt` and `requirements-dev.txt` files to help with
  installation of dependencies.

## Release 2023.12.0

Released on 2023-12-20.

Updated `fdrs_calcs` to match the Bureau of Meteorology's latest
production code, with the following major changes from earlier versions:

### Major changes

- Heathland model changes including new models for ROS and Spread Index.

### Minor changes

- Alignment to BoM production code.
- Improvements in code quality and documentation for the CSIRO-grassland-based
  models (more to come in future releases).
- Regression testing to ensure that changes to the code do not affect the
  results of the models unexpectedly.
