Welcome to fdrs_calcs's documentation!
======================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   apidocs/index

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
