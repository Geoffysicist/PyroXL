r"""
Australian Fire Danger Rating System spread and danger rating algorithms.

## Technical Guide

The AFDRS aims to provide information that is simple and consistent by using
four public rating categories and a numerical fire behaviour index that applies
to all fuels across the entire country. These simple products are built on
considerable complexity in the underlying fire behaviour models, aiming to use
accurate predictions based on a detailed understanding of fire spread and fuel
structure.
"""
try:
    from ._version import __version__
except ModuleNotFoundError:
    __version__ = "unknown"

from . import spread_models
from . import calc
from . import tests
from .calc import calculate_indicies
from .calc import build_local_time_grids
from .calc import update_time_since_fire
