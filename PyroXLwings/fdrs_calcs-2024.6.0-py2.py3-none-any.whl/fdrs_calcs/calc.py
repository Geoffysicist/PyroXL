"""
Copyright Bureau Of Meteorology and NSW Rural Fire Service.

This software is provided under license 'as is', without warranty of any
kind including, but not limited to, fitness for a particular purpose. The
user assumes the entire risk as to the use and performance of the software.
In no event shall the copyright holder be held liable for any claim, damages
or other liability arising from the use of the software.
"""

import os
from collections import defaultdict
from typing import get_type_hints as gth

import numpy as np
import pandas as pd

from .spread_models import (
    grass,
    savanna,
    dry_forest,
    wet_forest,
    spinifex,
    pine,
    buttongrass,
    low_wetland,
    heathland,
    wet_heathland,
    mallee_heath,
    chenopod,
    pasture,
    woody_horticulture,
    rural,
    acacia_woodland,
    unburnable,
    gamba,
)

from .spread_models.csiro_grassland import calc_grass_condition

SECONDSINHOUR = 3600
SECONDSINYEAR = 3600 * 24 * 365.25

FUEL_FDR_TO_MODEL = {
    "Wet_forest": wet_forest,
    "Forest": dry_forest,
    "Heath": heathland,
    "Wet_heath": wet_heathland,
    "Low_wetland": low_wetland,
    "Woodland": savanna,
    "Acacia_woodland": acacia_woodland,
    "Mallee": mallee_heath,
    "Spinifex_woodland": spinifex,
    "Spinifex": spinifex,
    "Chenopod_shrubland": chenopod,
    "Buttongrass": buttongrass,
    "Non_combustible": unburnable,
    "Grass": grass,
    "Gamba": gamba,
    "Pasture": pasture,
    "Woody_horticulture": woody_horticulture,
    "Horticulture": unburnable,
    "Rural": rural,
    "Crop": grass,
    "Pine": pine,
    "Built_up": unburnable,
    "Urban": woody_horticulture,
}
"""Mapping between fuel types (Fuel_FDR in the fuel table) and spread models"""

SPREAD_MODEL_LOOKUP = FUEL_FDR_TO_MODEL
"""Deprecated - use FUEL_FDR_TO_MODEL instead"""

FUEL_FDR_TO_MODEL_NAME = {
    k: v.__name__.split(".")[-1] for k, v in FUEL_FDR_TO_MODEL.items()
}
"""
Mapping between fuel types (Fuel_FDR in the fuel table) and spread model names
"""

MODEL_NAME_TO_FUEL_FDRS = defaultdict(list)
"""
Mapping between spread model names and lists of fuel types (Fuel_FDR in the fuel
table)
"""
for k, v in FUEL_FDR_TO_MODEL_NAME.items():
    MODEL_NAME_TO_FUEL_FDRS[v].append(k)

METADATA_PATH = os.path.join(os.path.dirname(__file__), "metadata")
"""The path to the metadata folder"""

DEFAULT_FUEL_MAP = os.path.join(
    METADATA_PATH, "IDZ10163_AUS_FSE_fuel_type_table_SFC.csv"
)


class FuelTableNotFoundError(FileNotFoundError):
    pass


def load_fuel_map(name=DEFAULT_FUEL_MAP):
    r"""
    Load the fuel map from the metadata folder.

    ### Parameters

    - **name** (*str, optional*) - The name of the fuel map file to load. If not
      provided, the default is 'IDZ10163_AUS_FSE_fuel_type_table_SFC.csv',
      located in METADATA_PATH.

    ### Returns

    - **fuel_map** (*pandas.DataFrame*) - The fuel map
    """
    # raise a special FileNotFoundError if the default fuel map is specified but
    # not found as it is not distributed with the package
    if name == DEFAULT_FUEL_MAP and not os.path.exists(name):
        raise FuelTableNotFoundError(
            f"The default fuel map '{name}' is not distributed with this"
            " package. Please contact the Australian Fire Danger Rating Team"
            " or your local jurisdiction for a copy of the fuel map, and"
            " provide the path using the `name` parameter of the"
            " load_fuel_map function."
        )
    fuel_map = pd.read_csv(
        os.path.join(os.path.dirname(__file__), "metadata", name)
    )
    return fuel_map


def get_unique_fuel_parameters_for_model(model, fuel_map=None):
    """
    Get the variations in fuel parameters for a particular spread model, by
    looking at how they change across the fuel_map.

    Only the variation in the fuel parameters that are used by the spread model
    are returned. Fuel parameters that are not used are ignored.

    ### Parameters

    - **model** (*python module*) - The spread model to get the fuel parameters
        for.
    - **fuel_map** (*pandas.DataFrame, optional*) - The fuel map to use. If not
        provided or None, the default is the fuel map loaded using the
        calc.load_fuel_map function.

    ### Returns

    - **fuel_parameters** (*pandas.DataFrame*) - The unique set of fuel
        parameters for the given spread model across the fuel map, with one row
        for each unique set of fuel parameters. Additionally the Fuel_Names and
        FTno_States covered by each set of fuel parameters are included in the
        output as lists inside the row.
    """

    if fuel_map is None:
        fuel_map = load_fuel_map()

    # get the FuelFDRs covered by our model
    model_name = model.__name__.split(".")[-1]
    FuelFDRs = MODEL_NAME_TO_FUEL_FDRS[model_name]
    fuel_map_subset = fuel_map[fuel_map["Fuel_FDR"].isin(FuelFDRs)]

    # use the FuelFDRs and the fuel_map_subset to find out unique fuel
    # parameters and the FTno_States covered by our model, only looking at fuel
    # parameters that the type hints indicate are used by the model
    fuel_parameters_used = list(gth(gth(model.calculate)["fuel_parameters"]))
    if len(fuel_parameters_used) == 0:
        # if there are no fuel parameters, then just return one row with the
        # list of fuel names and FTno_States in the row
        fuel_parameters = pd.DataFrame(
            [
                {
                    "Fuel_Names": fuel_map_subset["Fuel_Name"].tolist(),
                    "FTno_States": fuel_map_subset["FTno_State"].tolist(),
                }
            ]
        )
    else:
        # otherwise group by the fuel parameters that are used by the spread
        # model and aggregate fuel type information into a list
        fuel_parameters = (
            fuel_map_subset.groupby(fuel_parameters_used)
            .agg(
                Fuel_Names=("Fuel_Name", list), FTno_States=("FTno_State", list)
            )
            .reset_index()
        )

    # return the fuel parameters
    return fuel_parameters


def merge_drought_index(kbdi, sdi, fuel_map_grid):
    r"""
    Merge the KBDI and SDI drought indices into a single drought index, where
    Tasmania uses SDI, but the rest of the country uses KBDI.

    This is done assuming that fuel_map_grid values between 7000 and 7999 are
    in Tasmania.

    ### Parameters

    - **kbdi** (*array_like*) - The Keetch-Byram Drought Index (0-203.2, mm)
    - **sdi** (*array_like*) - Mount's Soil Dryness Index (0-203.2, mm)
    - **fuel_map_grid** (*array_like*) - The fuel map grid, containing the
        FTno_State values for each grid point

    ### Returns

    - **merged** (*array_like*) - The merged drought index, where Tasmanian
      FTno_States use the SDI, and the rest use the KBDI
    """
    merged = np.full_like(kbdi, np.nan)
    # get the Tasmania mask
    mask = (fuel_map_grid >= 7000) & (fuel_map_grid < 8000)
    # if we have any Tasmanian values, use the sdi
    if np.any(mask):
        merged[mask] = sdi[mask]
    # if we have any non-Tasmanian values, use the kbdi
    if np.any(~mask):
        merged[~mask] = kbdi[~mask]
    # return the merged array
    return merged


def calculate_indicies(
    temp,
    windmag10m,
    rh,
    td,
    df,
    curing,
    grass_fuel_load,
    precip,
    time_since_rain,
    time_since_fire,
    ground_moisture,
    kbdi,
    sdi,
    fuel_type,
    fuel_table,
    hours,
    months,
    grass_condition=None,
    return_model=False,
):
    """Calculate the fire danger indices for a given set of inputs.

    See the metadata table in README.md for more details on the inputs and
    outputs.

    Parameters
    ----------
    temp : array_like
        Temperature (Degrees celcius)
    windmag10m : array_like
        Wind magnitude at 10m (km/h)
    rh : array_like
        Relative Humidity (%)
    td : array_like
        Dew Point Temperature (Degrees celcius)
    df : array_like
        Drought Factor (0-10, unitless)
    curing : array_like
        Grassland Curing (%)
    grass_fuel_load : array_like
        Grass Fuel Load (tonnes/ha)
    precip : array_like
        Precipitation (mm)
    time_since_rain : array_like
        Hours since last rainfall
    time_since_fire : array_like
        Years since last burn/fire
    ground_moisture : array_like
        AWRA Upper Level Soil Moisture 0-10cm (%)
    kbdi : array_like
        Keetch-Byram Drought Index (0-203.2, mm)
    sdi : array_like
        Mount's Soil Dryness Index (0-203.2, mm)
    fuel_type : array_like
        AFDRS Main fuel type (`FTno_State` in the fuel table)
    fuel_table : pandas.DataFrame
        AFDRS Fuel Table (load from metadata/fuel-type-models.csv)
    hours : array_like
        Integer value of hour (1-24)
    months : array_like
        Integer value of month (1-12)
    grass_condition : array_like, optional
        Grass condition (3-1, corresponding to natural, grazed, eaten out). Will
        be calculated from grass_fuel_load if not provided.
    return_model : bool, optional
        Whether to return the model used for each grid point. Default is False.

    Returns
    -------
    output : dict
        A dictionary of *array_like* fire danger indices of the same shape as
        the inputs, with the following keys

        - **dead_fuel_moisture** : Dead/Fine Fuel Moisture (%)
        - **rate_of_spread** : Rate of Spread (m/hr)
        - **crown_probability** : Crown Fire Probability (%)
        - **spread_probability** : Spread Probability (%)
        - **spread_index** : Spread Index (unitless)
        - **flame_height** : AFDRS Flame Height (m)
        - **intensity** : AFDRS Intensity (kW/m)
        - **spotting_distance** : AFDRS Spotting Distance (m)
        - **rating_1** : AFDRS Fire Danger Rating (unitless)
        - **index_1** : AFDRS Fire Behaviour Index (unitless)
        - **model** : *str* - The model used for each grid point (if
          return_model is True)
    """

    contract = [
        "dead_fuel_moisture",
        "rate_of_spread",
        "crown_probability",
        "spread_probability",
        "spread_index",
        "flame_height",
        "intensity",
        "spotting_distance",
        "rating_1",
        "index_1",
    ]

    dataset = dict(
        AWAP_uf=ground_moisture,
        KBDI_SFC=kbdi,
        SDI_SFC=sdi,
        drought_index=merge_drought_index(kbdi, sdi, fuel_type),
        Curing_SFC=curing,
        DF_SFC=df,
        GrassFuelLoad_SFC=grass_fuel_load,
        RH_SFC=rh,
        T_SFC=temp,
        Td_SFC=td,
        WindMagKmh_10m=windmag10m,
        hours=hours,
        months=months,
        precipitation=precip,
        time_since_fire=time_since_fire,
        time_since_rain=time_since_rain,
    )

    if grass_condition is None:
        dataset["grass_condition"] = calc_grass_condition(
            dataset["GrassFuelLoad_SFC"]
        )
    else:
        dataset["grass_condition"] = grass_condition

    # setup outputs for each field the same size as the temperature array
    outputs = {x: np.full(temp.shape, np.nan) for x in contract}

    if return_model:
        outputs["model"] = np.full(temp.shape, "", dtype=object)

    int_grid = fuel_type.astype(int)

    for _, fuel_parameters in fuel_table.iterrows():
        # calculate the mask for this fuel type
        mask = int_grid == int(fuel_parameters["FTno_State"])
        # repeat the mask for the extra dimension if needed
        if temp.ndim - int_grid.ndim == 1:
            mask = np.repeat(mask[..., np.newaxis], temp.shape[-1], axis=-1)
        elif temp.ndim != int_grid.ndim:
            raise ValueError(
                "The fuel type grid must have the same number of dimensions"
                " as the data grids or one less"
            )
        if mask.any():
            reduced_dataset = dict()
            for k, v in dataset.items():
                try:
                    reduced_dataset[k] = v[mask]
                except Exception as e:
                    print(f"Size mismatch with data {k}")
                    raise e

            # calculate the outputs for the reduced dataset using the
            # appropriate model, passing in the fuel parameters from the fuel
            # table
            fire_model = fuel_parameters["Fuel_FDR"]
            try:
                reduced_output = FUEL_FDR_TO_MODEL[fire_model].calculate(
                    reduced_dataset, fuel_parameters
                )
            except Exception as e:
                print(
                    f"Running column entry {fuel_parameters['FTno_State']}"
                    f" with model {fire_model}"
                )
                print(f"Inputs {reduced_dataset}")
                raise e
            for param in contract:
                if param in reduced_output:
                    outputs[param][mask] = reduced_output[param]
            if return_model:
                outputs["model"][mask] = FUEL_FDR_TO_MODEL[
                    fire_model
                ].__name__.split(".")[-1]

    return outputs


def build_local_time_grids(utc_forecast_times, tz_grid):
    """Build a country wide grid for local hours."""

    final_shape = utc_forecast_times.shape + tz_grid.shape
    hours = np.broadcast_to(utc_forecast_times.hour, np.flip(final_shape, 0)).T
    hours = (np.broadcast_to(tz_grid, final_shape) + hours) % 24

    months = np.broadcast_to(
        utc_forecast_times.month.values, np.flip(final_shape, axis=0)
    ).T
    months = np.where(np.isnan(tz_grid), np.nan, months)

    return months, hours


def update_time_since_fire(tsf_grid, tsf_grid_time, calculation_time):
    """Adjust the time since fire grids to reflect the current time of calculation."""

    time_since_production = (
        pd.to_datetime(calculation_time) - pd.to_datetime(tsf_grid_time)
    ).total_seconds()
    tsf = tsf_grid + time_since_production // SECONDSINYEAR
    return tsf
