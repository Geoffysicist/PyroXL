r"""
Typing information for the spread models

This module contains type hints for the input variables, fuel parameters, and
output indices of the spread models. The type hints are used to define the input
and output variables of the spread models, for use in type checking and testing.
"""

from typing import TypedDict, Annotated, TypeVar
from dataclasses import dataclass
import numpy as np
from numpy.typing import NDArray


@dataclass
class Bounds:
    r"""
    Lower and upper expected bounds for a variable
    """

    lower: float
    upper: float


T = TypeVar("T", np.float64, np.int_)
# alias Variable to array of type T
InputVariableArray = NDArray[T]

# Type hints for input variables
T_SFC_Array = Annotated[InputVariableArray[np.float64], Bounds(-5, 50)]
"""Surface Temperature (°C)"""

RH_SFC_Array = Annotated[InputVariableArray[np.float64], Bounds(0, 100)]
"""Surface Relative Humidity (%)"""

WindMagKmh_10m_Array = Annotated[InputVariableArray[np.float64], Bounds(0, 300)]
"""Maximum 10 m wind speed in hour (km/h)"""

Curing_SFC_Array = Annotated[InputVariableArray[np.float64], Bounds(0, 100)]
"""Fuel curing (%)"""

GrassFuelLoad_SFC_Array = Annotated[
    InputVariableArray[np.float64], Bounds(0, 10)
]
"""Surface grass fuel load (tonnes/ha)"""

grass_condition_Array = Annotated[InputVariableArray[np.int_], Bounds(1, 3)]
"""Grass condition (3-1, corresponding to natural, grazed, eaten out)"""

precipitation_Array = Annotated[InputVariableArray[np.float64], Bounds(0, 50)]
"""Precipitation in the last 48 hours (mm)"""

time_since_rain_Array = Annotated[InputVariableArray[np.int_], Bounds(0, 100)]
"""Time since the last rain event (days)"""

Td_SFC_Array = Annotated[InputVariableArray[np.float64], Bounds(-20, 25)]
"""Surface dew point temperature (°C)"""

time_since_fire_Array = Annotated[InputVariableArray[np.int_], Bounds(1, 25)]
"""Time since the last fire event (years)"""

DF_SFC_Array = Annotated[InputVariableArray[np.float64], Bounds(0, 10)]
"""Drought factor (0-10, unitless)"""

drought_index_Array = Annotated[
    InputVariableArray[np.float64], Bounds(0, 203.2)
]
"""Drought index - either SDI or KBDI (0-203.2, mm)"""

AWAP_uf_Array = Annotated[InputVariableArray[np.float64], Bounds(0, 100)]
"""Relative soil moisture content (%)"""

months_Array = Annotated[InputVariableArray[np.int_], Bounds(1, 12)]
"""Month of the year (1-12)"""

hours_Array = Annotated[InputVariableArray[np.int_], Bounds(0, 23)]
"""Hour of the day (0-23)"""

# (Common) type hints for fuel parameters

# Most type hints for fuel parameters are specific to each spread model (or
# groups of spread models) and are defined in the spread model files themselves

FL_total_Value = float
"""Total fuel load (kg/m^2)"""

FTno_FDR_Value = int
r"""Fuel type number for the FDR system"""

# Type hints for output indices
dead_fuel_moisture_Array = InputVariableArray[np.float64]
rate_of_spread_Array = InputVariableArray[np.float64]
flame_height_Array = InputVariableArray[np.float64]
intensity_Array = InputVariableArray[np.float64]
spotting_distance_Array = InputVariableArray[np.float64]
rating_1_Array = InputVariableArray[np.int_]
index_1_Array = Annotated[InputVariableArray[np.int_], Bounds(0, 4)]


class CommonInputVariables(TypedDict):
    r"""
    Type hint for the input variables shared between spread models
    """

    T_SFC: T_SFC_Array
    RH_SFC: RH_SFC_Array
    WindMagKmh_10m: WindMagKmh_10m_Array


class NoFuelParameters(TypedDict):
    r"""
    Type hint for spread models that take fuel parameters but don't use any
    """

    pass


class CommonOutputIndices(TypedDict):
    r"""
    Type hint for the output indices shared between spread models
    """

    dead_fuel_moisture: dead_fuel_moisture_Array
    rate_of_spread: rate_of_spread_Array
    flame_height: flame_height_Array
    intensity: intensity_Array
    spotting_distance: spotting_distance_Array
    rating_1: rating_1_Array
    index_1: index_1_Array
