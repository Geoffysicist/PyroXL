import os

# we need to import netCDF before numpy or xarray to avoid a bug: see
# https://github.com/pydata/xarray/issues/7259
import netCDF4

import xarray as xr
import numpy as np
import pytest
from unittest.mock import patch
from .. import calc


@pytest.fixture
def input_dataset():
    # test data can be regenerated from the test_data/generators folder
    module_path = os.path.dirname(__file__)
    return xr.load_dataset(
        os.path.join(module_path, "test_data/calc_data_input.nc")
    )


@pytest.fixture
def expected_output(calculate_grass_condition):
    # test data can be regenerated from the test_data/generators folder
    module_path = os.path.dirname(__file__)
    if calculate_grass_condition:
        filename = "calc_data_output_calc_grass_condition.nc"
    else:
        filename = "calc_data_output_with_grass_condition.nc"
    return xr.load_dataset(os.path.join(module_path, "test_data", filename))


@pytest.fixture
def fuel_map():
    r"""
    Fixture to load the fuel map from the metadata folder

    The fuel map defines the mappings between fuel types and spread models,
    including any fuel parameters that are required by the spread models
    """
    return calc.load_fuel_map()


@patch("os.path.exists", return_value=False)
def test_load_fuel_map_default_file_not_found(mock_exists):
    r"""
    Test that the load_fuel_map function raises a FuelTableNotFoundError with
    information if the default fuel map file is not found.

    This test mocks the os.path.exists function to return False, so that the
    fuel map file is not found.
    """
    # check that the FuelTableNotFoundError is raised for the default fuel map
    with pytest.raises(calc.FuelTableNotFoundError):
        calc.load_fuel_map()

    # check that the mocked os.path.exists function was called with the default
    # fuel map file
    mock_exists.assert_called_with(calc.DEFAULT_FUEL_MAP)


def test_load_fuel_map_file_not_found():
    r"""
    Test that the load_fuel_map function raises a FileNotFoundError with
    information if a specified fuel map file is not found.

    For testing the default fuel map is missing, see the
    test_load_default_fuel_map_file_not_found function instead
    """
    # if we look for a non-existant file, it should only raise a
    # FileNotFound error
    with pytest.raises(FileNotFoundError):
        calc.load_fuel_map("nonexistant_file.csv")


@pytest.mark.parametrize(
    "calculate_grass_condition",
    [True, False],
    ids=["calc_grass_cond", "no_calc_grass_cond"],
)
@pytest.mark.parametrize(
    "return_model", [True, False], ids=["return_model", "no_return_model"]
)
def test_calculate_indicies(
    input_dataset,
    expected_output,
    fuel_map,
    calculate_grass_condition,
    return_model,
):
    """
    Test that the calculate_indicies function returns the expected output.
    """
    # set the grass condition to None if we are not calculating it
    if calculate_grass_condition:
        grass_condition = None
    else:
        grass_condition = input_dataset.grass_condition.values

    # generate the actual output
    actual_output = calc.calculate_indicies(
        temp=input_dataset.T_SFC.values,
        windmag10m=input_dataset.WindMagKmh_10m.values,
        rh=input_dataset.RH_SFC.values,
        td=input_dataset.Td_SFC.values,
        df=input_dataset.DF_SFC.values,
        curing=input_dataset.Curing_SFC.values,
        grass_fuel_load=input_dataset.GrassFuelLoad_SFC.values,
        precip=input_dataset.precipitation.values,
        time_since_fire=input_dataset.time_since_fire.values,
        time_since_rain=input_dataset.time_since_rain.values,
        ground_moisture=input_dataset.AWAP_uf.values,
        kbdi=input_dataset.KBDI_SFC.values,
        sdi=input_dataset.SDI_SFC.values,
        fuel_type=input_dataset.FTno_State.values,
        fuel_table=fuel_map,
        hours=input_dataset.hours.values,
        months=input_dataset.months.values,
        grass_condition=grass_condition,
        return_model=return_model,
    )

    if return_model:
        # check that the models returned match fdrs_calcs spread models

        # get unique models from the actual output
        unique_output_models = np.unique(actual_output["model"])
        # get actual models from the spread model lookup
        actual_models = calc.MODEL_NAME_TO_FUEL_FDRS.keys()
        # check that the unique models are in the actual models
        assert set(unique_output_models).issubset(actual_models)

        # check that the models are chosen appropriately for the fuel type
        for model in unique_output_models:
            # get the Fuel_FDRs for the model
            Fuel_FDRs = calc.MODEL_NAME_TO_FUEL_FDRS[model]
            # get the FTNo_States for that Fuel_FDR from the fuel map
            FTNo_States = fuel_map.loc[
                fuel_map.Fuel_FDR.isin(Fuel_FDRs)
            ].FTno_State
            # and check that the input data was from one of those FTNo_States
            mask = actual_output["model"] == model
            input_FTNo_States = np.unique(input_dataset.FTno_State.values[mask])
            assert set(input_FTNo_States).issubset(FTNo_States)

    # and compare it to the expected output on a field-by-field basis
    for field in actual_output:
        if return_model and field == "model":
            # the model field has to match strings exactly
            np.testing.assert_array_equal(
                actual_output[field],
                expected_output[field],
            )
        else:
            # all other fields can be within a close numerical tolerance
            np.testing.assert_allclose(
                actual_output[field],
                expected_output[field],
            )

    # remove the model field from the expected output if we are not returning it
    expected_keys = set(expected_output.data_vars)
    if not return_model:
        expected_keys.remove("model")

    # check that the actual output has the same fields as the expected output
    assert set(actual_output.keys()) == expected_keys


def test_calculate_indicies_with_time_dimension(input_dataset, fuel_map):
    """
    Test that the calculate_indicies function returns the expected output
    when the input data has a time dimension.
    """
    # use the input dataset to generate a 3d dataset of dimension (x, y, t)
    input_dataset_t = {}
    old_width, old_height = input_dataset.sizes["x"], input_dataset.sizes["y"]
    assert old_width % 2 == 0 and old_height % 2 == 0
    new_width, new_height = old_width // 2, old_height // 2
    new_times = 4
    for var in input_dataset.data_vars:
        input_dataset_t[var] = input_dataset[var].values.reshape(
            new_width, new_height, new_times
        )

    # we only want the first FTno_State
    input_dataset_t["FTno_State"] = input_dataset_t["FTno_State"][:, :, 0]

    # check that the FTno_State is only 2 dimensional now
    assert input_dataset_t["FTno_State"].ndim == 2
    assert input_dataset_t["FTno_State"].shape == (new_width, new_height)

    # but that the rest of the variables are still 3 dimensional
    for k, v in input_dataset_t.items():
        if k != "FTno_State":
            assert v.ndim == 3
            assert v.shape == (new_width, new_height, new_times)

    # generate the actual 3d output
    actual_output_3d = calc.calculate_indicies(
        temp=input_dataset_t["T_SFC"],
        windmag10m=input_dataset_t["WindMagKmh_10m"],
        rh=input_dataset_t["RH_SFC"],
        td=input_dataset_t["Td_SFC"],
        df=input_dataset_t["DF_SFC"],
        curing=input_dataset_t["Curing_SFC"],
        grass_fuel_load=input_dataset_t["GrassFuelLoad_SFC"],
        precip=input_dataset_t["precipitation"],
        time_since_fire=input_dataset_t["time_since_fire"],
        time_since_rain=input_dataset_t["time_since_rain"],
        ground_moisture=input_dataset_t["AWAP_uf"],
        kbdi=input_dataset_t["KBDI_SFC"],
        sdi=input_dataset_t["SDI_SFC"],
        fuel_type=input_dataset_t["FTno_State"],
        fuel_table=fuel_map,
        hours=input_dataset_t["hours"],
        months=input_dataset_t["months"],
    )

    # check that the output is 3 dimensional with the expected shape
    for field in actual_output_3d:
        assert actual_output_3d[field].ndim == 3
        assert actual_output_3d[field].shape == (
            new_width,
            new_height,
            new_times,
        )

    # take slices along the time dimension and compare the 2d output to the 3d
    # output
    for t in range(new_times):
        actual_output_2d = calc.calculate_indicies(
            temp=input_dataset_t["T_SFC"][:, :, t],
            windmag10m=input_dataset_t["WindMagKmh_10m"][:, :, t],
            rh=input_dataset_t["RH_SFC"][:, :, t],
            td=input_dataset_t["Td_SFC"][:, :, t],
            df=input_dataset_t["DF_SFC"][:, :, t],
            curing=input_dataset_t["Curing_SFC"][:, :, t],
            grass_fuel_load=input_dataset_t["GrassFuelLoad_SFC"][:, :, t],
            precip=input_dataset_t["precipitation"][:, :, t],
            time_since_fire=input_dataset_t["time_since_fire"][:, :, t],
            time_since_rain=input_dataset_t["time_since_rain"][:, :, t],
            ground_moisture=input_dataset_t["AWAP_uf"][:, :, t],
            kbdi=input_dataset_t["KBDI_SFC"][:, :, t],
            sdi=input_dataset_t["SDI_SFC"][:, :, t],
            fuel_type=input_dataset_t["FTno_State"],
            fuel_table=fuel_map,
            hours=input_dataset_t["hours"][:, :, t],
            months=input_dataset_t["months"][:, :, t],
        )

        # compare the 2d output to the appropriate slice of the 3d output
        for field in actual_output_2d:
            np.testing.assert_allclose(
                actual_output_2d[field],
                actual_output_3d[field][:, :, t],
            )
