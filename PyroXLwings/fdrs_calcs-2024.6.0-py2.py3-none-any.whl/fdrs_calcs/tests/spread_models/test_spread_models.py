from typing import get_type_hints as gth

import pytest
import numpy as np
import pandas as pd

from ... import calc
from ... import spread_models

# get fixtures for where the testing data is stored from the test_calc tests
from ..test_calc import input_dataset, expected_output, fuel_map

MODELS_TO_TEST = list(set(calc.FUEL_FDR_TO_MODEL.values()))
MODELS_TO_TEST_IDS = [m.__name__.split(".")[-1] for m in MODELS_TO_TEST]


@pytest.fixture
def calculate_grass_condition():
    r"""
    Fixture to determine which expected output to use from test_calc.

    For these tests, we will use the reported grass conditions, as it may allow
    us to catch discrepancies where the grass condition does not match the grass
    loads.
    """
    return False


@pytest.fixture
def model_fuel_parameters(model, fuel_map):
    r"""
    Fixture to filter the fuel_parameters needed for the input_dataset based on
    the model. See the calc.get_unique_fuel_parameters_for_model function for
    more details.
    """
    return calc.get_unique_fuel_parameters_for_model(model, fuel_map)


@pytest.fixture
def model_variables(model, input_dataset, model_fuel_parameters):
    r"""
    Fixture to filter the variables in the input_dataset based on the model
    """
    # explode the FTno_States in the model_fuel_parameters to get a list of all
    # the FTno_States covered by our model
    FTno_States = model_fuel_parameters["FTno_States"].explode().unique()

    # then use the FTno_States to filter the input_dataset
    mask = input_dataset["FTno_State"].isin(FTno_States)

    # Return the output as a dictionary of one dimensional arrays, only
    # collecting the variables that the type hints indicate are used by the
    # model (and FTno_State which is needed to determine the fuel parameters)
    fields = list(gth(gth(model.calculate)["dataset"]).keys()) + ["FTno_State"]
    variables = {f: input_dataset[f].values[mask] for f in fields}

    return variables


@pytest.fixture
def model_expected_output(model, expected_output):
    r"""
    Fixture to filter the expected_output based on the model
    """
    # get the expected outputs covered by our model
    model_name = model.__name__.split(".")[-1]
    mask = expected_output["model"] == model_name

    # Return the output as a dictionary of one dimensional arrays, only
    # collecting the variables that the type hints indicate are returned by the
    # model
    fields = list(gth(gth(model.calculate)["return"]).keys())
    expected_output = {f: expected_output[f].values[mask] for f in fields}

    return expected_output


def _get_calculate_input_and_expected_output(
    model_variables,
    model_fuel_parameters_row,
    model_expected_output,
    truncate=None,
):
    r"""
    Helper function to get the input and expected output for the calculate
    function, based on the model_variables, a row of the model_fuel_parameters
    table, and model_expected_output

    ### Parameters

    - **model_variables** (*dict*) - The variables to use as input to the
        calculate function, over all the FTno_States covered by the model.
    - **model_fuel_parameters_row** (*pandas.Series*) - A single row (as a
        Pandas Series of the model_fuel_parameters DataFrame), containing the
        fuel parameters and the FTno_States that use those fuel parameters.
    - **model_expected_output** (*dict*) - The expected output of the calculate
        function, over all the FTno_States covered by the model.
    - **truncate** (*int*) - If not None, truncate the input and expected output
        to this length.

    ### Returns

    - **dataset** (*dict*) - The input to the calculate function, filtered to
        only include the FTno_States in the fuel parameter row.
    - **fuel_parameters** (*dict*) - The fuel parameters to use as input to the
        calculate function, as provided by the model_fuel_parameters_row.
    - **expected_output** (*dict*) - The expected output of the calculate
        function, filtered to only include the FTno_States in the fuel parameter
        row.
    """
    # just use the first set of fuel parameters, as we are mostly interested in
    # getting the same output for both the dictionary and series
    fuel_parameters = model_fuel_parameters_row.to_dict()

    # remove the FTno_States from the fuel parameters, but keep for filtering
    # the model variables
    FTno_States = fuel_parameters.pop("FTno_States")

    # get a mask based on the FTno_States
    mask = np.isin(model_variables["FTno_State"], FTno_States)

    # if we are not truncating or the truncation is greater than the number of
    # rows in the mask, then set the truncation to the number of rows in the
    # mask
    if truncate is None or truncate > mask.sum():
        truncate = mask.sum()

    # filter the test data input based on the mask, truncating as needed
    dataset = {k: v[mask][:truncate] for k, v in model_variables.items()}

    # filter the expected output based on the mask, truncating as needed
    expected_output = {
        k: v[mask][:truncate] for k, v in model_expected_output.items()
    }

    return dataset, fuel_parameters, expected_output


@pytest.mark.parametrize("model", MODELS_TO_TEST, ids=MODELS_TO_TEST_IDS)
def test_calculate(
    model, model_variables, model_fuel_parameters, model_expected_output
):
    r"""
    Test that the calculate function returns the expected output.
    """
    # first check that the length of the arrays in both model variables and
    # expected output are all the same
    data_lengths = set(
        [len(v) for v in model_variables.values()]
        + [len(v) for v in model_expected_output.values()]
    )
    assert len(data_lengths) == 1
    print(f"Length of data: {data_lengths.pop()}")

    # for each unique set of fuel parameters, calculate the actual output and
    # compare it to the expected output
    for _, row in model_fuel_parameters.iterrows():
        # get the input and expected output for the calculate function
        dataset, fuel_parameters, expected_output = (
            _get_calculate_input_and_expected_output(
                model_variables, row, model_expected_output
            )
        )

        # run calculate and compare to expected output
        actual_output = model.calculate(dataset, fuel_parameters)

        # compare actual and expected output array by array
        for fields in expected_output.keys():
            np.testing.assert_allclose(
                actual_output[fields], expected_output[fields]
            )

        # check that no extra columns are included
        assert len(actual_output) == len(expected_output)


@pytest.mark.parametrize("model", MODELS_TO_TEST, ids=MODELS_TO_TEST_IDS)
@pytest.mark.parametrize(
    "old_wind_name", ["WindMagKmh_SFC", "WindMaxInHourKmh_SFC"]
)
def test_calculate_windmag_warning(
    model,
    old_wind_name,
    model_variables,
    model_fuel_parameters,
    model_expected_output,
):
    r"""
    Test that the calculate warns when using the deprecated `old_wind_name`, but
    otherwise returns the same results as if WindMagKmh_10m was passed in.
    """
    # just use the first 10 rows of the first set of fuel parameters, as we are
    # mostly interested in getting the deprecation warning, and we don't need to
    # test a large volume of the actual results
    dataset, fuel_parameters, expected_output = (
        _get_calculate_input_and_expected_output(
            model_variables,
            model_fuel_parameters.iloc[0],
            model_expected_output,
            truncate=10,
        )
    )

    # rename the WindMagKmh_10m to the deprecated old_wind_name
    dataset[old_wind_name] = dataset.pop("WindMagKmh_10m")

    # run calculate, and test that we get a depreciation warning
    with pytest.warns(DeprecationWarning):
        output = model.calculate(dataset, fuel_parameters)

    # check that the output is the same as before
    for fields in expected_output.keys():
        np.testing.assert_allclose(output[fields], expected_output[fields])

    # check that no extra columns are included
    assert len(output) == len(expected_output)


@pytest.mark.parametrize("model", MODELS_TO_TEST, ids=MODELS_TO_TEST_IDS)
def test_calculate_fuel_params_as_dict_or_series(
    model, model_variables, model_fuel_parameters, model_expected_output
):
    r"""
    Test that the calculate function returns the same output when the fuel
    parameters are passed in as a dictionary or a series.
    """
    # just use the first 10 rows of the first set of fuel parameters, as we are
    # mostly interested in getting the same output for both the dictionary and
    # series
    dataset, fuel_parameters, expected_output = (
        _get_calculate_input_and_expected_output(
            model_variables,
            model_fuel_parameters.iloc[0],
            model_expected_output,
            truncate=10,
        )
    )

    # run calculate with the fuel parameters as a dictionary
    output_dict = model.calculate(dataset, fuel_parameters)

    # run calculate with the fuel parameters as a series
    output_series = model.calculate(dataset, pd.Series(fuel_parameters))

    # check that the output is the same as the expected output for both the
    # dictionary and series
    for fields in expected_output.keys():
        np.testing.assert_allclose(output_dict[fields], expected_output[fields])
        np.testing.assert_allclose(
            output_series[fields], expected_output[fields]
        )

    # check that no extra columns are included
    assert len(output_dict) == len(expected_output)
    assert len(output_series) == len(expected_output)


def test_savannah_deprecation_warning():
    r"""
    Test that importing the savannah module raises a DeprecationWarning.
    """
    with pytest.warns(DeprecationWarning):
        from ...spread_models import savannah

    # same with attempting to access it from spread_models directly
    with pytest.warns(DeprecationWarning):
        module = spread_models.savannah

    # and no warning should happen for savanna
    from ...spread_models import savanna

    module = spread_models.savanna
