import os

# we need to import netCDF before numpy or xarray to avoid a bug: see
# https://github.com/pydata/xarray/issues/7259
import netCDF4

import xarray as xr
import pytest

from . import calc_generator
from .... import calc

SCRIPT_DIR = os.path.dirname(os.path.realpath(__file__))

FRESH_DATA_SEED = 42


def test_generate_input_dataset_model_coverage():
    """
    Check that the generate_input_dataset function generates a dataset with
    good coverage of the fuel models.
    """
    # generate a dataset
    dataset = calc_generator.generate_input_dataset()

    # get all of the fuel fdrs we expect to see in the input dataset
    fuel_fdrs = calc.FUEL_FDR_TO_MODEL.keys()

    # we expect to get them roughly equally
    expected_count = dataset.FTno_State.size // len(fuel_fdrs)

    # load the fuel map
    fuel_map = calc.load_fuel_map()

    # create a map between FTno_State and Fuel_FDR using the fuel map
    ft_no_state_to_fuel_fdr = fuel_map.set_index("FTno_State")[
        "Fuel_FDR"
    ].to_dict()

    # apply that map to the dataset and count how many of each fuel fdr we get
    fuel_fdr_counts = (
        dataset.FTno_State.to_series()
        .map(ft_no_state_to_fuel_fdr)
        .value_counts()
    )

    # check that every fuel fdr is represented, and each has at least
    # expected_count
    for fuel_fdr in fuel_fdrs:
        assert fuel_fdr in fuel_fdr_counts
        assert fuel_fdr_counts[fuel_fdr] >= expected_count


def test_generate_input_dataset_model_fields():
    """
    Check that the generate_input_dataset function generates a dataset with the
    correct fields.
    """
    # generate a dataset
    dataset = calc_generator.generate_input_dataset(shape=(50, 50))

    # check that every field we expect to see is there (and not drought_index or
    # any others we don't expect to see)
    expected_fields = [
        "FTno_State",
        "AWAP_uf",
        "KBDI_SFC",
        "SDI_SFC",
        "Curing_SFC",
        "DF_SFC",
        "GrassFuelLoad_SFC",
        "RH_SFC",
        "T_SFC",
        "Td_SFC",
        "WindMagKmh_10m",
        "hours",
        "months",
        "precipitation",
        "time_since_fire",
        "time_since_rain",
        "grass_condition",
    ]

    # check that the expected fields match the fields in the dataset
    assert set(expected_fields) == set(dataset.data_vars)

    # check that all fields have the same, expected shape
    for field in dataset.data_vars:
        assert dataset[field].shape == (50, 50)

    # if we do ask for the drought index, check that it is there
    dataset = calc_generator.generate_input_dataset(
        shape=(50, 50), add_drought_index=True
    )
    assert "drought_index" in dataset.data_vars


def test_generate_input_dataset_save_and_regression():
    """
    Check that the generate_input_dataset function saves the dataset when
    requested into the correct location, and that the dataset can be loaded
    from that location.

    This particular test will also ensure that the latest version of the input
    data is saved in `fdrs_calcs/tests/test_data/fresh_data` for use in the
    test_generate_input_dataset_value_regression test. For this reason a seed
    is used to ensure that the dataset is deterministic.

    It will also ensure that the generated dataset matches the expected values
    saved in the `fdrs_calcs/tests/test_data` folder. If the behaviour of the
    function changes, the expected values should be updated to match the new
    behaviour. Updated versions of the expected values are generated in the
    fresh_data folder when this test is run.
    """
    output_folder = os.path.join(SCRIPT_DIR, "../fresh_data")

    # generate a dataset, saving it to the output folder
    dataset = calc_generator.generate_input_dataset(
        seed=FRESH_DATA_SEED,
        save=True,
        output_folder=output_folder,
        add_drought_index=True,
    )

    # check that the dataset is saved to the correct location
    assert os.path.exists(os.path.join(output_folder, "calc_data_input.nc"))

    # check that the dataset can be loaded from that location and matches the
    # original dataset
    dataset2 = xr.load_dataset(
        os.path.join(output_folder, "calc_data_input.nc")
    )
    assert dataset.equals(dataset2)

    # load the expected dataset
    expected_dataset = xr.load_dataset(
        os.path.join(SCRIPT_DIR, "../calc_data_input.nc")
    )

    # check that the generated dataset matches the expected dataset
    assert dataset.equals(expected_dataset)


def test_generate_input_dataset_shape():
    """
    Check that the generate_input_dataset function generates a dataset with the
    correct shape.
    """
    for shape in [(10, 20), (20, 20), (20, 50), (50, 100)]:
        dataset = calc_generator.generate_input_dataset(shape=shape)
        # check that every variable has the correct shape
        for variable in dataset.data_vars:
            assert dataset[variable].shape == shape


def test_generate_input_dataset_deterministic():
    """
    Check that the generate_input_dataset function generates a deterministic
    dataset when provided with a seed, and doesn't when not provided with a
    seed.
    """

    # generate a dataset with a known shape and seed twice
    dataset = calc_generator.generate_input_dataset(seed=0)
    dataset2 = calc_generator.generate_input_dataset(seed=0)

    # and a third with a different seed
    dataset3 = calc_generator.generate_input_dataset(seed=1)

    # and a fourth and fifth with no seed
    dataset4 = calc_generator.generate_input_dataset()
    dataset5 = calc_generator.generate_input_dataset()

    # check that the first two datasets are the same
    assert dataset.equals(dataset2)

    # check that all other datasets are different
    assert not dataset.equals(dataset3)
    assert not dataset.equals(dataset4)
    assert not dataset.equals(dataset5)
    assert not dataset2.equals(dataset3)
    assert not dataset2.equals(dataset4)
    assert not dataset2.equals(dataset5)
    assert not dataset3.equals(dataset4)
    assert not dataset3.equals(dataset5)
    assert not dataset4.equals(dataset5)


@pytest.mark.parametrize(
    "calculate_grass_condition",
    [True, False],
    ids=["calc_grass_cond", "no_calc_grass_cond"],
)
def test_generate_output_data_save_and_regression(calculate_grass_condition):
    """
    Check that the generate_output_data function saves the dataset when
    requested into the correct location, and that the dataset can be loaded from
    that location.

    This particular test will also ensure that the latest version of the output
    data is saved in `fdrs_calcs/tests/test_data/fresh_data` for use in the
    test_generate_output_data_value_regression test. This output data will be
    generated from the input data generated in the
    test_generate_input_dataset_save test.

    It will also ensure that the generated dataset matches the expected values
    saved in the `fdrs_calcs/tests/test_data` folder. If the behaviour of the
    function changes, the expected values should be updated to match the new
    behaviour. Updated versions of the expected values are generated in the
    fresh_data folder when this test is run.
    """
    data_folder = os.path.join(SCRIPT_DIR, "../fresh_data")

    # load the input dataset
    input_dataset = xr.load_dataset(
        os.path.join(data_folder, "calc_data_input.nc")
    )

    # generate the output dataset
    output_dataset = calc_generator.generate_output_dataset(
        input_dataset,
        calculate_grass_condition=calculate_grass_condition,
        save=True,
        output_folder=data_folder,
    )

    # determine the filename of the dataset
    if calculate_grass_condition:
        filename = "calc_data_output_calc_grass_condition.nc"
    else:
        filename = "calc_data_output_with_grass_condition.nc"

    # check that the dataset is saved to the correct location
    assert os.path.exists(os.path.join(data_folder, filename))

    # check that the dataset can be loaded from that location and matches the
    # original dataset
    dataset2 = xr.load_dataset(os.path.join(data_folder, filename))
    assert output_dataset.equals(dataset2)

    # load the expected dataset
    if calculate_grass_condition:
        filename = "calc_data_output_calc_grass_condition.nc"
    else:
        filename = "calc_data_output_with_grass_condition.nc"
    expected_dataset = xr.load_dataset(os.path.join(SCRIPT_DIR, "..", filename))

    # check that the generated dataset matches the expected dataset
    xr.testing.assert_allclose(output_dataset, expected_dataset)
