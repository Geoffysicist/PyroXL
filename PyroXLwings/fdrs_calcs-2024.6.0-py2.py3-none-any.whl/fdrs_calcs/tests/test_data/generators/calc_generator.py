r"""
Test Data Generator for main FDRS calc.py entry point

This module contains functions that generate random input data for the main FDRS
calc.py entry point, and to run that data through the FDRS calc.py entry point
to generate the output data. This input and output data is used for testing the
FDRS calc.py entry point against regressions.
"""

import os

# we need to import netCDF before numpy or xarray to avoid a bug: see
# https://github.com/pydata/xarray/issues/7259
import netCDF4

import numpy as np
import xarray as xr

from .... import calc
from .. import get_random_data


SCRIPT_DIR = os.path.dirname(os.path.realpath(__file__))


def generate_input_dataset(
    shape=(200, 200),
    fuel_map=None,
    seed=None,
    save=False,
    output_folder=os.path.join(SCRIPT_DIR, "../fresh_data"),
    add_drought_index=False,
):
    r"""
    Generate a random input dataset for the FDRS calc.py entry point

    ### Usage

    ```python
    from fdrs_calcs.tests.test_data.generators import calc_generator
    input_dataset = calc_generator.generate_input_dataset()
    ```

    ### Parameters

    - **shape** : *tuple (width, height)*, optional - Shape of the input dataset
        to generate. Default is (200, 200).
    - **fuel_map** : *pandas.DataFrame*, optional - Fuel map to use for the
        input dataset. If None, will be loaded from
        `metadata/fuel_type_models.csv`
    - **seed** : *int*, optional - Seed to use for the random number generator
        to generate the input dataset deterministically. If None, no seed will
        be used and dataset will not be deterministic.
    - **save** : *bool*, optional - Whether to save the generated dataset to a
        netcdf `calc_data_input.nc` file in the specified output_folder. Default
        is False.
    - **output_folder** : *str*, optional - Folder to save the generated dataset
        to if save is True. Default is `fdrs_calcs/tests/test_data/fresh_data`.
    - **add_drought_index** : *bool*, optional - Whether to add the drought
        index field to the dataset, calculated based on the KBDI and SDI fields,
        depending upon the FTno_State chosen. Default is False.

    ### Returns

    - **xarray.Dataset** - The generated input dataset
    """

    # Set random seed if provided for deterministic dataset generation
    if seed is not None:
        np.random.seed(seed)

    # Load fuel map if not provided
    if fuel_map is None:
        fuel_map = calc.load_fuel_map()

    # start with a flattened version of the FTno_State dataset, filled with
    # random values from the FTno_State column in the fuel_map. Most of these
    # will be overwritten in the next step, but we don't want to leave any blank
    # values.
    pixel_count = shape[0] * shape[1]
    ftno_states = np.random.choice(
        fuel_map["FTno_State"], pixel_count, replace=True
    )

    # now, for each of the Fuel_FDR values defined in calc.FUEL_FDR_TO_MODEL,
    # divide that flattened dataset into equal sized chunks, and assign each
    # chunk to a fuel fdr, that we will randomly pick fuel models from. Whatever
    # is left over will have the random values assigned above.
    fuel_fdrs = calc.FUEL_FDR_TO_MODEL.keys()
    pixels_per_fuel_fdr = pixel_count // len(fuel_fdrs)
    # randomly pick fuel models from each fuel fdr
    for i, fuel_fdr in enumerate(fuel_fdrs):
        ftno_states[i * pixels_per_fuel_fdr : (i + 1) * pixels_per_fuel_fdr] = (
            np.random.choice(
                fuel_map.loc[fuel_map.Fuel_FDR == fuel_fdr, "FTno_State"],
                pixels_per_fuel_fdr,
                replace=True,
            )
        )

    # reshape the fuel models into the shape of the dataset
    ftno_states = ftno_states.reshape(shape)

    # and put them into the dataset
    dataset = xr.Dataset({"FTno_State": (["x", "y"], ftno_states)})

    # now add the rest of the fields, with random sensible values of the same
    # shape as the FTno_State field
    fields = [
        "AWAP_uf",
        "KBDI_SFC",
        "SDI_SFC",
        "Curing_SFC",
        "DF_SFC",
        "GrassFuelLoad_SFC",
        "RH_SFC",
        "T_SFC",
        "Td_SFC",
        "WindMagKmh_10m",
        "hours",
        "months",
        "precipitation",
        "time_since_fire",
        "time_since_rain",
        "grass_condition",
    ]
    for field in fields:
        dataset[field] = (["x", "y"], get_random_data(field, shape))

    # add the drought index if requested
    if add_drought_index:
        dataset["drought_index"] = (
            ["x", "y"],
            calc.merge_drought_index(
                dataset["KBDI_SFC"].values,
                dataset["SDI_SFC"].values,
                dataset["FTno_State"].values,
            ),
        )

    # save the dataset if requested
    if save:
        dataset.to_netcdf(os.path.join(output_folder, "calc_data_input.nc"))

    # now return the dataset
    return dataset


def generate_output_dataset(
    input_dataset,
    calculate_grass_condition=False,
    save=False,
    output_folder=os.path.join(SCRIPT_DIR, "../fresh_data"),
):
    """
    Generate the output dataset for the FDRS calc.py entry point from the
    provided input dataset

    Parameters
    ----------
    input_dataset : xarray.Dataset
        The input dataset to generate the output dataset from
    calculate_grass_condition : bool, optional
        Whether to calculate the grass condition from the grass fuel load (and
        ignore the provided grass condition) or to take the provided grass
        condition from the input dataset. Default is False (take the provided
        grass condition).
    save : bool, optional
        Whether to save the generated dataset to a netcdf file in the specified
        output_folder. Default is False. The filename will be
        `calc_data_output_with_grass_condition.nc` if calculate_grass_condition
        is False, or `calc_data_output_calc_grass_condition.nc` if
        calculate_grass_condition is True.
    output_folder : str, optional
        Folder to save the generated dataset to if save is True. Default is
        `fdrs_calcs/tests/test_data/fresh_data`.

    Returns
    -------
    xarray.Dataset
        The generated output dataset
    """
    # set the grass condition to None if we are calculating it
    if calculate_grass_condition:
        grass_condition = None
    else:
        grass_condition = input_dataset.grass_condition.values

    # calculate the output data
    output_data = calc.calculate_indicies(
        temp=input_dataset.T_SFC.values,
        windmag10m=input_dataset.WindMagKmh_10m.values,
        rh=input_dataset.RH_SFC.values,
        td=input_dataset.Td_SFC.values,
        df=input_dataset.DF_SFC.values,
        curing=input_dataset.Curing_SFC.values,
        grass_fuel_load=input_dataset.GrassFuelLoad_SFC.values,
        precip=input_dataset.precipitation.values,
        time_since_rain=input_dataset.time_since_rain.values,
        time_since_fire=input_dataset.time_since_fire.values,
        ground_moisture=input_dataset.AWAP_uf.values,
        kbdi=input_dataset.KBDI_SFC.values,
        sdi=input_dataset.SDI_SFC.values,
        fuel_type=input_dataset.FTno_State.values,
        fuel_table=calc.load_fuel_map(),
        hours=input_dataset.hours.values,
        months=input_dataset.months.values,
        grass_condition=grass_condition,
        return_model=True,
    )

    # convert the output from a dict of array-likes to an xarray dataset
    output_dataset = xr.Dataset(
        {k: (["x", "y"], v) for k, v in output_data.items()}
    )

    # save the dataset if requested
    if save:
        # determine the filename
        if calculate_grass_condition:
            filename = "calc_data_output_calc_grass_condition.nc"
        else:
            filename = "calc_data_output_with_grass_condition.nc"

        output_dataset.to_netcdf(os.path.join(output_folder, filename))

    # and return it
    return output_dataset
