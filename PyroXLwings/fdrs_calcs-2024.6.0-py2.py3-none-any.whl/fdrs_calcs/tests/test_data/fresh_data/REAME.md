# fresh_data folder

This folder contain will contain freshly generated data used to test calc.py and
the spread_models after running `pytest` in the root folder of this repository.
If all `pytest` tests pass it will be the same as the data in the parent
`test_data` folder.

If the functionality of calc.py and/or a spread model is changed and you are
confident in the current output, the data in this folder can be used to copy
over the top of the relevant data in the parent `test_data` folder to fix the
regression test error.