from typing import Sequence, Union, Mapping
import numpy as np

VariableToValues = Mapping[str, Union[Sequence[float], Sequence[int]]]

TESTING_VALUES: VariableToValues = {
    # wider coverage for T_SFC, RH_SFC, WindMagKmh_10m as most models are
    # more sensitive to these variables
    "T_SFC": [-5.0, 0, 6.25, 12.5, 25.0, 30.0, 40.0, 50.0],
    "RH_SFC": [0.0, 5.0, 10.0, 15.0, 20.0, 25.0, 50.0, 80.0, 100.0],
    "WindMagKmh_10m": [
        0.0,
        5.0,
        10.0,
        15.0,
        20.0,
        30.0,
        40.0,
        80.0,
        150.0,
        300.0,
    ],
    "Curing_SFC": [0, 12.5, 25.0, 50.0, 100.0],
    # grass fuel load adjusted to include the thresholds at 4 and 6 t/ha
    # for calculating the grass condition
    "GrassFuelLoad_SFC": [1.25, 3.0, 4.0, 6.0, 10.0],
    # grass condition can only be 1, 2, or 3 (eaten out, grazed, natural)
    "grass_condition": [1, 2, 3],
    "precipitation": [0, 6.25, 12.5, 25.0, 50.0],
    # time since rain (days) is an integer
    "time_since_rain": [0, 12, 25, 50, 100],
    "Td_SFC": [-20, -10, 6.25, 12.5, 25],
    # time since fire (years) is an integer, and can't be zero
    "time_since_fire": [1, 6, 13, 19, 25],
    "DF_SFC": [0, 1.25, 2.5, 5.0, 10.0],
    "KBDI_SFC": [0, 25.4, 50.8, 101.6, 203.2],
    "SDI_SFC": [0, 25.4, 50.8, 101.6, 203.2],
    "drought_index": [0, 25.4, 50.8, 101.6, 203.2],
    "AWAP_uf": [0, 12.5, 25.0, 50.0, 100.0],
    # months are spaced evenly across the year
    "months": [1, 3, 5, 7, 9, 11],
    # hours are spaced evenly across the day
    "hours": [0, 4, 8, 12, 16, 20],
}


def get_random_data(field: str, shape: tuple[int, int]) -> np.ndarray:
    r"""
    Generates sensible random data for a field of the given shape.

    Random values are taken from TESTING_VALUES. If the field is not in
    TESTING_VALUES, a KeyError will be raised.

    ### Usage

    ```python
    from fdrs_calcs.tests.test_data.generators import get_random_data
    data = get_random_data(field, shape)
    ```

    ### Parameters

    - **field** : *str* - The name of the field to generate data for
    - **shape** : *tuple* - The shape of the data to generate

    ### Returns

    - **data** : *numpy.ndarray* - The generated data
    """
    return np.random.choice(TESTING_VALUES[field], shape)
