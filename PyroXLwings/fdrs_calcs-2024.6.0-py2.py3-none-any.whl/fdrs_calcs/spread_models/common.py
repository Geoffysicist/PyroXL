r"""
Common functions shared between spread models
"""

from warnings import warn
import numpy as np


def calc_accumulation_since_fire(
    time_since_fire, steady_state, accumulation_rate
):
    r"""
    Calculate fuel/hazard accumulation since fire

    ### Technical Guide

    Accumulation of fuel or hazard scores since a fire event is calculated using
    Olson curves [@olson1963]. These curves take a steady_state value ($F_{ss}$)
    and an accumulation rate ($k$) and accumulate towards the steady state value
    based on the time since the fire event ($t$):

    $$
    F = F_{ss} (1 - e^{-kt})
    $$ {#eq-olson}

    ### Usage

    ```python
    current_value = calc_accumulation_since_fire(
        time_since_fire, steady_state, accumulation_rate
    )
    ```

    ### Parameters

    - **time_since_fire** - Time since the fire event (years)
    - **steady_state** - Steady state value (e.g. fuel load, hazard score)
    - **accumulation_rate** - Accumulation rate (1/years)

    ### Returns

    - **current_value** - Current value of fuel/hazard score
    """
    return steady_state * (1 - np.exp(-accumulation_rate * time_since_fire))


def calc_fire_intensity(rate_of_spread, fuel_load, heat_yield):
    r"""
    Calculate fire-line intensity (kW/m)

    ### Technical Guide

    Fire-line intensity is calculated using the following equation from
    @byram1959:

    $$
    I = h \times F \times ROS
    $$ {#eq-fire-intensity}

    where $h$ is the heat yield (kJ/kg), $F$ is the fuel load (kg/m^2), and ROS
    is the rate of spread in m/s.

    ### Implementation Details

    In order to apply the equation from @byram1959, both the fuel load and rate
    of spread need to be converted to match that used in the equation. The fuel
    load is provided to this function in t/ha, so it is converted to kg/m^2
    before calculating the intensity. The rate of spread is provided in m/hr, so
    it is converted to m/s before calculating the intensity.

    ### Usage

    ```python
    intensity = calc_fire_intensity(
        rate_of_spread, fuel_load, heat_yield
    )
    ```

    ### Parameters

    - **rate_of_spread** - Rate of spread (m/hr)
    - **fuel_load** - Fuel load (t/ha)
    - **heat_yield** - Heat yield (kJ/kg)

    ### Returns

    - **intensity** - Fire-line intensity (kW/m)
    """
    # Convert fuel load from t/ha to kg/m^2
    fuel_load = fuel_load / 10

    # Convert rate of spread from m/hr to m/s
    rate_of_spread = rate_of_spread / 3600

    # Calculate fire intensity
    intensity = heat_yield * fuel_load * rate_of_spread

    return intensity


def standardize_dataset_variables(dataset):
    r"""
    Ensure that all variables in the dataset are standardized to have the
    expected variable names.

    At present the following actions are taken to standardise the dataset:

    - Rename the WindMagKmh_SFC or WindMaxInHourKmh_SFC variables to
      WindMagKmh_10m to reflect that the variable is the 10m wind speed.

    If any standardisation actions are taken, a warning is issued to the user.

    ### Usage

    ```python
    dataset = standardize_dataset_variables(dataset)
    ```

    ### Parameters

    - **dataset** (*dict*) - A dictionary of variables and their values

    ### Returns

    - **dataset** (*dict*) - A dictionary of variables and their values with
        names standardized to have the expected variable names
    """
    # if 'WindMagKmh_SFC' is in the dataset, rename it to 'WindMagKmh_SFC'
    # and issue a deprecation warning
    if "WindMagKmh_SFC" in dataset:
        dataset["WindMagKmh_10m"] = dataset.pop("WindMagKmh_SFC")
        warn(
            """The WindMagKmh_SFC variable has been renamed to
            WindMagKmh_10m to better reflect how the variable is defined
            and used. fdrs_calcs will remove the old variable in a
            future release. Please update your code to use the new variable
            name.
            """,
            DeprecationWarning,
        )

    # if 'WindMaxInHourKmh_SFC' is in the dataset, rename it to 'WindMagKmh_10m'
    # and issue a deprecation warning
    if "WindMaxInHourKmh_SFC" in dataset:
        dataset["WindMagKmh_10m"] = dataset.pop("WindMaxInHourKmh_SFC")
        warn(
            """The WindMaxInHourKmh_SFC variable has been renamed to
            WindMagKmh_10m to better reflect how the variable is defined
            and used. fdrs_calcs will remove the old variable in a
            future release. Please update your code to use the new variable
            name.
            """,
            DeprecationWarning,
        )

    return dataset
