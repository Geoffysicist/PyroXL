r"""
Fire behaviour calculations for gamba grass

## Technical Guide

A highly invasive introduced species that grows to 4m tall and produces very
high fuel loads. Mainly found in the tropics, especially in the NT between
Katherine and Darwin. Note that the fuel loads and fuel height of this sub-type
are outside the original range of application for the grassland model. The fuel
condition is always set to natural with this sub-fuel.
"""

import numpy as np

from . import fire_behaviour_index
from . import fire_danger_rating
from .. import typing as ft
from .common import standardize_dataset_variables

from .csiro_grassland import calc_fuel_moisture
from .csiro_grassland import calc_rate_of_spread
from .csiro_grassland import calc_flame_height
from .csiro_grassland import calc_intensity
from .csiro_grassland import calc_spotting_distance
from .csiro_grassland import GRASS_CONDITION_NATURAL

from .savanna import SavannaFuelParameters


# add additional type hints for gamba specific inputs
class GambaInputVariables(ft.CommonInputVariables):
    r"""Gamba specific additional input variables"""

    Curing_SFC: ft.Curing_SFC_Array


class GambaFuelParameters(SavannaFuelParameters):
    r"""Gamba specific additional fuel parameters"""

    FL_total: ft.FL_total_Value


def calculate(
    dataset: GambaInputVariables, fuel_parameters: GambaFuelParameters
) -> ft.CommonOutputIndices:
    r"""
    Main entry point for calculating fire behaviour for gamba grass.

    ### Implementation Details

    Implemented using the CSIRO Grassland Fire Spread Model with the following
    modifications:

    - The grass condition is set to `GRASS_CONDITION_NATURAL`
    - A wind reduction factor (`WF_Sav`) applied to the rate of spread
    - The fuel load is provided as a fuel parameter, and not clipped prior to
      intensity calculations

    ### Usage

    ```python indices = gamba.calculate(dataset, fuel_parameters) ```

    ### Parameters

    - **dataset** (*dict*) - A dictionary of *array_like* containing the input
        variables.

        From these input variables, only the following are used by this model

        - **T_SFC** : Surface temperature (C)
        - **RH_SFC** : Relative humidity (%)
        - **WindMagKmh_10m** : Wind magnitude at 10m (km/h)
        - **Curing_SFC** : Fuel curing (%)

    - **fuel_parameters** A dictionary of scalars containing the fuel
      parameters.

        For this model the following parameters are used

        - **FL_total** : Total fuel load (kg/m^2)
        - **WF_Sav** : Wind reduction factor (0.0-1.0, unitless)

    ### Returns

    - **indices** (*dict*) - A dictionary of *array_like* containing the output
        variables of the same shape as the input arrays with the following keys

        - **dead_fuel_moisture** : Dead fuel moisture content (%)
        - **rate_of_spread** : Rate of spread (m/hr)
        - **flame_height** : Flame height (m)
        - **intensity** : Fire intensity (kW/m)
        - **spotting_distance** : Spotting distance (m)
        - **rating_1** : Fire danger rating (unitless)
        - **index_1** : Fire behaviour index (unitless)
    """
    # standardize the dataset variables
    dataset = standardize_dataset_variables(dataset)

    # calculate the dead fuel moisture content
    dead_fuel_moisture = calc_fuel_moisture(dataset["T_SFC"], dataset["RH_SFC"])

    # as per the technical guide, gamba grass is always treated as having
    # natural grass condition, with fixed loads per fuel type (see FL_total
    # below)
    grass_condition = np.full(
        dataset["WindMagKmh_10m"].shape, GRASS_CONDITION_NATURAL
    )

    # calculate rate of spread from the dead fuel moisture content, wind speed
    # and curing using the CSIRO grassland model. However, for gamba, we set the
    # grass condition to GRASS_CONDITION_NATURAL, and multiply by the wind
    # reduction factor (WF_Sav) to account for the reduced wind speed due to
    # the presence of trees.
    rate_of_spread = calc_rate_of_spread(
        dead_fuel_moisture,
        dataset["WindMagKmh_10m"],
        dataset["Curing_SFC"],
        grass_condition,
    )
    rate_of_spread = rate_of_spread * fuel_parameters["WF_Sav"]

    # calculate flame height based on the rate of spread and grass condition
    flame_height = calc_flame_height(rate_of_spread, grass_condition)

    # calculate the fire intensity from the rate of spread and the fuel load for
    # gamba grass the fuel loads are not clipped prior to the intensity
    # calculations
    intensity = calc_intensity(
        rate_of_spread, fuel_parameters["FL_total"], clip_load_range=None
    )

    # calculate the spotting distance from the surface temperature
    spotting_distance = calc_spotting_distance(dataset["T_SFC"])

    # calculate the fire behaviour index and fire danger rating from the
    # intensity using the grass model
    index_1 = fire_behaviour_index.grass(intensity)
    rating_1 = fire_danger_rating.fire_danger_rating(index_1)

    # return the outputs
    return {
        "dead_fuel_moisture": dead_fuel_moisture,
        "rate_of_spread": rate_of_spread,
        "flame_height": flame_height,
        "intensity": intensity,
        "spotting_distance": spotting_distance,
        "rating_1": rating_1,
        "index_1": index_1,
    }
