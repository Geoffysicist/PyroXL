r"""
CSIRO grassland model for use in grass-like models

## Technical Guide - AFDRS Grassland Model

The AFDRS Grassland Model is used for a variety of grassland fuels, including
continuous and tussock grasslands, pasture, grassy crops, and gamba grass.
Grassland fuels are widespread across Australia, dominating 46% of all FWAs and
having a significant influence in 76% of FWAs.

### What is the AFDRS Grassland Model?  {#sec-grassland-model}

The model used for grasslands in AFDRS is the CSIRO Grassland Fire Spread Meter,
described in two key research papers: @cheney1998 and @cruz2015b. The
researchers aimed to better capture the wind and fuel load effect compared to
the McArthur meter. This model was developed using 121 experimental fires at
Annaburroo Station in the NT in 1986 and using case studies of wildfires.

### Inputs and Outputs {#sec-grass-inputs}

As with the McArthur grassland meter, this model requires inputs of curing,
temperature, relative humidity, and wind speed. The fuel state was also
incorporated into this model to better capture the influence of differing fuel
characteristics on the observed rate of spread in grass fires. This is a simple
model and outputs Rate of Spread (ROS) and flame height.

### Model Behaviour and Limitations {#sec-limitations}

This is generally a well-balanced model and not overly sensitive to the inputs,
though wind and dead fuel moisture content generally have the greatest
influence. There are, however, a few things to note:

- Accurate assessment of fuel condition in all areas is difficult; "grazed" is
  used as default in absence of observed/known condition. Additionally, AFDRS
  assumes a standard correlation between fuel load and fuel condition, rather
  than a direct observation of fuel conditions in an area.
- Choice of fuel condition has a large impact on model output, except in extreme
  burning conditions where ROS is similar for all 3 conditions.
- The original model was developed for natural and grazed fuels. The eaten-out
  condition was added later and was assumed to halve the ROS of grazed fuels for
  wind speeds over 5km/h. It likely overestimates ROS in mild weather
  conditions.
- If curing is < 20%, fires will self-extinguish.
- Curing generally has less of an influence as the dry season/summer progresses;
  for southern Australia grasses tend to be fully cured by the end of January,
  so this input effectively becomes a constant.
- The influence of wind follows an almost linear effect, with a critical
  threshold of 5km/h.
- The fuel moisture content follows an exponential decay when dead fuel moisture
  content, $MC$, is < 12%, and linear decay otherwise (i.e. $MC$ > 12%).
- If $MC$ > 20%, no fire propagation will occur.
- When $MC$ > 5%, the CSIRO grassland fire spread model tends to predict faster
  rates of fire spread compared to the McArthur meters for wind speeds up to
  50-60 km/h, after which McArthur meters yield faster fire spread rates.
- For $MC$ < 5%, this wind speed threshold lowers; McArthur meters will predict
  faster rates of fire spread at wind speeds above 30-40 km/h.

### Fuel Sub-Types {#sec-grass-fuel-types}

There are five sub-fuels defined in AFDRS that use the grassland model, with
Gamba grass having been added as a separate sub-fuel after the completion of the
NFDRS report. These sub-fuels are:

- Grass
- Pasture
- Chenopod Shrubland
- Low Wetland
- Gamba Grass

## Technical Guide - Woody Grassland Model

The AFDRS Grassy Woodland Model, originally called the Savanna Model, is used
for the tropical savanna woodlands of northern Australia and other structurally
similar vegetation throughout the country. This fuel covers the greatest area of
Australia out of the eight fuel types, though it affects less Fire Weather Areas
than grass It dominates in 20% of FWAs and influences 51%. Grassy woodlands are
most common in QLD and NT, covering just over 40% of these regions.

### What is the AFDRS Grassy Woodland Model?  {#sec-savanna-model}

This model is an extension of the CSIRO Grassland Model. In woodland-like
vegetations (grass with a sparse overstorey of trees) the tree overstorey
reduces the wind speed near the ground and therefore the rate of spread of fire
through the surface and near-surface fuels. This model can be considered a
rule-of-thumb model as it applies the grassland model with an estimated
reduction to the rate of spread. This model maintains the three fuel conditions
from the grassland model: natural (also called undisturbed), cut/grazed, and
eaten out. The model will use the reported grass condition layer input from
agency observations. If no inputs are given, or for some of the fuel sub-types,
a default value of fuel condition is used (see sub-types below). The default for
grassy woodland is natural.

### Inputs and Outputs {#sec-savanna-inputs}

As with the grassland model, the grassy woodland requires inputs of curing,
temperature, relative humidity, wind speed and fuel state. This is a simple
model and outputs Rate of Spread (ROS), fireline intensity, and flame height.
This model also requires an overstorey height to determine the rate of spread
reduction factor (wind speed reduction factor):

### Model Behaviour and Limitations {#sec-limitations}

This is generally a well-balanced model and is not overly sensitive to any of
the inputs, though wind and dead fuel moisture content generally have the
greatest influence. This model has a default fuel state of natural rather than
grazed as per the grassland model, so this model may over-predict fire spread in
open woodlands/forests that are grazed.

Choice of condition has a large impact on model output (stronger effect than
fuel load) except in extreme burning conditions where ROS is similar for all 3
conditions.

The original model was developed for natural and grazed fuels. The eaten-out
condition was added later and was assumed to half the ROS of grazed fuels for
wind speeds over 5km/h. It likely overestimates ROS in mild weather conditions.

The influence of wind follows an almost linear effect, with a critical threshold
of 5km/h. The fuel moisture content follows an exponential decay when dead fuel
moisture content $MC$ < 12%, and linear decay otherwise ($MC$ > 12%).

Based on experimental fire results, for this fuel no fire propagation will occur
if $MC$ > 20% and fires will self-extinguish if curing is less than 20%.

### Fuel Sub-Types {#sec-savanna-fuel-types}

There are currently four sub-fuels defined in AFDRS that use the Grassy Woodland
model:

- Woody Grassland (Savanna)
- Acacia woodland
- Woody horticulture
- Rural

## Implementation Details

This `csiro_grassland.py` module contains the helper functions used by the
grassland and woody grassland models. The particular grassland models themselves
are implemented in the individual modules:

- `grass.py`
- `pasture.py`
- `chenopod.py`
- `low_wetland.py`
- `savanna.py`
- `acacia_woodland.py`
- `woody_horticulture.py`
- `rural.py`
- `gamba.py`
"""

import numpy as np

from . import common
from .. import typing as ft

HEAT_CONTENT = 18600
"""Heat content of grassland fuels (kJ/kg)"""

M_PER_KM = 1000
"""Number of metres in a kilometre"""

GRASS_CONDITION_NATURAL = 3
"""Grass condition code for natural grasslands"""

GRASS_CONDITION_GRAZED = 2
"""Grass condition code for grazed grasslands"""

GRASS_CONDITION_EATENOUT = 1
"""Grass condition code for eaten out grasslands"""


def calc_grass_condition(fuel_load):
    r"""
    Calculate the grass conditions from the fuel load

    ### Technical Guide

    Models for three types of grasslands were presented in the original paper by
    @cheney1998, i.e. natural (undisturbed/ungrazed) grasslands, cut or grazed
    grasslands, and eaten-out grasslands. These conditions are generally
    obtained from the grass condition layer provided by agencies. However, if
    this layer is not provided, the following default values are used:

    - **natural**: fuel load >= 6 t/ha
    - **grazed**: 3 <= fuel load < 6 t/ha
    - **eaten out**: fuel load < 3 t/ha

    ::: {.callout-note}
    In October 2023, the grassland fuel load guidance was updated based on the
    recommendations of the AFDRS Grassland Working Group to the following:

    |                    | Natural        | Grazed         | Eaten Out      |
    |--------------------|----------------|----------------|----------------|
    | Continuous Fuel    | 4.0 - 5.0 t/ha | 2.7 - 4.5 t/ha | 1.5 - 2.0 t/ha |
    | Discontinuous Fuel | 3.0 - 4.0 t/ha | 2.0 - 2.7 t/ha | 1.0 - 1.5 t/ha |

    : Updated guidance for grassland fuel loads in AFDRS.
        {#tbl-grassland-fuel-loads}

    In AFDRS, the grass condition is generally provided by the agency, based on
    the above guidance.

    However, if the grass condition is not provided, the fuel load will still be
    estimated using the original thresholds from @cheney1998. This may
    be updated in the future to use the new guidance provided by the AFDRS
    Grassland Working Group.
    :::

    ### Usage

    ```python
    grass_condition = calc_grass_condition(fuel_load)
    ```

    ### Parameters

    - **fuel_load** (*array_like*) - Fuel load (t/ha).

    ### Returns

    - **grass_condition** (*array_like*) - Grass condition (3: natural, 2:
        grazed, 1: eaten out)
    """
    # setup nan grass_condition of the same shape as fuel_load
    grass_condition = np.full(fuel_load.shape, np.nan)

    # use natural grass condition for fuel loads greater than or equal to 6 t/ha
    mask = fuel_load >= 6
    if np.any(mask):
        grass_condition[mask] = GRASS_CONDITION_NATURAL

    # use grazed grass condition for fuel loads between 3 and 6 t/ha
    mask = (fuel_load >= 3) & (fuel_load < 6)
    if np.any(mask):
        grass_condition[mask] = GRASS_CONDITION_GRAZED

    # use eaten out grass condition for fuel loads less than 3 t/ha
    mask = fuel_load < 3
    if np.any(mask):
        grass_condition[mask] = GRASS_CONDITION_EATENOUT

    return grass_condition


def assert_valid_grass_conditions(array):
    r"""
    Raise an error if any values in the array are not valid grass conditions.

    Valid grass conditions are GRASS_CONDITION_EATENOUT, GRASS_CONDITION_GRAZED
    and GRASS_CONDITION_NATURAL from the csiro_grassland module.
    """
    if not np.all(
        np.isin(
            array,
            [
                GRASS_CONDITION_EATENOUT,
                GRASS_CONDITION_GRAZED,
                GRASS_CONDITION_NATURAL,
            ],
        )
    ):
        raise ValueError(
            "Invalid grass_condition values. Must be one of "
            "GRASS_CONDITION_EATENOUT, GRASS_CONDITION_GRAZED or "
            "GRASS_CONDITION_NATURAL."
        )


def calc_fuel_moisture(air_temperature, relative_humidity):
    r"""
    Calculate grassland dead fuel moisture content (%)

    ### Technical Guide

    Moisture content (in %) is calculated based on the model developed for the
    Mk 3/4 meters and published as a graph in @mcarthur1966 (@cruz2015b).

    $$
    MC = 9.58 - 0.205 T + 0.138 RH
    $$ {#eq-moisture-content}

    The lower limit of the fuel moisture coefficient ($\Phi_{MC}$) given in
    @cheney1998 was 2% moisture content. Based on analysis of historical data
    and more recent investigation into the sensitivity of rate of spread to low
    moisture content and wind speed by @cruz2022, this value was set to 5%
    for AFDRS calculations.

    Accordingly all fuel moisture values below 5% are set to 5% in the AFDRS
    implementation.

    ### Usage

    ```python
    fuel_moisture = calc_fuel_moisture(air_temperature, relative_humidity)
    ```

    ### Parameters

    - **air_temperature** (*array_like*) - Air Temperature (C)

    - **relative_humidity** (*array_like*) - Relative Humidity (%)

    ### Returns

    - **fuel_moisture** (*array_like*) - Dead fuel moisture content (%)
    """
    # calculate fuel moisture in percentage
    fuel_moisture = 9.58 - 0.205 * air_temperature + 0.138 * relative_humidity

    # set lower limit of fuel moisture to 5%
    fuel_moisture[fuel_moisture < 5] = 5

    # return fuel moisture
    return fuel_moisture


def calc_fuel_moisture_factor(dead_fuel_moisture, wind_speed):
    r"""
    Calculate grassland fuel moisture factor/coefficient ($\Phi_{MC}$)

    ### Technical Guide

    @cheney1998 calculated the fuel moisture coefficient ($\Phi_{MC}$) based on
    three different conditions based on fuel moisture ($MC$) and 10m wind speed
    ($W$):

    $$ 
    \Phi_{MC} = \left\{ \begin{array}{ll}
        e^{-0.108 MC} & \mbox{if } MC < 12 \\ 
        0.684 - 0.0342 MC & \mbox{if } MC \geq 12 \mbox{ and } W \leq 10 \\ 
        0.547 - 0.0228 MC & \mbox{if } MC \geq 12 \mbox{ and } W > 10
    \end{array} \right. 
    $$ {#eq-fuel-moisture-factor}

    ### Implementation Details

    When calculating the fuel moisture factor above a moisture content of 12%,
    the fuel moisture coefficient is clipped to stay between 0.001 and 1.0.

    ### Usage

    ```python
    fuel_moisture_factor = calc_fuel_moisture_factor(
        dead_fuel_moisture, wind_speed
    )
    ```

    ### Parameters

    - **dead_fuel_moisture** (*array_like*) - Dead fuel moisture content (%).
    - **wind_speed** (*array_like*) - Wind speed (km/h).

    ### Returns

    - **fuel_moisture_factor** (*array_like*) - Fuel moisture factor/coefficient
        ($\Phi_{MC}$).
    """
    # setup nan fuel_moisture_factor of same shape as dead_fuel_moisture
    fuel_moisture_factor = np.full(dead_fuel_moisture.shape, np.nan)

    # calculate fuel moisture factor when dead fuel moisture is less than 12%
    mask = dead_fuel_moisture < 12
    if np.any(mask):
        fuel_moisture_factor[mask] = np.exp(-0.108 * dead_fuel_moisture[mask])

    # calculate fuel moisture factor when dead fuel moisture is greater than or
    # equal to 12% and wind speed is less than or equal to 10
    mask = (dead_fuel_moisture >= 12) & (wind_speed <= 10)
    if np.any(mask):
        fuel_moisture_factor[mask] = np.clip(
            0.684 - 0.0342 * dead_fuel_moisture[mask],
            0.001,
            1,  # clip to 0.001 -> 1.0 (TODO: explain why)
        )

    # calculate fuel moisture factor when dead fuel moisture is greater than or
    # equal to 12% and wind speed is greater than 10
    mask = (dead_fuel_moisture >= 12) & (wind_speed > 10)
    if np.any(mask):
        fuel_moisture_factor[mask] = np.clip(
            0.547 - 0.0228 * dead_fuel_moisture[mask],
            0.001,
            1,  # clip to 0.001 -> 1.0 (TODO: explain why)
        )

    # return fuel moisture factor
    return fuel_moisture_factor


def calc_intensity(rate_of_spread, fuel_load, clip_load_range=(1, 6)):
    r"""
    Calculate grassland fireline intensity (kW/m)

    ### Technical Guide

    The fireline intensity is calculated using @byram1959:

    $$
    I = h \times F \times ROS
    $$ {#eq-fire-intensity}

    Where $h$ is the heat yield, assumed here to be 18,600 kJ/kg, $F$ is the
    fuel load in kg/m^2 and $ROS$ is the rate of spread in m/s.

    ::: {.callout-note}
    Based on Table 3.1 in @cheney2008, the heat yield in grass species
    could be lower than the commonly used value of 18,600 kJ/kg.
    :::

    ### Implementation Details

    Additionally, by default the fuel_load is clipped to be between 1 and 6
    t/ha before calculating the intensity. This can be modified or turned off by
    setting the `clip_load_range` parameter.

    After clipping, this function is just a light wrapper around
    `common.calc_fire_intensity` which implements the above equation.

    ### Usage

    ```python
    intensity = calc_intensity(
        rate_of_spread,
        fuel_load,
        clip_load_range, # optional
    )
    ```

    ### Parameters

    - **rate_of_spread** (*array_like*) - Rate of spread (m/hr).
    - **fuel_load** (*array_like*) - Fuel load (t/ha).
    - **clip_load_range** (*(num, num)*) - Optional, range to clip fuel load to
      (t/ha). Default is (1, 6). If set to None, no clipping will occur.

        For example, in gamba grass, the fuel loads are often outside the range
        of normal application for the grassland model, so this function is used
        with no clip_load_range.

    ### Returns

    - **intensity** (*array_like*) - Fireline intensity (kW/m).
    """
    # clip fuel load if required
    if clip_load_range is not None:
        start, end = clip_load_range
        fuel_load = np.clip(fuel_load, start, end)

    # calculate and return intensity
    return common.calc_fire_intensity(rate_of_spread, fuel_load, HEAT_CONTENT)


def calc_flame_height(rate_of_spread, grass_condition):
    r"""
    Calculate flame height (m)

    ### Technical Guide

    Flame height (m) is calculated using the following equations, provided by
    Matt Plucinski (pers. comm. 31/07/2017).

    For natural grasses:

    $$
    H = 2.66 \times \left( \frac{ROS/1000}{3.6} \right)^{0.295}
    $$ {#eq-flame-height-natural}

    And for grazed and eaten out grasses:

    $$
    H = 1.12 \times \left( \frac{ROS/1000}{3.6} \right)^{0.295}
    $$ {#eq-flame-height-grazed}

    Where $ROS$ is the rate of spread in m/s.

    ### Usage

    ```python
    flame_height = calc_flame_height(rate_of_spread, grass_condition)
    ```

    ### Parameters

    - **rate_of_spread** (*array_like*) - Rate of spread (m/hr).
    - **grass_condition** (*array_like*) - Grass condition (3: natural, 2:
        grazed, 1: eaten out)

    ### Returns

    - **flame_height** (*array_like*) - Flame height (m).
    """
    # check that all grass_conditions are valid
    assert_valid_grass_conditions(grass_condition)

    # setup nan flame_height of the same shape as rate_of_spread
    flame_height = np.full(rate_of_spread.shape, np.nan)

    # calculate flame height for natural grasses
    mask = grass_condition == GRASS_CONDITION_NATURAL
    if np.any(mask):
        flame_height[mask] = 2.66 * np.power(
            ((rate_of_spread[mask] / M_PER_KM) / 3.6), 0.295
        )

    # calculate flame height for grazed and eaten out grasses
    mask = (grass_condition == GRASS_CONDITION_GRAZED) | (
        grass_condition == GRASS_CONDITION_EATENOUT
    )
    if np.any(mask):
        flame_height[mask] = 1.12 * np.power(
            ((rate_of_spread[mask] / M_PER_KM) / 3.6), 0.295
        )

    # return flame height
    return flame_height


def calc_spotting_distance(air_temperature):
    r"""
    Calculate grassland spotting distance (m)

    ### Technical Guide

    A spotting model is not currently implemented for grassland fuel types.

    ### Implementation Details

    As a spotting model is not currently implemented for grassland fuel types,
    this function returns an empty array (all values NaN) of the same shape as
    the air_temperature array.

    ### Usage

    ```python
    spotting_distance = calc_spotting_distance(air_temperature)
    ```

    ### Parameters

    - **air_temperature** (*array_like*) - Air temperature (C).

    ### Returns

    - **spotting_distance** (*array_like*) - Spotting distance (m).
    """
    return np.full(air_temperature.shape, np.nan)


def calc_rate_of_spread(
    dead_fuel_moisture,
    wind_speed,
    curing,
    grass_condition,
    r_nl0=0.054,
    r_nlw=0.269,
    r_nh0=1.4,
    r_nhw=0.838,
    r_gl0=0.054,
    r_glw=0.209,
    r_gh0=1.1,
    r_ghw=0.715,
    r_el0=0.027,
    r_elw=0.1045,
    r_eh0=0.55,
    r_ehw=0.357,
):
    r"""
    Calculate grassland rate of spread (m/h)

    ### Technical Guide

    Fire rate of spread in continuous grasslands was calculated by @cheney1998
    based on 10 m wind speed, dead fuel moisture content and degree of curing,
    dependent on the grass_condition. To describe the relationship between rate
    of spread and wind speed, a linear function is used for 10 m wind speeds
    below 5 km/h and a power function is used at 10 m wind speeds above 5 km/h.

    In general, the rate of spread is calculated using the following equation if
    the wind speed is less than 5 km/h:

    $$ 
    ROS_l = 1000 \times (r_{l0} + r_{lw} W) \times \Phi_{MC} \times \Phi_{C}
    $$ {#eq-ros-low-wind}
    
    and using the following equation if the wind speed is greater than or equal
    to 5 km/h:

    $$ 
    ROS_h = 1000 \times (r_{h0} + r_{hw} (W-5)^{0.844}) \times \Phi_{MC} 
        \times \Phi_{C}
    $$ {#eq-ros-high-wind}

    Where $W$ is the 10m wind speed in km/h, $\Phi_{MC}$ is the fuel moisture
    factor, calculated above, and $\Phi_{C}$ is the curing factor, outlined 
    below. The coefficients $r_{l0}$, $r_{lw}$, $r_{h0}$ and $r_{hw}$ are 
    different for each grass condition and are described below.

    For natural grasslands, the coefficients are:

    $$ 
    \begin{aligned}
        r_{l0} &= r_{nl0} = 0.054, \\ 
        r_{lw} &= r_{nlw} = 0.269, \\ 
        r_{h0} &= r_{nh0} = 1.4, \\ 
        r_{hw} &= r_{nhw} = 0.838
    \end{aligned} 
    $$ {#eq-ros-coeffs-natural}

    For cut or grazed grasslands, the coefficients are:

    $$ 
    \begin{aligned}
        r_{l0} &= r_{gl0} = 0.054, \\ 
        r_{lw} &= r_{glw} = 0.209, \\ 
        r_{h0} &= r_{gh0} = 1.1, \\ 
        r_{hw} &= r_{ghw} = 0.715
    \end{aligned} 
    $$ {#eq-ros-coeffs-grazed}

    For eaten-out grasslands, the coefficients are:

    $$ 
    \begin{aligned}
        r_{l0} &= r_{el0} = 0.027, \\ 
        r_{lw} &= r_{elw} = 0.1045, \\ 
        r_{h0} &= r_{eh0} = 0.55, \\ 
        r_{hw} &= r_{ehw} = 0.357
    \end{aligned} 
    $$ {#eq-ros-coeffs-eatenout}

    ::: {.callout-note}
    While @cheney1998 suggested that the rate of spread for the eaten out
    condition be half that of the grazed condition, they only provided an
    equation for the high wind speed condition. The low wind speed condition
    equation was inferred by halving the low wind speed grazed condition
    similarly.
    :::

    #### Curing Factor in the ROS

    The curing factor calculated originally in @cheney1998 has been superseded
    by a new function provided by @cruz2015c. The previous function assumed that
    (i) fire spread would normally not occur at grass curing values less than
    50%, and (ii) the major influence of grass curing on fire spread occurs when
    grass curing is between 70 and 90%. However, @cruz2015c found that
    experimental fires did spread at curing values as low as 21%. The new curing
    equation is:

    $$ 
    \Phi_{C} = \frac{1.036}{1+103.989 e^{-0.0996 (C-20)}} 
    $$ {#eq-curing-factor}

    Where $C$ is the provided grass curing in %.

    ### Implementation Details

    Each of the $r_{xxx}$ coefficients can be overridden by providing the
    coefficients as inputs to this function.

    ### Usage

    ```python 
    rate_of_spread = calc_rate_of_spread(
        dead_fuel_moisture, wind_speed, curing, grass_condition, 
        r_nl0, r_nlw,r_nh0, r_nhw, # all optional 
        r_gl0, r_glw, r_gh0, r_ghw, # all optional
        r_el0, r_elw, r_eh0, r_ehw # all optional
    )
    ```

    ### Parameters

    - **dead_fuel_moisture** (*array_like*) - Dead fuel moisture content (%).
    - **wind_speed** (*array_like*) - Wind speed (km/h).
    - **curing** (*array_like*) - Grass curing (%).
    - **grass_condition** (*array_like*) - Grass condition (3: natural, 2:
        grazed, 1: eaten out).
    - **r_xxx** (*float*) - Coefficients for rate of spread calculation. Default
        values are outlined above.

    ### Returns

    - **rate_of_spread** (*array_like*) - Rate of spread (m/h).
    """
    # check that all grass_conditions are valid
    assert_valid_grass_conditions(grass_condition)

    # calculate fuel moisture factor
    fuel_moisture_factor = calc_fuel_moisture_factor(
        dead_fuel_moisture, wind_speed
    )

    # calculate curing factor using @cruz2015c
    curing_factor = 1.036 / (1 + 103.989 * np.exp(-0.0996 * (curing - 20)))

    # setup nan rate_of_spread of the same shape as wind_speed
    rate_of_spread = np.full(wind_speed.shape, np.nan)

    # calculate rate of spread for natural grasslands and wind speeds below 5
    # km/h (eqn 3.5 in @cheney1998)
    mask = (wind_speed < 5) & (grass_condition == GRASS_CONDITION_NATURAL)
    if np.any(mask):
        rate_of_spread[mask] = M_PER_KM * (
            (r_nl0 + r_nlw * wind_speed[mask])
            * fuel_moisture_factor[mask]
            * curing_factor[mask]
        )

    # calculate rate of spread for natural grasslands and wind speeds above 5
    # km/h (eqn 3.5 in @cheney1998)
    mask = (wind_speed >= 5) & (grass_condition == GRASS_CONDITION_NATURAL)
    if np.any(mask):
        rate_of_spread[mask] = M_PER_KM * (
            (r_nh0 + r_nhw * np.power((wind_speed[mask] - 5), 0.844))
            * fuel_moisture_factor[mask]
            * curing_factor[mask]
        )

    # calculate rate of spread for cut or grazed grasslands and wind speeds
    # below 5 km/h (eqn 3.6 @cheney1998)
    mask = (wind_speed < 5) & (grass_condition == GRASS_CONDITION_GRAZED)
    if np.any(mask):
        rate_of_spread[mask] = M_PER_KM * (
            (r_gl0 + r_glw * wind_speed[mask])
            * fuel_moisture_factor[mask]
            * curing_factor[mask]
        )

    # calculate rate of spread for cut or grazed grasslands and wind speeds
    # above 5 km/h (eqn 3.6 in @cheney1998)

    mask = (wind_speed >= 5) & (grass_condition == GRASS_CONDITION_GRAZED)
    if np.any(mask):
        rate_of_spread[mask] = M_PER_KM * (
            (r_gh0 + r_ghw * np.power((wind_speed[mask] - 5), 0.844))
            * fuel_moisture_factor[mask]
            * curing_factor[mask]
        )

    # calculate rate of spread for eaten-out grasslands and wind speeds below 5
    # km/h (inferred from @cheney1998)
    mask = (wind_speed < 5) & (grass_condition == GRASS_CONDITION_EATENOUT)
    if np.any(mask):
        rate_of_spread[mask] = M_PER_KM * (
            (r_el0 + r_elw * wind_speed[mask])
            * fuel_moisture_factor[mask]
            * curing_factor[mask]
        )

    # calculate rate of spread for eaten-out grasslands and wind speeds above 5
    # km/h (eqn 3.11 in @cheney1998)
    mask = (wind_speed >= 5) & (grass_condition == GRASS_CONDITION_EATENOUT)
    if np.any(mask):
        rate_of_spread[mask] = M_PER_KM * (
            (r_eh0 + r_ehw * np.power((wind_speed[mask] - 5), 0.844))
            * fuel_moisture_factor[mask]
            * curing_factor[mask]
        )

    return rate_of_spread
