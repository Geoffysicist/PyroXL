r"""
Fire behaviour calculations for heathland

## Technical Guide

The AFDRS Heathland (Shrubland) Model is used for temperate shrubland fuels.
Shrubland fuels are most prevalent in Tasmania, covering approx. 7% of the
state. They only influence Fire Weather Area ratings in TAS and WA, but they are
found in all other jurisdictions except NT.

### What is the AFDRS heathland (shrubland) model? {#sec-heathland-model}

The Heathland (Shrubland) model, by @anderson2015, is used for temperate
shrublands and heathlands. It improves upon previous shrubland models by using a
data set from fires in Australia, New Zealand, Europe, and South Africa, and
covers a broader range of species and vegetation structures. Whilst the model
was originally developed for temperate heathlands, it has been extended to
include a wide range of heathland and shrubland structures.

### Inputs and outputs {#sec-inputs}

This model requires input values for 10m wind speed, temperature, relative
humidity, sky, precipitation in the past 48 hours, time since rain or dew
stopped, vegetation height, and whether there is an overstorey (i.e. if the
shrublands are below a woodland) see Figure 1.

### Model behaviour and limitations

This model is most applicable to open shrubland or shrubland within open
woodland and assumes a constant wind reduction to the 10m wind speeds.
Shrublands are a fine (<6mm diameter) fuel that are highly flammable and remain
so for a much longer portion of the year than forest fuels. It has potential for
very rapid growth and high fire intensity, particularly on windy days, however
dangerous conditions in this fuel type may not be reflected in Fire Weather Area
ratings due to its limited geographic extent.

The effect of wind speed on fire spread is approximately linear and the model is
most sensitive to this parameter until fuels reach high levels of moisture.

### Fuel Types {#sec-fuel-types}

#### Heath {#sec-fuel-types-heath}

This sub-fuel consists of shrublands in temperate parts of Australia, including
coastal heathlands, which tend to have a more continuous fuel structure than
those found in arid areas. It includes heathland, tall closed shrubland, low
closed forest and open woodland with a heath understorey. Open woodlands with a
dominant heath understorey are included in the Heath fuel type and not Forest,
as are some low closed forests.
"""

import numpy as np

from . import fire_behaviour_index
from . import fire_danger_rating
from .. import typing as ft
from . import common
from .common import standardize_dataset_variables
from . import mallee_heath
from . import dry_forest

HEAT_CONTENT = 18600  # kJ/kg


# add additional type hints for heathland specific inputs
class HeathlandInputVariables(ft.CommonInputVariables):
    r"""Heathland specific additional input variables"""

    precipitation: ft.precipitation_Array
    time_since_rain: ft.time_since_rain_Array
    time_since_fire: ft.time_since_fire_Array


WF_Heath_Value = float
"""Wind reduction factor (unitless)"""

Fk_total_Value = float
"""Accumulation rate (1/years)"""


class HeathlandFuelParameters(ft.NoFuelParameters):
    r"""Heathland specific fuel parameters"""

    WF_Heath: WF_Heath_Value
    H_el: dry_forest.H_el_Value
    FL_total: ft.FL_total_Value
    Fk_total: Fk_total_Value


def calc_fuel_moisture(
    relative_humidity, air_temperature, precipitation, time_since_rain
):
    r"""
    Calculate fuel moisture content (%).

    ### Technical Guide

    The @cruz2013 mallee-heath and @anderson2015 shrubland models do not include
    fuel availability or rainfall effects in their fuel moisture models and no
    recommendations are made for treatment of these effects on either fuel
    moisture or fuel cover/height. Because these fuel types are expected to
    become flammable more rapidly than a forest fuel type, we used the
    @marsden1999 fuel moisture modifier function originally developed for
    buttongrass. While these fuel types are structurally dissimilar, the
    buttongrass fuel moisture modification function has a response time of 1-2
    days, making it suitable for fuel types with a large near-surface and
    elevated fuel component.

    Dead fuel moisture content is calculated in the AFDRS as a combination of
    two components, $MC_{1}$ and $MC_{2}$, as follows:

    $$
    MC = MC_{1} + MC_{2}
    $$ {#eq-fuel-moisture}

    where the two components are defined as follows (@cruz2015a, @marsden1999):

    $$
    \begin{aligned}
    MC_{1} &= 4.37 + 0.161 RH - 0.1\ (T - 25) - 0.027 RH \mathrm{\Delta}\\
    MC_{2} &= 67.128 (1 - e^{( - 3.132 P)}) e^{( - 0.0858 TSR)}
    \end{aligned}
    $$ {#eq-fuel-moisture-one-two}

    where $RH$ is relative humidity (%), $T$ is temperature (°C), $P$ is
    precipitation in the last 48 hours (mm), $TSR$ is time since rain or dewfall
    stopped (h). 
    
    In addition, $\mathrm{\Delta}$ is the radiation factor, which @cruz2015a
    indicated should be set to 1.0 for sunny days in the period 12:00-17:00
    October to March, and 0.0 otherwise. As the cloud cover is not always known,
    in the AFDRS we instead set $\mathrm{\Delta}$ to be 1.0 if $RH \leq 60\%$,
    and 0.0 otherwise.

    ### Usage

    ```python
    moisture = calc_fuel_moisture(
        relative_humidity, air_temperature, precipitation, time_since_rain
    )
    ```

    ### Parameters

    - **relative_humidity** (*array_like*) - relative humidity (%).
    - **air_temperature** (*array_like*) - air temperature (°C).
    - **precipitation** (*array_like*) - precipitation in the last 48 hours
      (mm).
    - **time_since_rain** (*array_like*) - time since rain or dewfall stopped
        (h).

    ### Returns

    - **fuel_moisture** (*array_like*) - fuel moisture content (%).
    """
    # TODO: why is this function calculating Delta via RH, but mallee_heath does
    # it via time?
    # See https://gitlab.com/afdrs/afdrs-dev/packages/python-packages/fdrs_calcs/-/issues/39

    # set fuel moisture to an nan array of the same shape as relative_humidity
    fuel_moisture = np.full(relative_humidity.shape, np.nan)

    # delta is the radiation factor
    delta = (relative_humidity <= 60).astype(int)

    # calculate fuel moisture components
    fuel_moisture_1 = (
        4.37
        + 0.161 * relative_humidity
        - 0.1 * (air_temperature - 25)
        - 0.027 * relative_humidity * delta
    )
    fuel_moisture_2 = (
        67.128
        * (1 - np.exp(-3.132 * precipitation))
        * np.exp(-0.0858 * time_since_rain)
    )

    # combine and return the fuel moisture components
    return fuel_moisture_1 + fuel_moisture_2


def calc_fuel_load(fuel_load_total_max, time_since_fire, k):
    r"""
    Calculate fuel load accumulated since the last fire

    ### Technical Guide

    The fuel load is calculated using the Olson curves [@olson1963]. These
    curves take a steady_state value (F_{ss}) and an accumulation rate (k) and
    accumulate towards the steady state value based on the time since the fire
    event (t):

    $$
    F = F_{ss} (1 - e^{-kt})
    $$ {#eq-fuel-load}

    where $F$ is the fuel load (t/ha), $F_{ss}$ is the steady state fuel load
    (t/ha), $k$ is the accumulation rate (1/years), and $t$ is the time since
    the fire event (years).

    ### Implementation Details

    This function is just a light wrapper around the
    `common.calc_accumulation_since_fire` function, which is used by multiple
    spread models.

    ### Usage

    ```python
    fuel_load = calc_fuel_load(fuel_load_total_max, time_since_fire, k)
    ```

    ### Parameters

    - **fuel_load_total_max** (*float*) - maximum/steady-state fuel load (t/ha).
    - **time_since_fire** (*array_like*) - time since the fire event (years).
    - **k** (*float*) - accumulation rate (1/years).

    ### Returns

    - **fuel_load** (*array_like*) - fuel load (t/ha).
    """
    return common.calc_accumulation_since_fire(
        time_since_fire, fuel_load_total_max, k
    )


def calc_spread_index(
    wind_speed_10m, dead_fuel_moisture, fuel_height, wind_reduction_factor
):
    r"""
    Calculate spread index.

    ### Technical Guide

    @anderson2015 does not include a spread probability function. Testing during
    the AFDRS Research Prototype project showed that this resulted in
    unrealistically high rates of spread outside of typical wildfire conditions,
    especially when winds are light and/or fuels are moist. Results from
    @cruz2010 indicated that to compensate for this, a rate of spread reduction
    function should be applied.

    To convert from 10 m wind speed to 2 m wind speed a wind reduction factor
    was used, such that $U_2 = WRF * U_{10}$, where $U_2$ is the 2 m wind speed
    and $U_{10}$ is the 10 m wind speed. The wind reduction factors are provided
    in the fuel parameters table by the jurisdictions, but are generally set to:
    
    - $WRF = 0.667$, when shrublands do not have a canopy
    - $WRF = 0.350$, when shrublands are below a woodland

    Using @anderson2015 and @cruz2010 as a frame work, @krix2024 developed
    a logistic regression model for explicitly defining a spread index:

    $$
    \begin{aligned}
    {lin\_preds} &= 2.579 + 0.176 U_{2} + 0.752 H_{el} 
        + 0.149 U_{2} H_{el} - 0.431 MC\\
    {spread\_index} &= \frac{e^{lin\_preds}}{1 + e^{lin\_preds}}
    \end{aligned}
    $$ {#eq-spread-index}

    where $H_{el}$ is the elevated height (m) provided in the fuel parameters
    table, and $MC$ is the dead fuel moisture content (%).

    The calculated spread index will range from 0.0 to 1.0, with 0.0 indicating
    no spread and 1.0 indicating maximum likelihood of spread.

    ### Usage

    ```python
    spread_index = calc_spread_index(
        wind_speed_10m, dead_fuel_moisture, fuel_height, wind_reduction_factor
    )
    ```

    ### Parameters

    - **wind_speed_10m** (*array_like*) - 10 m wind speed (km/h).
    - **dead_fuel_moisture** (*array_like*) - dead fuel moisture content (%).
    - **fuel_height** (*float*) - fuel height (m).
    - **wind_reduction_factor** (*float*) - wind reduction factor.

    ### Returns

    - **spread_index** (*array_like*) - spread index (0.0-1.0)
    """
    # convert wind speed to 2 m
    wind_speed_2m = wind_speed_10m * wind_reduction_factor

    # set coefficients
    intercept_value = 2.5790256049894307
    wind_speed_coefficient = 0.17560873855156325
    fuel_height_coefficient = 0.7524486590283435
    fuel_wind_coefficient = 0.14916661946053977
    moisture_impact_coefficient = -0.43072711156385884

    # calculate the linear predictions
    lin_preds = (
        intercept_value
        + (wind_speed_coefficient * wind_speed_2m)
        + (fuel_height_coefficient * fuel_height)
        + (fuel_wind_coefficient * fuel_height * wind_speed_2m)
        + (moisture_impact_coefficient * dead_fuel_moisture)
    )

    # convert to spread index
    spread_index = np.exp(lin_preds) / (1 + np.exp(lin_preds))

    return spread_index


def calc_rate_of_spread(
    wind_speed,
    fuel_moisture,
    spread_index,
    wind_reduction_factor,
    elevated_height,
):
    r"""
    Calculate rate of spread (m/h).

    ### Technical Guide

    Similar to that done for the spread index in @anderson2015, @krix2024 also
    developed a generic fire spread model for shrublands. This model is based on
    fires from Australia, New Zealand, Spain, Portugal, and South Africa.

    @krix2024 fitted a logistic regression model with a logistic transformation
    to fuel moisture:

    $$
    {logit\_MC} = \ln\left(\frac{MC/100}{1 - (MC/100)}\right)
    $$ {#eq-logit-mc}

    where $MC$ is the dead fuel moisture content (%).

    To then calculate the rate of spread, the following model was used:

    $$
    \begin{aligned}
    {lin\_preds} &= 3.347 + 0.589 \sqrt{U_{2}} + 0.789 logit\_MC
        + 0.415 \ln(H_{el})\\
    {ROS} &= e^{lin\_preds} \times {spread\_index}
    \end{aligned}
    $$ {#eq-rate-of-spread}

    where $U_{2}$ is the 2 m wind speed (km/h), $H_{el}$ is the elevated height
    (m), and $spread\_index$ is the spread index calculated using
    [eq-spread-index].

    As in the spread index calculation, $U_{2}$ is calculated from the 10 m wind
    speed ($U_{10}$) using a wind reduction factor, $WRF$, such that $U_2 = WRF
    * U_{10}$.

    ### Usage

    ```python
    rate_of_spread = calc_rate_of_spread(
        wind_speed, fuel_moisture, spread_index,
        wind_reduction_factor, elevated_height
    )
    ```
    ### Parameters

    - **wind_speed** (*array_like*) - 10 m wind speed (km/h).
    - **fuel_moisture** (*array_like*) - dead fuel moisture content (%).
    - **spread_index** (*array_like*) - spread index (0.0-1.0).
    - **wind_reduction_factor** (*float*) - wind reduction factor.
    - **elevated_height** (*float*) - elevated height (m).

    ### Returns

    - **rate_of_spread** (*array_like*) - rate of spread (m/h).
    """
    # convert wind speed to sqrt(U_2)
    sqrt_wind_speed_2m = np.sqrt(wind_speed * wind_reduction_factor)

    # get the logistic moisture content
    logit_fmc = np.log((fuel_moisture / 100) / (1 - (fuel_moisture / 100)))

    # set coefficients
    intercept_value = 3.3469609211976348
    wind_speed_coefficient = 0.5886615983973722
    moisture_coefficient = -0.788551298241711
    height_coefficient = 0.41499298457549766

    # calculate the linear predictions
    lin_preds = (
        intercept_value
        + (wind_speed_coefficient * sqrt_wind_speed_2m)
        + (moisture_coefficient * logit_fmc)
        + (height_coefficient * np.log(elevated_height))
    )

    # convert to rate of spread, and multiply by the spread index
    rate_of_spread = spread_index * np.exp(lin_preds)

    return rate_of_spread


def calc_intensity(rate_of_spread, fuel_load):
    r"""
    Calculate heathland fireline intensity (kW/m)

    ### Technical Guide

    The fireline intensity is calculated using the @byram1959 equation:

    $$
    I = h \times F \times ROS
    $$ {#eq-intensity}

    where $h$ is the heat yield, assumed here to be 18,600 kJ/kg, $F$ is the
    fuel load in kg/m^2, and $ROS$ is the rate of spread in m/s.

    ### Implementation Details

    This function is just a light wrapper around the
    `common.calc_fire_intensity` function, which is used by multiple fuel
    models.

    ### Usage

    ```python
    intensity = calc_intensity(rate_of_spread, fuel_load)
    ```

    ### Parameters

    - **rate_of_spread** (*array_like*) - rate of spread (m/h).
    - **fuel_load** (*array_like*) - fuel load (t/ha).

    ### Returns

    - **intensity** (*array_like*) - fireline intensity (kW/m).
    """
    # calculate and return the intensity
    return common.calc_fire_intensity(rate_of_spread, fuel_load, HEAT_CONTENT)


def calc_flame_height(intensity):
    r"""
    Calculate flame height (m).

    ### Technical Guide

    No equation for flame height was given by @anderson2015, so this model uses
    the flame height calculations for mallee heath. Refer to that model for more
    information.

    ### Usage

    ```python
    flame_height = calc_flame_height(intensity)
    ```

    ### Parameters

    - **intensity** (*array_like*) - fireline intensity (kW/m).

    ### Returns

    - **flame_height** (*array_like*) - flame height (m).
    """
    return mallee_heath.calc_flame_height(intensity)


def calc_spotting_distance(air_temperature):
    r"""
    Calculate spotting distance (m).

    ### Technical Guide

    A spotting model is not currently implemented for heathland.

    ### Implementation Details

    As a spotting function is not currently implemented for heathland, this
    function just returns an array of NaNs of the same shape as
    `air_temperature`.

    ### Usage

    ```python
    spotting_distance = calc_spotting_distance(air_temperature)
    ```

    ### Parameters

    - **air_temperature** (*array_like*) - air temperature (°C).

    ### Returns

    - **spotting_distance** (*array_like*) - spotting distance (m).
    """
    return np.full(air_temperature.shape, np.nan)


def calculate(
    dataset: HeathlandInputVariables, fuel_parameters: HeathlandFuelParameters
) -> ft.CommonOutputIndices:
    r"""
    Main entry point for healthland fire behaviour calculations.

    ### Usage

    ```python
    indices = calculate(dataset, fuel_parameters)
    ```

    ### Parameters

    - **dataset** (*dict*) - A dictionary of *array_like* containing the input
        variables.

        From these input variables, only the following are used by this model:

        - **T_SFC** - air temperature (°C)
        - **RH_SFC** - relative humidity (%)
        - **WindMagKmh_10m** : Wind magnitude at 10m (km/h)
        - **precipitation** - precipitation in the last 48 hours (mm)
        - **time_since_rain** - time since rain or dewfall (h)
        - **time_since_fire** - time since the fire event (years)

    - **fuel_parameters** A dictionary of scalars containing the fuel
      parameters.

        From these fuel parameters, only the following are used by this model:

        - **WF_Heath** - wind reduction factor (unitless)
        - **H_el** - elevated height (m)
        - **FL_total** - maximum/steady-state fuel load (t/ha)
        - **Fk_total** - accumulation rate (1/years)

    ### Returns

    - **indices** (*dict*) - A dictionary of *array_like* containing the
        output variables of the same shape as the input variables with the
        following keys:

        - **dead_fuel_moisture** - dead fuel moisture content (%)
        - **rate_of_spread** - rate of spread (m/h)
        - **flame_height** - flame height (m)
        - **intensity** - fireline intensity (kW/m)
        - **spotting_distance** - spotting distance (m)
        - **rating_1** - fire danger rating (unitless)
        - **index_1** - fire behaviour index (unitless)
    """
    # standardize the dataset variables
    dataset = standardize_dataset_variables(dataset)

    # calculate the dead fuel moisture
    dead_fuel_moisture = calc_fuel_moisture(
        dataset["RH_SFC"],
        dataset["T_SFC"],
        dataset["precipitation"],
        dataset["time_since_rain"],
    )

    # calculate the spread index
    spread_index = calc_spread_index(
        dataset["WindMagKmh_10m"],
        dead_fuel_moisture,
        fuel_parameters["H_el"],
        fuel_parameters["WF_Heath"],
    )

    # calculate the rate of spread
    rate_of_spread = calc_rate_of_spread(
        dataset["WindMagKmh_10m"],
        dead_fuel_moisture,
        spread_index,
        fuel_parameters["WF_Heath"],
        fuel_parameters["H_el"],
    )

    # calculate the fuel load
    fuel_load = calc_fuel_load(
        fuel_parameters["FL_total"],
        dataset["time_since_fire"],
        fuel_parameters["Fk_total"],
    )

    # calculate the intensity
    intensity = calc_intensity(rate_of_spread, fuel_load)

    # calculate the flame height
    flame_height = calc_flame_height(intensity)

    # calculate the spotting distance
    spotting_distance = calc_spotting_distance(dataset["T_SFC"])

    # calculate the fire behaviour index and fire danger rating from the rate of
    # spread only
    index_1 = fire_behaviour_index.heathland(rate_of_spread)
    rating_1 = fire_danger_rating.fire_danger_rating(index_1)

    return {
        "dead_fuel_moisture": dead_fuel_moisture,
        "rate_of_spread": rate_of_spread,
        "flame_height": flame_height,
        "intensity": intensity,
        "spotting_distance": spotting_distance,
        "rating_1": rating_1,
        "index_1": index_1,
    }
