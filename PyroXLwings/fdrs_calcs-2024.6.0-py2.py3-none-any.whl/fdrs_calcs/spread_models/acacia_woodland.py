r"""
Fire behaviour calculations for acacia_woodland

## Technical Guide

This fuel sub-type is defined as arid acacia woodlands or shrublands (such as
mulga), and similar vegetations (such as casuarina or eucalypts) where there is
little ground fuel except for chenopod (saltbush) shrubs and herbaceous plants,
with ephemeral grass occurring only after sufficient rain. There is no dedicated
fire spread model for acacia woodlands/shrublands; both savanna and mallee heath
were considered, and both were deemed likely to over-predict fire behaviour.
This sub-fuel uses the eaten-out grass condition.
"""

from typing import Annotated
import numpy as np

from . import fire_behaviour_index
from . import fire_danger_rating
from .. import typing as ft
from .common import standardize_dataset_variables

from .csiro_grassland import calc_fuel_moisture
from .csiro_grassland import calc_rate_of_spread
from .csiro_grassland import calc_flame_height
from .csiro_grassland import calc_intensity
from .csiro_grassland import calc_spotting_distance
from .csiro_grassland import GRASS_CONDITION_EATENOUT

from .savanna import SavannaFuelParameters as AcaciaWoodlandFuelParameters


# add additional type hints for acacia_woodland specific inputs
class AcaciaWoodlandInputVariables(ft.CommonInputVariables):
    r"""Acacia Woodland specific additional input variables"""

    grass_condition: ft.grass_condition_Array
    GrassFuelLoad_SFC: ft.GrassFuelLoad_SFC_Array
    Curing_SFC: ft.Curing_SFC_Array


def calculate(
    dataset: AcaciaWoodlandInputVariables,
    fuel_parameters: AcaciaWoodlandFuelParameters,
) -> ft.CommonOutputIndices:
    r"""
    Main entry point for Acacia Woodland fire behaviour calculations.

    ### Implementation Details

    Implemented using the CSIRO Grassland Fire Spread Model, with the following
    modifications:

    - The grass condition is set to `GRASS_CONDITION_EATENOUT`
    - A provided wind reduction factor (`WF_Sav`) is applied to the calculated
      rate of spread

    ### Usage

    ```python
    indices = acacia_woodland.calculate(dataset, fuel_parameters)
    ```

    ### Parameters

    - **dataset** (*dict*) - A dictionary of *array_like* containing the input
        variables.

        From these input variables, only the following are used by this model

        - **T_SFC** : Surface temperature (C)
        - **RH_SFC** : Relative humidity (%)
        - **WindMagKmh_10m** : Wind magnitude at 10m (km/h)
        - **Curing_SFC** : Fuel curing (%)
        - **GrassFuelLoad_SFC** : Grass fuel load (t/ha)

    - **fuel_parameters** A dictionary of scalars containing the fuel
      parameters.

        For this model the following parameters are used

        - **WF_Sav** : Wind reduction factor (unitless)

    ### Returns

    - **indices** (*dict*) - A dictionary of *array_like* containing the output
        variables of the same shape as the input arrays with the following keys

        - **dead_fuel_moisture** : Dead fuel moisture content (%)
        - **rate_of_spread** : Rate of spread (m/hr)
        - **flame_height** : Flame height (m)
        - **intensity** : Fire intensity (kW/m)
        - **spotting_distance** : Spotting distance (m)
        - **rating_1** : Fire danger rating (unitless)
        - **index_1** : Fire behaviour index (unitless)
    """
    # standardize the dataset variables
    dataset = standardize_dataset_variables(dataset)

    # Calculate dead fuel moisture content
    dead_fuel_moisture = calc_fuel_moisture(dataset["T_SFC"], dataset["RH_SFC"])

    # Calculate rate of spread using a modified CSIRO grassland model, assuming
    # the grass condition is best represented as eaten out. Also multiply by the
    # wind reduction factor (WF_Sav) to account for the reduced wind speed due
    # to the presence of trees.
    rate_of_spread = calc_rate_of_spread(
        dead_fuel_moisture,
        dataset["WindMagKmh_10m"],
        dataset["Curing_SFC"],
        np.full(dataset["WindMagKmh_10m"].shape, GRASS_CONDITION_EATENOUT),
    )
    rate_of_spread = rate_of_spread * fuel_parameters["WF_Sav"]

    # calculate the flame height from the rate of spread using the CSIRO
    # grassland model. However, for acacia_woodland, we set the grass condition
    # to eaten out.
    flame_height = calc_flame_height(
        rate_of_spread, np.full(rate_of_spread.shape, GRASS_CONDITION_EATENOUT)
    )

    # calculate the fire intensity from the rate of spread and grass fuel load
    intensity = calc_intensity(rate_of_spread, dataset["GrassFuelLoad_SFC"])

    # calculate the spotting distance from the surface temperature
    spotting_distance = calc_spotting_distance(dataset["T_SFC"])

    # calculate the fire behaviour index and fire danger rating
    index_1 = fire_behaviour_index.grass(intensity)
    rating_1 = fire_danger_rating.fire_danger_rating(index_1)

    # return the outputs
    return {
        "dead_fuel_moisture": dead_fuel_moisture,
        "rate_of_spread": rate_of_spread,
        "flame_height": flame_height,
        "intensity": intensity,
        "spotting_distance": spotting_distance,
        "rating_1": rating_1,
        "index_1": index_1,
    }
