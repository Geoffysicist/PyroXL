r"""
Fire behaviour calculations for wet forests

## Technical Guide

This sub-fuel type is classified as forests with high moisture content due to
the forest structure, topography, or inundation. Some examples include
rainforest, wet sclerophyll forest, and swamp forest. The fuel structure of wet
sclerophyll forest, rainforest, and forested wetlands is most like a litter and
shrub dominated forest. Hardwood plantations have been classified to wet forest
as the canopy species are most commonly the tall eucalypt species typical of wet
sclerophyll forests. However, the understorey fuel structure in these plantation
forests is highly modified and varies with differing management practices.

Different forest types will display different fire behaviour. The composition,
structure and moisture content of the forest, as well as the exposure to the
elements, play a role in this. "Wet forests", such as rain forests, wet
sclerophyll forests and swamp forests have a limited fuel availability for
fires, because of the high moisture content in these fuels. Since fire behaviour
models have not been developed for these specific fuel types (apart from the Red
book, for Karri forests, @sneeuwjagt1998) the AFDRS uses Vesta with a wind
reduction and a drought factor modifier.

::: {.callout-note}
Only a single drought factor modification has been applied across all wet forest
types, however there are likely to be significant differences in fuel
availability between rainforest, wet sclerophyll forest, and forested wetlands. 
:::
"""

import numpy as np

from . import fire_behaviour_index
from . import fire_danger_rating
from .common import standardize_dataset_variables
from .. import typing as ft

from .dry_forest import calc_flame_height
from .dry_forest import calc_spotting_distance
from .dry_forest import fuel_moisture_model as base_fuel_moisture_model
from .dry_forest import calc_rate_of_spread as base_calc_rate_of_spread
from .dry_forest import calc_intensity as base_calc_intensity
from . import dry_forest


# add additional type hints for wet forest specific inputs
class WetForestInputVariables(dry_forest.DryForestInputVariables):
    r"""Wet Forest specific additional input variables"""

    drought_index: ft.drought_index_Array


def fuel_availability(drought_factor, drought_index, WRF):
    r"""
    Calculate fuel availability for wet forest

    ### Technical Guide

    For wet forests, the fraction of fuel available for combustion
    $Fuel\_availablity$ (wet) uses the drought index (KBDI/SDI) and McArthur
    Drought Factor ($DF$) based on the Vesta Mk2 fuel availability (@cruz2021)
    to first calculate the stand structure adjustment ($C_1$):

    $$
    C_1 = 0.1 \left(
        DI \left( 0.0046 WRF^{2} - 0.0079 WRF - 0.0175 \right)
        - 0.9167 WRF^2 + 1.5833 WRF + 13.5
    \right)
    $$ {#eq-fuel-availability-modifier}

    Where $DI$ is the drought index (KBDI/SDI, 0-203.2 mm), and $WRF$ is the
    wind reduction factor (3 or 5). The stand structure adjustment is then
    clipped to the range 0 to 1 and used to calculate the fuel availability:

    $$
    Fuel\_ availability = \ \frac{1.008}{1 + 104.9e^{- 0.9306 DF \times C_1}}
    $$ {#eq-fuel-availability-modified}

    ### Usage

    ```python
    fuel_availability = fuel_availability(
        drought_factor, drought_index, WRF
    )
    ```

    ### Parameters

    - **drought_factor** (*array-like*) - drought factor (0-10, unitless)
    - **drought_index** (*array-like*) - either SDI or KBDI (0-203.2, mm)
    - **WRF** (*array-like*) - wind reduction factor

    ### Returns

    - **fuel_availability** (*array-like*) - fuel availability (0.0-1.0)
    """
    # Calculate stand structure adjustment
    C1 = 0.1 * (
        (0.0046 * np.power(WRF, 2) - 0.0079 * WRF - 0.0175) * drought_index
        + (-0.9167 * np.power(WRF, 2) + 1.5833 * WRF + 13.5)
    )
    C1 = np.clip(C1, 0, 1)

    # Calculate fuel availability using stand structure adjustment
    fuel_availability = 1.008 / (
        1 + 104.9 * np.exp(-0.9306 * drought_factor * C1)
    )

    return fuel_availability


def fuel_moisture_model(air_temperature, relative_humidity, time):
    r"""Calculate dead fuel moisture (%)

    ### Technical Guide

    The dead fuel moisture model for wet forests is the same as for dry forests
    except that the sunny afternoon condition is not used. Refer to the dry
    forest fuel moisture model for more details.

    ### Usage

    ```python
    dead_fuel_moisture = fuel_moisture_model(
        air_temperature, relative_humidity, time
    )
    ```

    ### Parameters

    - **air_temperature** (*array-like*) - air temperature (°C)
    - **relative_humidity** (*array-like*) - relative humidity (%)
    - **time** (*tuple*) - tuple of (month, hour) of the day

    ### Returns

    - **dead_fuel_moisture** (*array-like*) - dead fuel moisture (%)
    """
    return base_fuel_moisture_model(
        air_temperature, relative_humidity, time, wet_forest=True
    )


def calc_rate_of_spread(
    fuel_moisture,
    wind_speed,
    drought_factor,
    drought_index,
    time_since_fire,
    FHS_s,
    FHS_ns,
    H_ns,
    Fk_s,
    Fk_ns,
    Hk_ns,
    wind_reduction_factor,
):
    r"""Calculate rate of spread in m/h

    ### Technical Guide

    The rate of spread model for wet forests is the same as for dry forests
    except that a fuel modifier based on the drought factor, drought index
    (KBDI/SDI) and a wind reduction factor is used instead of the simpler
    approach for dry forests. Refer to the fuel availability calculation for
    more details on the wet forest fuel availability calculations, and to the
    dry forest rate of spread model for more details on the rate of spread
    calculations.

    ### Usage

    ```python
    rate_of_spread = calc_rate_of_spread(
        fuel_moisture, wind_speed,
        drought_factor, drought_index, time_since_fire,
        FHS_s, FHS_ns, H_ns,
        Fk_s, Fk_ns, Hk_ns,
        wind_reduction_factor
    )
    ```

    ### Parameters

    - **fuel_moisture** (*array-like*) - dead fuel moisture (%)
    - **wind_speed** (*array-like*) - wind speed (km/h)
    - **drought_factor** (*array-like*) - drought factor (0-10, unitless)
    - **drought_index** (*array-like*) - either SDI or KBDI (0-203.2, mm)
    - **time_since_fire** (*array-like*) - time since fire (years)
    - **FHS_s** (*float*) - steady-state surface fuel hazard score (0-4)
    - **FHS_ns** (*float*) - steady-state near-surface fuel hazard score (0-4)
    - **H_ns** (*float*) - steady-state near-surface fuel height (cm)
    - **Fk_s** (*float*) - surface fuel accumulation rate (1/year)
    - **Fk_ns** (*float*) - near-surface fuel accumulation rate (1/year)
    - **Hk_ns** (*float*) - near-surface fuel height accumulation rate (m/year)
    - **wind_reduction_factor** (*float*) - wind reduction factor

    ### Returns

    - **rate_of_spread** (*array-like*) - rate of spread (m/h)
    """
    # calculate fuel modifier for wet forests
    fuel_modifier = fuel_availability(
        drought_factor, drought_index, wind_reduction_factor
    )

    # use the dry forest rate of spread model, but with the fuel modifier
    rate_of_spread = base_calc_rate_of_spread(
        fuel_moisture,
        wind_speed,
        drought_factor,
        time_since_fire,
        FHS_s,
        FHS_ns,
        H_ns,
        Fk_s,
        Fk_ns,
        Hk_ns,
        wind_reduction_factor,
        fuel_modifier,
    )

    return rate_of_spread


def calc_intensity(
    drought_factor,
    drought_index,
    time_since_fire,
    flame_height,
    rate_of_spread,
    FL_s,
    FL_ns,
    FL_el,
    FL_b,
    FL_o,
    H_o,
    Fk_s,
    Fk_ns,
    Fk_el,
    Fk_b,
    wind_reduction_factor,
):
    r"""Calculate fireline intensity (kW/m)

    ### Technical Guide

    The intensity model for wet forests is the same as for dry forests except
    that a fuel modifier based on the drought factor, drought index (KBDI/SDI)
    and a wind reduction factor is used instead of the simpler approach for dry
    forests. Refer to the fuel availability calculation for more details on the
    wet forest fuel availability calculations, and to the dry forest intensity
    model for more details on the intensity calculations.

    ### Usage

    ```python
    intensity = calc_intensity(
        drought_factor, drought_index, time_since_fire,
        flame_height, rate_of_spread,
        FL_s, FL_ns, FL_el, FL_b, FL_o, H_o,
        Fk_s, Fk_ns, Fk_el, Fk_b,
        wind_reduction_factor
    )
    ```

    ### Parameters

    - **drought_factor** (*array-like*) - drought factor (0-10, unitless)
    - **drought_index** (*array-like*) - either SDI or KBDI (0-203.2, mm)
    - **time_since_fire** (*array-like*) - time since fire (years)
    - **flame_height** (*array-like*) - flame height (m)
    - **rate_of_spread** (*array-like*) - rate of spread (m/h)
    - **FL_s** (*float*) - steady-state surface fuel load (t/ha)
    - **FL_ns** (*float*) - steady-state near-surface fuel load (t/ha)
    - **FL_el** (*float*) - steady-state elevated fuel load (t/ha)
    - **FL_b** (*float*) - steady-state bark fuel load (t/ha)
    - **FL_o** (*float*) - steady-state canopy fuel load (t/ha)
    - **H_o** (*float*) - canopy height (m)
    - **Fk_s** (*float*) - surface fuel accumulation rate (1/year)
    - **Fk_ns** (*float*) - near-surface fuel accumulation rate (1/year)
    - **Fk_el** (*float*) - elevated fuel accumulation rate (1/year)
    - **Fk_b** (*float*) - bark fuel accumulation rate (1/year)
    - **wind_reduction_factor** (*float*) - wind reduction factor

    ### Returns

    - **intensity** (*array-like*) - fireline intensity (kW/m)
    """
    # calculate fuel modifier for wet forests
    fuel_modifier = fuel_availability(
        drought_factor, drought_index, wind_reduction_factor
    )

    # use the dry forest intensity model, but with the fuel modifier
    intensity = base_calc_intensity(
        drought_factor,
        time_since_fire,
        flame_height,
        rate_of_spread,
        FL_s,
        FL_ns,
        FL_el,
        FL_b,
        FL_o,
        H_o,
        Fk_s,
        Fk_ns,
        Fk_el,
        Fk_b,
        fuel_modifier,
    )

    return intensity


def calculate(
    dataset: WetForestInputVariables,
    fuel_parameters: dry_forest.DryForestFuelParameters,
) -> ft.CommonOutputIndices:
    r"""
    Main entry point for calculating fire behaviour for wet forests.

    ### Usage

    ```python
    indices = calculate(dataset, fuel_parameters)
    ```

    ### Parameters

    - **dataset** (*dict*) - A dictionary of *array_like* containing the input
        variables.

        From these input variables, the following are used by this model:

        - **T_SFC** - air temperature (°C)
        - **RH_SFC** - relative humidity (%)
        - **WindMagKmh_10m** : Wind magnitude at 10m (km/h)
        - **DF_SFC** - drought factor (0-10, unitless)
        - **drought_index** - either SDI or KBDI (0-203.2, mm)
        - **time_since_fire** - time since fire (years)
        - **months** - month of the year (1-12)
        - **hours** - hour of the day (0-23)

    - **fuel_parameters** A dictionary of scalars containing the fuel
      parameters.

        From these fuel parameters, the following are used by this model:

        - **FHS_s** - steady-state surface fuel hazard score (0-4)
        - **FHS_ns** - steady-state near-surface fuel hazard score (0-4)
        - **H_ns** - steady-state near-surface fuel height (cm)
        - **Fk_s** - surface fuel accumulation rate (1/year)
        - **Fk_ns** - near-surface fuel accumulation rate (1/year)
        - **Hk_ns** - near-surface fuel height accumulation rate (m/year)
        - **FL_s** - steady-state surface fuel load (t/ha)
        - **FL_ns** - steady-state near-surface fuel load (t/ha)
        - **FL_el** - steady-state elevated fuel load (t/ha)
        - **FL_b** - steady-state bark fuel load (t/ha)
        - **FL_o** - steady-state canopy fuel load (t/ha)
        - **H_o** - canopy height (m)
        - **H_el** - elevated fuel height (m)
        - **Fk_el** - elevated fuel accumulation rate (1/year)
        - **Fk_b** - bark fuel accumulation rate (1/year)
        - **WRF_For** - wind reduction factor

    ### Returns

    - **indices** (*dict*) - A dictionary of *array_like* containing the
        output variables of the same shape as the input arrays with the
        following keys:

        - **dead_fuel_moisture** - dead fuel moisture (%)
        - **rate_of_spread** - rate of spread (m/h)
        - **flame_height** - flame height (m)
        - **intensity** - fireline intensity (kW/m)
        - **spotting_distance** - spotting distance (m)
        - **rating_1** - fire danger rating (unitless)
        - **index_1** - fire behaviour index (unitless)
    """
    # standardize the dataset variables
    dataset = standardize_dataset_variables(dataset)

    # Calculate the dead fuel moisture
    dead_fuel_moisture = fuel_moisture_model(
        dataset["T_SFC"],
        dataset["RH_SFC"],
        (dataset["months"], dataset["hours"]),
    )

    # Calculate the rate of spread
    rate_of_spread = calc_rate_of_spread(
        dead_fuel_moisture,
        dataset["WindMagKmh_10m"],
        dataset["DF_SFC"],
        dataset["drought_index"],
        dataset["time_since_fire"],
        fuel_parameters["FHS_s"],
        fuel_parameters["FHS_ns"],
        fuel_parameters["H_ns"],
        fuel_parameters["Fk_s"],
        fuel_parameters["Fk_ns"],
        fuel_parameters["Hk_ns"],
        fuel_parameters["WRF_For"],
    )

    # Calculate the flame height
    flame_height = calc_flame_height(rate_of_spread, fuel_parameters["H_el"])

    # Calculate the fire intensity
    intensity = calc_intensity(
        dataset["DF_SFC"],
        dataset["drought_index"],
        dataset["time_since_fire"],
        flame_height,
        rate_of_spread,
        fuel_parameters["FL_s"],
        fuel_parameters["FL_ns"],
        fuel_parameters["FL_el"],
        fuel_parameters["FL_b"],
        fuel_parameters["FL_o"],
        fuel_parameters["H_o"],
        fuel_parameters["Fk_s"],
        fuel_parameters["Fk_ns"],
        fuel_parameters["Fk_el"],
        fuel_parameters["Fk_b"],
        fuel_parameters["WRF_For"],
    )

    # Calculate the spotting distance
    spotting_distance = calc_spotting_distance(
        rate_of_spread,
        dataset["WindMagKmh_10m"],
        fuel_parameters["FHS_s"],
    )

    # calculate the fire behaviour index and fire danger rating from the
    # intensity only
    index_1 = fire_behaviour_index.forest(intensity)
    rating_1 = fire_danger_rating.fire_danger_rating(index_1)

    return {
        "dead_fuel_moisture": dead_fuel_moisture,
        "rate_of_spread": rate_of_spread,
        "flame_height": flame_height,
        "intensity": intensity,
        "spotting_distance": spotting_distance,
        "rating_1": rating_1,
        "index_1": index_1,
    }
