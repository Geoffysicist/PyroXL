r"""
Fire Danger Rating (FDR) conversion from Fire Behaviour Index (FBI)

## Technical Guide

For fire danger rating a simple threshold is applied, using the FBI
thresholds of 12, 24, 50 and 100. The same table is used for all fuel
types:

| FBI range          | Fire Danger Rating | Colour           |
| ------------------ | ------------------ | ---------------- |
| [0 - 11]{.fdrno}   | No rating          | \fdrno{}  White  |
| [12 - 23]{.fdrmod} | Moderate           | \fdrmod{} Green  |
| [24 - 49]{.fdrhi}  | High               | \fdrhi{}  Yellow |
| [50 - 99]{.fdrex}  | Extreme            | \fdrex{}  Orange |
| [100 +]{.fdrcat}   | Catastrophic       | \fdrcat{} Red    |

: Fire Behaviour Index ranges, Fire Danger Ratings, and their associated colour
    {#tbl-fbi-fdr-ranges}
"""
import numpy as np


def fire_danger_rating(fire_behaviour_index):

    r"""
    Calculate fire danger rating from fire behaviour index

    ### Usage

    ```python
    fire_danger_rating = fire_danger_rating(fire_behaviour_index)
    ```

    ### Parameters

    - **fire_behaviour_index** (*array_like*) - Fire Behaviour Index 
        (dimensionless)

    ### Returns

    - **fire_danger_rating** (*array_like*) - Fire danger rating (dimensionless)

    ### Notes

    The following 'round numbers' are used for all fuel types in converting FBI 
    to FDR:

    - 0 to 12 : No Rating (FDR = 0)
    - 12 to 24 : Moderate (FDR = 1)
    - 24 to 50 : High (FDR = 2)
    - 50 to 100 : Extreme (FDR = 3)
    - 100+ : Catastrophic (FDR = 4)
    """
    # setup rating array of same size as FBI
    rating = np.full(fire_behaviour_index.shape, np.nan)

    # assign ratings based on FBI thresholds
    rating[fire_behaviour_index >= 100] = 4 # Catastrophic
    rating[fire_behaviour_index < 100] = 3 # Extreme
    rating[fire_behaviour_index < 50] = 2 # High
    rating[fire_behaviour_index < 24] = 1 # Moderate
    rating[fire_behaviour_index < 12] = 0 # No rating

    return rating
