from warnings import warn

# deprecated version of savanna.py

# raise a depreciation warning
warn(
    "The `fdrs_calcs.spread_models.savannah` module is deprecated and will be "
    "removed in a future release. Please use "
    " `fdrs_calcs.spread_models.savanna` instead.",
    DeprecationWarning,
)

from .savanna import *
