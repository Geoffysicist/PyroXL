r"""
Fire behaviour model implementations

## Technical Guide

In Australia, over 60 years of scientific research has produced numerous fire
behaviour models. As fires spread and behave differently in different fuels,
specific models have been built for major fuel types; e.g. grasslands, forests
and shrublands [@cruz2015a]. Over time, fire behaviour models for certain fuel
types have been revised or adjusted, and new models have been developed for
specific conditions or fuel types that were not explicitly described before
(e.g. pine plantations). For some fuel types, multiple models have been
developed (e.g. dry eucalypt forest models have been developed by @mcarthur1967,
@mcarthur1973, and @cheney2012).

In general, all fire behaviour models use some kind of weather input (e.g. wind
speed), fuel moisture content (as a function of relative humidity and air
temperature), and fuel information. Some models require more specific input such
as grassland curing (@cheney1998; @cruz2015b), or fuel strata characteristics
such as Fuel Hazard Scores or Fuel Hazard Ratings (@cheney2012). As outputs, all
fire behaviour models provide a measure of rate of spread (m/hr), and some
provide a measure of spotting (m) or flame height/length (m). Another measure we
are taking into account is fireline intensity (kW/m), as described and
discussed by @byram1959.

@tbl-fbm-ref provides an overview of the fire behaviour models that are
currently included in the AFDRS, initially constructed in consultation with
well-established fire researchers at the science workshop at NSW RFS
headquarters on 07/06/2017, then developed further over time by the AFDRS
Science Team with ongoing consultation with predictive services staff within
fire and land management agencies. The selected models and their characteristics
are further discussed in the specific model section of this Technical Guide.

+-----------------------+-------------+-----------------+----------------------+
| Fire behaviour model  | Short name  | References      |  Fuel type           |
+=======================+=============+=================+======================+
| CSIRO Grassland fire  | Grassland   | @cheney1998,    | Continuous           |
| spread meter          |             | @cruz2015b      | grasslands           |
+-----------------------+-------------+-----------------+----------------------+
| CSIRO Grassland for   | Savanna     | @cheney1998     | Grassy woodlands and |
| northern Australia    |             | @cruz2015b      | open forests         |
+-----------------------+-------------+-----------------+----------------------+
| Desert spinifex model | Spinifex    | @holmes2023     | Hummock grasslands   |
+-----------------------+-------------+-----------------+----------------------+
| Buttongrass moorlands | Buttongrass | @marsden1995b   | Buttongrass          |
| model                 |             |                 | moorlands            |
+-----------------------+-------------+-----------------+----------------------+
| Dry Eucalypt Forest   | Vesta       | @cheney2012     | Shrubby dry eucalypt |
| Fire Model (DEFFM or  |             |                 | forests              |
| "Vesta")              |             |                 |                      |
+-----------------------+-------------+-----------------+----------------------+
| Mallee heath model    | Mallee      | @cruz2013       | Semi-arid mallee     |
|                       | heath       |                 | heath                |
+-----------------------+-------------+-----------------+----------------------+
| Heathland (Shrubland) | Shrubland   | @anderson2015   | Temperate shrublands |         
| model                 |             |                 |                      |
+-----------------------+-------------+-----------------+----------------------+
| Adjusted Pine model   | Pine        | @cruz2015a      | Pine plantations     |
+-----------------------+-------------+-----------------+----------------------+

: Fire Behaviour Models and their associated references 
    {#tbl-fbm-ref .striped .hover}

All models have their own limitations and assumptions. These are more
extensively described in the original papers and summarised in @cruz2015a.
Operationalisation of the fire behaviour models for the purpose of fire danger
ratings required decisions and consideration of the models and input to enable
use within the AFDRS. These decisions and considerations are described in more
detail in the relevant sections below.

However, there remain fuel types for which fire behaviour models have not (yet)
been developed (e.g. rainforests, arid shrublands, wetlands), as they are
generally less flammable than the fuel types provided in @tbl-fbm-ref. In
addition, human influenced fuel types such as crops and horticultural fields, or
rural and (semi-) urban areas lack specific fire behaviour models, and are
typically assigned to the model with the most similar fuel structure.

### Measures of fire behaviour

In addition to reporting the **fire behaviour index** and **fire danger
rating**, all fire behaviour models produce **rate of spread** (m/hr) as their
primary non-index output. In all cases rate of spread is a function of:

- Wind speed;

- Fuel moisture, either as an explicit variable calculated using a sub-model, or
  implicitly through the inclusion of air temperature and humidity in the model;
  and

- Fuel parameter(s).

Other derived output variables, which are available in the AFDRS, are:

- **Flame height** (m), most commonly modelled as a function of rate of spread
  and a fuel parameter (e.g. fuel load, or fuel height), or back-calculated from
  fireline intensity.

- **Fireline intensity**, calculated from rate of spread and fuel load
  [@byram1959].

- **Spotting distance**, for forest fuel types only, taking wind speed,
  estimated rate of spread and surface fuel hazard scores into account.

Given these relationships, it is expected that all four output variables, i.e.
rate of spread, flame height, fireline intensity and spotting distance, are
correlated. However, because flame dimensions and intensity are effectively
including fuel parameters 'twice' in their calculation, they are more sensitive
to these fuel parameters. 

#### Integral measures of fire danger

'Power of fire' is a measure of the rate of energy release from a fire,
calculated as the integral of intensity around the perimeter of a fire, or as
the rate of area growth multiplied by fuel load [@harris2012]. Empirical studies
[@harris2012] have shown power of fire for historical events to be well
correlated with the *magnitude* of house loss, much better than FFDI or similar
measures. While power of fire is a useful measure of the magnitude of a given
fire (similar to cyclone categories) it is not suitable for use in the AFDRS
because power of fire combines the size and intensity of a fire. For a fire
danger rating system, there is no information on the size of potential fires.
During the 2015-16 NSW FDR trial, an attempt was made to estimate the power of
fires by simulating the ignition of fires at hourly intervals and allowing them
to grow for a prescribed, arbitrary amount of time. These calculations were
dominated by grass fires which had high rates of spread, outweighing their low
fuel load relative to forests. If power was normalised to remove size, then it
reverts to intensity. Further research can and should question the relative
merits of intensity and power as predictors of house loss.

It has been anecdotally observed that days with longer periods of elevated FDR
are more dangerous than those with short peaks. This could be encapsulated in a
fire danger rating that combines both the peak FDR and time above some threshold
as an integral measure, similar to the 'hours above X' product currently
produced. While this approach has some merit it must be used with care as it has
the potential to introduce degeneracy into the rating system, e.g. same rating
for short Severe peak and long Very High peak, further compounding the issue of
days with high wind speed and low temperature vs low wind speed and high
temperatures. Research by @plucinski2020 using a variety of FFDI measures showed
that daily maximum fire danger is most useful.

#### Other measure of fire behaviour and potential

The behaviour of the head fire is the core of the fire behaviour index and
rating. However, this is not the whole story. Other things which contribute to
fire danger are:

- **Atmospheric stability**. If the atmosphere is unstable, or could be with the
  addition of heat, then fires which become large enough to interact with the
  upper atmosphere are potential more dangerous because they may draw down
  dry-windy air from aloft, form pyrocumulus clouds, etc. The most readily
  available measure of instability is the CHaines index (@mills2010). While
  CHaines has some limitations (e.g. where the mixed layer is very deep both
  levels used in calculation of CHaines may be in the mixed layer) it has proved
  to be useful. It is to be expected that CHaines would affect fire danger
  rating only at the upper range of the driving fire behaviour metric (e.g.
  intensity, flame height), since it is only under these conditions that fires
  are able to grow large enough and output sufficient heat to become coupled
  with the upper atmosphere. For the AFDRS, CHaines was included in the AFDRS as
  a 'weather alert' warning only. A flag was forecast at a point if the daily
  maximum CHaines exceeded the climatological 95^th^ percentile value. A flag
  was forecast for a fire weather area if at least 10% of its areas exceeded the
  95% percentile values. In future CHaines may be replaces with a more accurate
  PyroCb outlook product (@tory2021).

- **Spotting**. Short and long-distance spotting contributes to both the
  difficulty of suppression and potential to damage assets of fires burning in
  forests. Bark characteristics derived from fuel type maps, and spotting models
  will be used where there is significant spotting potential. Spotting is a
  local phenomenon linked to areas of forest with both bark fuels and
  sufficiently high fire behaviour conditions. As such, spotting was not
  incorporated directly into the AFDRS but is included in the outputs by
  displaying the 90^th^ percentile value on the static daily ratings web page
  for fire weather areas that included forest.

- **Wind change**. Wind changes can be associated with increased fire danger
  through two mechanisms: instability in the vicinity of the change, and
  dramatic increases in fire size where the flank of an existing fire becomes
  the head fire. This behaviour has been associated with some of the most
  significant fire events in Australia (@cruz2012). While wind changes may have
  complex and varied structure, @huang2006 have developed a wind change danger
  index which summarises various characteristics of changes into a single index.
  The Wind Change Danger Index (WCDI) will be used to highlight where wind
  information warrants closer inspection through other means (such as forecast
  weather grids, MetEye, or Wind Change Forecasts). The Wind Change Danger Index
  is a combination of the Wind Change Strength Index (WCSI) and the Wind Change
  Rate Index (WCRI) and gives an indication of the strength, speed, and
  sharpness of a wind change. The largest values of WCDI are achieved when there
  is both a rapid direction change and a strong synoptic (direction + speed)
  change. This index is included in the AFDRS as an index and as a weather alert
  both for individual grid cells where the index exceeded 40, and for fire
  weather areas where at least 10% of the area exceeded 40. Further information
  can found in the [BoM AFDRS Wind Change Danger Index
  Documentation.]
  (https://www.afac.com.au/initiative/afdrs/article/wind-change-danger-index-guide)

### Modifiers of fire behaviour

#### Drought and fuel availability

Dead fuel moisture is an important determinant of the potential for fires to
start and spread (@matthews2014). Two main approaches have been used including
the effect of rainfall on operational fire spread models: increasing moisture
content above the fibre saturation point, such as by @marsden1995a, or reducing
the amount of fuel available to burn e.g. such as in the McArthur drought factor 
[@noble1980].

Live fuel fraction is also important for some fuel types, notably grasslands
(@cruz2015c) and spinifex fuels (@burrows2018). This effect may be included
either using a curing function (e.g. @cheney2008) or by including the live
component in a bulk moisture content estimate (@burrows2018).

Unfortunately, a complete set of drought or fuel availability models has not yet
been developed for the eight major fuel types used in the AFDRS @tbl-fbm-ref.
For the grassland, savanna, spinifex and buttongrass models the recommended fuel
availability model was used with observed and forecast inputs as required.

For the remaining four fuel types, existing models were adapted. Some of the
modifications have been made without a proper scientific foundation and the
development of better fuel availability models is a high research priority.

+--------------+------------------------------+--------------------------------+
| Fuel type    | Recommended fuel             |  Adapted fuel                  |
|              | availability model           |  availability model            |
+==============+==============================+================================+
| Grassland    | @cruz2015c curing function   | Recommended, using observed    |
|              |                              | curing                         |
+--------------+------------------------------+--------------------------------+
| Savanna      | @cruz2015c curing function   | Recommended, using observed    |
|              |                              | curing                         |
+--------------+------------------------------+--------------------------------+
| Spinifex     | @holmes2023                  | Recommended, using modelled    |
|              |                              | soil moisture, and observed    |
|              |                              | time since fire                |
+--------------+------------------------------+--------------------------------+
| Buttongrass  | @marsden1995b                | Recommended, using observed    |
|              |                              | and forecast median rainfall   |
+--------------+------------------------------+--------------------------------+
| Forest       | None                         | Drought factor used to modify  |
|              |                              | fuel amount                    |
+--------------+------------------------------+--------------------------------+
| Mallee-heath | None                         | @marsden1995b                  |
+--------------+------------------------------+--------------------------------+
| Heathland    | None                         | @marsden1995b                  |
| (Shrubland)  |                              |                                |
+--------------+------------------------------+--------------------------------+
| Pine         | Fine Fuel Moisture           | Drought factor used to modify  |
|              | code-based models            | fuel amount                    |
|              | (@vanwagner1987)             |                                |
+--------------+------------------------------+--------------------------------+

: Fuel availability models and their associated references 
    {#tbl-fuel-models .striped .hover}

#### Build-up phase

Most available fire behaviour models assume dry conditions and a fully developed
head fire e.g. CSIRO grassland (after allowing for curing factor), Vesta/DEFFM,
and the heathland model. Since no satisfactory model exists for the build-up
phase of a fire except in very mild conditions (@sullivan2013), and since we are
interested in the maximum potential of fire spread, the AFDRS calculates the
maximum potential rate of spread, assuming that the fire has reached its
quasi-steady state. Consequently, it might be over-predicting in cases where the
fire is still in an initial state, or when fuels are damp.

#### Topographic effects

Fires burning in hilly country are affected by topography at different scales.
At a local scale, fires burn uphill faster and downhill slower than on flat
ground. The accepted models for this are:

For uphill slopes (@noble1980):

$$
ROS_{+slope} = ROS \times e^{0.069\theta}
$$ {#eq-ros-pos-slope}

For downhill slopes (@sullivan2014):
$$
ROS_{-slope} = ROS \times \frac{2^{ - \left(\frac{\theta}{10}\right)}}
    {2\left(2^{ - \left(\frac{\theta}{10}\right)}\right) - 1}
$$ {#eq-ros-neg-slope}

where $\theta$ is the angle of the slope in degrees, being positive for uphill
slopes, and negative for downhill slopes.

Topography can also generate more complex fire behaviours such as lateral spread
on lee slopes (@simpson2014, @simpson2016), or generation of mass spotting both
of which can contribute to fire spread and place fire fighters at risk
(@lahaye2018). Fire-fighting in mountainous terrain may be more challenging than
on flat ground due to the difficulty of moving ground resources and lower
density of track networks. On the other hand, topography may also offer
opportunities for suppression by allowing use of up- or downslopes to facilitate
back-burning or providing natural moisture boundaries.

On balance, it seems likely that steep topography should increase fire danger.
However, there are no accepted models for estimating how much higher it should
be, nor is it sensible to simply increase fire danger following
@eq-ros-pos-slope and @eq-ros-neg-slope. Therefore at this point, the AFDRS does
not include topographic effects. The system was built to allow inclusion of
slope as a variable in future if required, depending on the outcomes of the
AFDRS Ignition, Suppression and Impact research project.

### Detailed model descriptions 

In the remainder of the technical guide, the eight primary fire behaviour models
are discussed in detail. This document has strived to be as consistent as
possible with the use of units. The units for input and output values are given
for each variable in the specific section and summarised here in @tbl-fbm-units.

However, because of the different sources for the models and equations,
sometimes it was necessary to make conversions. For example, for the calculation
of fireline intensity, conversions had to be made for fuel load from tonnes per
hectare (tonne/ha) to kilograms per square meter (kg/m^2), and for rate of
spread from meter per hour (m/h) to meter per second (m/s). In addition, some
models are based on research conducted using imperial units (such as lb/ft^2 for
fuel load) and conversion factors are included in the model to adjust for this.
This will be noted in the technical guide where it happens.

The reader of this technical guide is encouraged to be vigilant of these
conversions in examining the individual model equations and/or implementations.

|   Input/output variable                          |   Unit              |
| ------------------------------------------------ | ------------------- |
| Wind speed                                       | km/h                |
| Temperature                                      | °C                  |
| Relative humidity                                | \%                  |
| Fuel load                                        | tonnes/ha (or t/ha) |
| Fuel moisture content                            | \%                  |
| Fuel density                                     | kg/m^3              |
| Curing                                           | \%                  |
| Heat yield                                       | kJ/kg               |
| Fuel cover (e.g. spinifex) or overstorey cover   | \%                  |
| Near-surface fuel height                         | cm                  |
| Elevated fuel height                             | m                   |
| Overstorey height                                | m                   |
| Rate of spread                                   | m/h                 |
| Fireline intensity                               | kW/m                |
| Flame height                                     | m                   |

: Input and/or Output variables used in the Fire Behaviour Models and their
    associated units {#tbl-fbm-units .striped .hover}

### Application of models to fuel types

For the AFDRS, fuel type classification has been driven by the need to select an
appropriate fire behaviour model, and to capture the range of variation in the
fuel parameters that feed the inputs to the models. A hierarchy of
classification describes the use of increasingly detailed fuel information
within the AFDRS.

Vegetation types that don't have a specific fire behaviour model (e.g.
rainforests, arid shrublands, wetlands, rural and urban areas) have been
allocated to the model with the most similar fuel structure (as per @cruz2015a).
However, there are often factors (broadly represented by climatic variation or
human management) limiting the flammability, fuel availability or fuel
connectivity in these vegetation types. These vegetation types have been
classified as additional fuel types that identify which fire behaviour model is
to be applied and what modifications are required to the fire behaviour
calculations (as per @plucinski2017). The broad fuel types divided into these
additional fuel types make up the full list of AFDRS fuel types as shown in
@tbl-fuel-classification. A comparison between the AFDRS fuel types and other
fuel and vegetation classifications is provided by @matthews2019 in
Supplementary Table 4.7.1.

+-------------+--------------+------------------------+----------------+------------------+
| Fire        | Fuel Type    | Description            | Limitations    | Modifications    |
| Behaviour   |              |                        |                |                  |
| Model Used  |              |                        |                |                  |
+=============+==============+========================+================+==================+
| Grassland   | Grass        | Continuous and         | n/a            | Variation by     |
|             |              | tussock grasslands.    |                | reported grass   |
|             |              |                        |                | fuel load        |
+-------------+--------------+------------------------+----------------+------------------+
| Grassland   | Pasture      | Modified or native     | Fuel           | Variation by     |
|             |              | pasture where primary  | availability   | reported grass   |
|             |              | land use is grazing.   | variable with  | fuel load        |
|             |              |                        | management     |                  |
+-------------+--------------+------------------------+----------------+------------------+
| Grassland   | Crop         | Non-irrigated cropping | Fuel           | Variation by     |
|             |              | land (cereals, hay,    | availability   | reported grass   |
|             |              | sugar, etc.).          | variable with  | fuel load        |
|             |              |                        | management     |                  |
+-------------+--------------+------------------------+----------------+------------------+
| Grassland   | Low wetland  | Wetland with low or no | Fuel           | Eaten out grass  |
|             |              | overstorey. E.g. low   | availability   | condition        |
|             |              | swamp heath, sedgeland,| limited by     |                  |
|             |              | rushland.              | moisture       |                  |
|             |              |                        | content        |                  |
+-------------+--------------+------------------------+----------------+------------------+
| Grassland   | Chenopod     | Low arid shrublands    | Fuel           | Eaten out grass  |
|             | shrubland    | dominated by chenopod  | availability   | condition        |
|             |              | (saltbush) species, or | limited by     |                  |
|             |              | similar non-arid       | moisture       |                  |
|             |              | vegetation with        | content        |                  |
|             |              | samphire species.      |                |                  |
|             |              | Limited flammability   |                |                  |
|             |              | except when high cover |                |                  |
|             |              | of ephemeral grasses.  |                |                  |
+-------------+--------------+------------------------+----------------+------------------+
| Grassland   | Gamba grass  | Invasive Andropogon    | Fuel loads and | Always natural   |
| or Savanna  |              | gayanus grasses        | fuel height    | condition, fixed |
|             |              | introduced for grazing | variable       | fuel loads per   |
|             |              | in tropical areas.     | outside the    | fuel type        |
|             |              |                        | range of       |                  |
|             |              |                        | application    |                  |
+-------------+--------------+------------------------+----------------+------------------+
| Savanna     | Woodland     | Woodland and           | n/a            | Variation by     |
|             |              | shrubland with a       |                | reported grass   |
|             |              | continuous grass       |                | fuel load        |
|             |              | understorey (minimal   |                |                  |
|             |              | shrub or litter        |                |                  |
|             |              | component).            |                |                  |
+-------------+--------------+------------------------+----------------+------------------+
| Savanna     | Acacia       | Arid woodland or       | Fuel           | Eaten out grass  |
|             | woodland     | shrubland with an      | connectivity   | condition        |
|             |              | ephemeral grass        | limited and    |                  |
|             |              | understorey. Fuel      | variable with  |                  |
|             |              | connectivity only when | ephemeral      |                  |
|             |              | grass cover occurs     | grass growth   |                  |
|             |              | after sufficient rain. |                |                  |
+-------------+--------------+------------------------+----------------+------------------+
| Savanna     | Woody        | Perennial woody        | Fuel           | Eaten out grass  |
|             | horticulture | horticulture, likely   | availability   | condition        |
|             |              | managed (mown,         | variable with  |                  |
|             |              | irrigated) grass, such | management     |                  |
|             |              | as orchards or         |                |                  |
|             |              | vineyards.             |                |                  |
+-------------+--------------+------------------------+----------------+------------------+
| Savanna     | Rural        | Rural residential      | Fuel           | Grazed grass     |
|             |              | areas. Typically       | availability   | condition        |
|             |              | continuous grass with  | variable with  |                  |
|             |              | variable tree cover.   | management     |                  |
|             |              | Fuel management may be |                |                  |
|             |              | highly variable.       |                |                  |
+-------------+--------------+------------------------+----------------+------------------+
| Savanna     | Urban        | Urban and suburban     | Fuel           | Eaten out grass  |
|             |              | residential areas with | availability   | condition        |
|             |              | grass or garden and    | variable with  |                  |
|             |              | variable tree cover,   | management     |                  |
|             |              | such as parks and golf |                |                  |
|             |              | courses. Fuel          |                |                  |
|             |              | management may be      |                |                  |
|             |              | highly variable.       |                |                  |
+-------------+--------------+------------------------+----------------+------------------+
| Spinifex    | Spinifex     | Spinifex hummock       | n/a            | None             |
|             |              | grassland.             |                |                  |
+-------------+--------------+------------------------+----------------+------------------+
| Spinifex    | Spinifex     | Woodland and           | Overstorey     | Wind reduction   |
|             | woodland     | shrubland with a       | presence       | factor applied   |
|             |              | hummock grass          | reduces wind   |                  |
|             |              | understorey. Includes  | penetration    |                  |
|             |              | vegetation described   |                |                  |
|             |              | as mallee if the       |                |                  |
|             |              | understorey is         |                |                  |
|             |              | spinifex.              |                |                  |
+-------------+--------------+------------------------+----------------+------------------+
| Mallee      | Mallee       | Semi-arid woodland     | n/a            | None             |
| heath       |              | and shrubland with a   |                |                  |
|             |              | shrub understorey.     |                |                  |
|             |              | Includes mallee        |                |                  |
|             |              | eucalypt, acacia and   |                |                  |
|             |              | casuarina woodlands or |                |                  |
|             |              | shrublands.            |                |                  |
+-------------+--------------+------------------------+----------------+------------------+
| Heathland   | Heath        | Shrublands. Includes   | n/a            | None             |
| (Shrubland) |              | heathland, tall closed |                |                  |
|             |              | shrubland, low closed  |                |                  |
|             |              | forest, and open       |                |                  |
|             |              | woodland with heath    |                |                  |
|             |              | understorey.           |                |                  |
+-------------+--------------+------------------------+----------------+------------------+
| Heathland   | Wet heath    | Wetlands with a        | Fuel           | None             |
| (Shrubland) |              | medium to tall shrub   | availability   |                  |
|             |              | structure. E.g. swamp  | limited by     |                  |
|             |              | heath, melaleuca       | moisture       |                  |
|             |              | shrubland.             | content        |                  |
+-------------+--------------+------------------------+----------------+------------------+
| Buttongrass | Buttongrass  | Buttongrass moorland.  | n/a            | None             |
+-------------+--------------+------------------------+----------------+------------------+
| Forest      | Forest       | Dry eucalypt forest    | n/a            | None             |
|             |              | and temperate woodland |                |                  |
|             |              | with a shrubby         |                |                  |
|             |              | understorey and litter |                |                  |
|             |              | surface fuel.          |                |                  |
+-------------+--------------+------------------------+----------------+------------------+
| Forest      | Wet forest   | Forests with high      | Fuel           | Drought factor   |
|             |              | moisture content due   | availability   | modifier applied |
|             |              | to structure (closed   | limited by     |                  |
|             |              | forest cover >70%,     | moisture       |                  |
|             |              | tall forest >30m),     | content        |                  |
|             |              | topography, or         |                |                  |
|             |              | inundation. E.g.       |                |                  |
|             |              | rainforest, wet        |                |                  |
|             |              | sclerophyll forest,    |                |                  |
|             |              | swamp forest.          |                |                  |
+-------------+--------------+------------------------+----------------+------------------+
| Pine        | Pine         | Pine plantation.       | n/a            | None             |
+-------------+--------------+------------------------+----------------+------------------+
| Non-        | Horticulture | Seasonal horticulture, | Nil            | Nil              |
| combustible |              | very low flammability. | calculations   | calculations     |
|             |              | E.g. vegetables, herbs | made           | made             |
|             |              | and irrigated crops.   |                |                  |
+-------------+--------------+------------------------+----------------+------------------+
| Non-        | Built up     | Non-combustible urban  | Nil            | Nil              |
| combustible |              | areas and intensive    | calculations   | calculations     |
|             |              | land use. E.g.         | made           | made             |
|             |              | business districts,    |                |                  |
|             |              | industrial areas,      |                |                  |
|             |              | infrastructure,        |                |                  |
|             |              | mining.                |                |                  |
+-------------+--------------+------------------------+----------------+------------------+
| Non-        | Non-         | Non-combustible areas  | Nil            | Nil              |
| combustible | combustible  | of water, sand, rock,  | calculations   | calculations     |
|             |              | etc. Includes saline   | made           | made             |
|             |              | wetlands.              |                |                  |
+-------------+--------------+------------------------+----------------+------------------+

: Fire behaviour model to fuel classification hierarchy 
    {#tbl-fuel-classification .striped .hover .table-sm}
"""

import warnings

from . import (
    acacia_woodland,
    buttongrass,
    chenopod,
    dry_forest,
    grass,
    gamba,
    heathland,
    low_wetland,
    mallee_heath,
    pasture,
    pine,
    rural,
    savanna,
    spinifex,
    unburnable,
    wet_forest,
    wet_heathland,
    woody_horticulture,
    common,
    csiro_grassland,
)


# allow the use of savannah, but raise a deprecation warning and return the
# savanna module instead
def __getattr__(name):
    if name == "savannah":
        # raise a depreciation warning
        warnings.warn(
            "The `fdrs_calcs.spread_models.savannah` module is deprecated and "
            "will be removed in a future release. Please use "
            " `fdrs_calcs.spread_models.savanna` instead.",
            DeprecationWarning,
        )
        return savanna
    else:
        raise AttributeError(f"module {__name__} has no attribute {name}")


# don't import anything when using `from fdrs_calcs.spread_models import *`
__all__ = []
