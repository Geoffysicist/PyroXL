r"""
Fire behaviour calculations for heathland

## Technical Guide

This sub-fuel consists of wetlands with a medium to tall shrubland structure;
for example, swamp heath or melaleuca shrubland. Wet heath is included as a
separate sub-fuel, but no variation to the model has been applied at this stage.
"""

from .. import typing as ft
from . import heathland


def calculate(
    dataset: heathland.HeathlandInputVariables,
    fuel_parameters: heathland.HeathlandFuelParameters,
) -> ft.CommonOutputIndices:
    r"""
    Main entry point for wet heathland fire behaviour calculations.

    ### Implementation Details

    In the current implementation, wet heathland is treated identically as
    heathland, so refer to that sub-fuel for more information on the
    implementation.
    """

    return heathland.calculate(dataset, fuel_parameters)
