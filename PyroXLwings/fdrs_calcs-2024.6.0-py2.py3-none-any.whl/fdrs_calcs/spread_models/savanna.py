r"""
Fire behaviour calculations for savanna

## Technical Guide

This sub-fuel is for woodland and shrubland with a continuous grass understorey
and minimal shrub or litter component in the fuel makeup. It includes tropical
savanna woodland, temperate grassy woodlands, and semi-arid woodlands or
shrublands with a perennial continuous grass understorey. The fuel condition is
set by the reported fuel load. If no input is given the default for grassy
woodland is natural.
"""

from typing import Annotated

from . import fire_behaviour_index
from . import fire_danger_rating
from .. import typing as ft
from .common import standardize_dataset_variables

from .csiro_grassland import calc_fuel_moisture
from .csiro_grassland import calc_rate_of_spread
from .csiro_grassland import calc_intensity
from .csiro_grassland import calc_flame_height
from .csiro_grassland import calc_spotting_distance

from .grass import GrassInputVariables

# add additional type hints for savanna specific inputs
WF_Sav_Value = Annotated[float, ft.Bounds(0.0, 1.0)]
"""Wind reduction factor (0.0-1.0)"""


class SavannaFuelParameters(ft.NoFuelParameters):
    r"""Savanna specific fuel parameters"""

    WF_Sav: WF_Sav_Value


def calculate(
    dataset: GrassInputVariables, fuel_parameters: SavannaFuelParameters
) -> ft.CommonOutputIndices:
    r"""
    Main entry point for calculating fire behaviour in savanna areas.

    ### Implementation Details

    Implemented using the CSIRO Grassland Fire Spread Model, with the
    calculated rate of spread multiplied by a provided wind reduction factor
    (WF_Sav).

    ### Usage

    ```python
    indices = savanna.calculate(dataset, fuel_parameters)
    ```

    ### Parameters

    - **dataset** (*dict*) - A dictionary of *array_like* containing the input
        variables.

        From these input variables, only the following are used by this model

        - **T_SFC** : Surface temperature (C)
        - **RH_SFC** : Relative humidity (%)
        - **WindMagKmh_10m** : Wind magnitude at 10m (km/h)
        - **Curing_SFC** : Fuel curing (%)
        - **grass_condition** : Grass condition (3-1, corresponding to natural,
            grazed, eaten out)
        - **GrassFuelLoad_SFC** : Surface grass fuel load (tonnes/ha)

    - **fuel_parameters** A dictionary of scalars containing the fuel
      parameters.

        For this model the following parameters are used

        - **WF_Sav** : Wind reduction factor (unitless)

    ### Returns

    - **indices** (*dict*) - A dictionary of *array_like* containing the output
        variables of the same shape as the input arrays with the following keys

        - **dead_fuel_moisture** : Dead fuel moisture content (%)
        - **rate_of_spread** : Rate of spread (m/hr)
        - **flame_height** : Flame height (m)
        - **intensity** : Fire intensity (kW/m)
        - **spotting_distance** : Spotting distance (m)
        - **rating_1** : Fire danger rating (unitless)
        - **index_1** : Fire behaviour index (unitless)

    """
    # standardize the dataset variables
    dataset = standardize_dataset_variables(dataset)

    # calculate dead fuel moisture content
    dead_fuel_moisture = calc_fuel_moisture(dataset["T_SFC"], dataset["RH_SFC"])

    # Calculate rate of spread from the dead fuel moisture content, wind speed
    # and curing using the CSIRO grassland model, but multiply by the wind
    # reduction factor (WF_Sav) to account for the reduced wind speed due to
    # the presence of trees.
    rate_of_spread = calc_rate_of_spread(
        dead_fuel_moisture,
        dataset["WindMagKmh_10m"],
        dataset["Curing_SFC"],
        dataset["grass_condition"],
    )
    rate_of_spread = rate_of_spread * fuel_parameters["WF_Sav"]

    # calculate the flame height from the rate of spread and the fuel load
    flame_height = calc_flame_height(rate_of_spread, dataset["grass_condition"])

    # calculate the fire intensity from the rate of spread and the fuel load
    intensity = calc_intensity(rate_of_spread, dataset["GrassFuelLoad_SFC"])

    # calculate the spotting distance from the surface temperature
    spotting_distance = calc_spotting_distance(dataset["T_SFC"])

    # calculate the fire danger rating and fire behaviour index from the
    # intensity
    index_1 = fire_behaviour_index.grass(intensity)
    rating_1 = fire_danger_rating.fire_danger_rating(index_1)

    # return the outputs
    return {
        "dead_fuel_moisture": dead_fuel_moisture,
        "rate_of_spread": rate_of_spread,
        "flame_height": flame_height,
        "intensity": intensity,
        "spotting_distance": spotting_distance,
        "rating_1": rating_1,
        "index_1": index_1,
    }
