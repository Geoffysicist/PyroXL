r"""
Fire behaviour calculations for Buttongrass

## Technical Guide

The AFDRS Buttongrass Model is used for buttongrass moorlands. Buttongrass fuels
are found mainly in Tasmania, covering 10% of the state but significant in only
1 FWA.

### What is the AFDRS Buttongrass Model? {#sec-buttongrass-model}

AFDRS uses the buttongrass moorland model developed by @marsden1995b. This model
was created using data from 44 experimental fires, 11 prescribed burns, and 5
wildfires. It is potentially applicable to other areas in Australia, such as
coastal swamps, but for the initial implementation of AFDRS, it is used
exclusively for moorlands with a significant proportion of buttongrass.

Typical Tasmanian buttongrass moorlands burn very differently compared to other
grasslands, heathlands or forests. As long as the fuel moisture content is below
70% and the age of the buttongrass moorlands is over 3 years, fires have been
reported to spread - even over standing water. The threshold of dead fuel
moisture content at which fires can be sustained in these moorlands is much
higher (70%) compared to Eucalyptus litter (16-20%) or pine needles (30%)
because moisture content is measured as a bulk value mixing live and dead fuels
in contrast to other fuel types which consider dead fuel moisture only.

The key components of fire spread in buttongrass moorlands are (i) the openness
of the moorlands (i.e. non-forested nature) and therefore the exposure to wind.
And (ii) the substantial quantity of suspended dead fuels.

### Inputs and outputs {#sec-inputs}

The buttongrass model requires inputs of 10m wind speed, relative humidity,
dewpoint temperature, rainfall/dewfall in the past 48 hours, time since
rainfall/dewfall ceased, fuel age and site productivity. Fuel age (time since
fire) is used as a surrogate for fuel load and the proportion of dead fuels in
the fuel bed. This model has a go/no-go threshold; it first calculates the
likelihood a fire will self-sustain and if this is above 50% it will then
calculate ROS.

### Model Behaviour and Limitations

The two key components of fire spread in buttongrass moorlands are:

- The openness of the moorlands (is it of a non-forested nature and therefore
  exposed to wind). 
- The quantity of suspended dead fuels.

This is a simple model and could be considered well-balanced as it is not overly
sensitive to any of the inputs: 

- Wind speed has the strongest effect on the rate of fire spread, accounting for
  approximately 40% of the observed variation in $ROS$ in the dataset used to
  develop this model. 
- Moisture content of suspended dead fuels and time since fire also have a
  significant effect, though to a lesser extent than wind, each accounting for
  15-20% of the variation in observed ROS from the dataset. 
- The model is sensitive to small amounts of recent rainfall as this will
  significantly increase $MC$ and therefore decrease the probability of spread
  and the rate of spread. 
- The model is less sensitive to changes in temperature/humidity.

For this model, AFDRS assumes all of the fuel (not just dead fuel load) will
burn, which could lead to an overestimation of intensity, particularly near
fast-moving fire fronts. This assumption is reflected in the moisture content
variable, which, unlike in other fire spread models, is a measure of the
moisture content of both the live and dead fuels. The threshold of $MC$ at which
fires can be sustained is much higher (70%) compared to other fuels (~20% for
eucalyptus and 30% for pine). If $MC$ < 70% and $TSF$ > 3, fires have been
reported to spread, even over standing water and with little or no wind speed. 

This model was developed mostly for prescribed burning conditions, but it has
been shown to perform adequately for wildfires. The go/no-go threshold is mostly
determined by the site quality (such as time since fire), which is most
accurately determined on-site rather than estimated from other parameters. 

### Fuel Sub-Types

This model was developed specifically for buttongrass and so has just the one
fuel sub-type. However, there is potential to apply it to other vegetation such
as coastal swamps in future updates.

#### Buttongrass Moorland

Buttongrass (Gymnoschoenus sphaerocephalus) is a species of tussock-forming
sedge mainly found in Tasmania. For AFDRS, buttongrass moorlands are defined as
treeless communities of mainly sedges and low heaths in which this species is a
significant proportion, and at the AFDRS landscape scale, this fuel is confined
entirely to Tasmania and Flinders Island. Approximately 10% of Tasmania is
classed as buttongrass moorlands, the majority of which is in the Western Fire
Weather Area.

#### Application to Low Wetlands

In the first few weeks of the live trial, the buttongrass model was used for low
wetlands on mainland Australia (based on input from the science workshop,
07/06/2017). Since this led to clear overestimations of rate of spread and fire
danger, the system was altered to model these low wetlands as chenopod
shrublands instead, using the eaten-out grassland model.
"""

from typing import Annotated
import numpy as np

from . import fire_behaviour_index
from . import fire_danger_rating
from .. import typing as ft
from . import common
from .common import standardize_dataset_variables

HEAT_CONTENT = 19900
"""KJ/kg, based on @marsden1995b."""


# add additional type hints for buttongrass specific inputs
class ButtongrassInputVariables(ft.CommonInputVariables):
    r"""Buttongrass specific additional input variables"""

    precipitation: ft.precipitation_Array
    time_since_rain: ft.time_since_rain_Array
    Td_SFC: ft.Td_SFC_Array
    time_since_fire: ft.time_since_fire_Array


Prod_BG_Value = Annotated[int, ft.Bounds(1, 2)]
"""Buttongrass productivity level (1 for low, or 2 for medium)"""


class ButtongrassFuelParameters(ft.NoFuelParameters):
    r"""Buttongrass specific fuel parameters"""

    Prod_BG: Prod_BG_Value


def calc_fuel_moisture(
    precipitation, time_since_rain, relative_humidity, dew_point_temp
):
    r"""
    Calculate fuel moisture content (%).
    
    ### Technical Guide

    Moisture content for buttongrass was calculated in Appendix 2 of
    @marsden1999 by separating it into a Rainfall Factor ($R_f$), dependent on
    the amount of precipitation in the last 48 hours and the time since the last
    rain event, and a Humidity Factor ($H_f$), dependent on relative humidity
    and dew point temperature:
    
    $$
    \begin{aligned}
        R_f &= 67.128 \left( 1 - e^{- 3.132 P} \right) e^{- 0.0858 TSR}, \\
        H_f &= e^{(1.660 + 0.0214 RH - 0.0292 T_d)},
    \end{aligned}
    $$ {#eq-rainfall-humidity-factors}

    where $P$ is the amount of precipitation in the last 48 hours (mm) and $TSR$
    is the time since the last rain event (hours), $RH$ is the relative humidity
    (%) and $T_d$ is the dew point temperature (°C).

    The moisture content (%) is then calculated as the sum of the two factors:

    $$ 
    MC = R_f + H_f 
    $$ {#eq-fuel-moisture-content}

    The unusual use of both $RH$ and $T_d$ in this equation is because
    temperature and relative humidity were correlated in the original research
    dataset.

    ### Usage

    ```python
    fuel_moisture = calc_fuel_moisture(
        precipitation, time_since_rain, relative_humidity, dew_point_temp
    )
    ```

    ### Parameters

    - **precipitation** (*array_like*) - Precipitation in the last 48 hours
      (mm).
    - **time_since_rain** (*array_like*) - Time since the last rain event
      (hours).
    - **relative_humidity** (*array_like*) - Relative humidity (%).
    - **dew_point_temp** (*array_like*) - Dew point temperature (°C).

    ### Returns

    - **fuel_moisture** (*array_like*) - Fuel moisture content (%).
    """

    # start with an nan array of the same shape as time_since_rain
    fuel_moisture = np.full(np.shape(time_since_rain), np.nan)

    # calculate the rainfall factor
    rainfall_factor = (
        67.128
        * (1 - np.exp(-3.132 * precipitation))
        * np.exp(-0.0858 * time_since_rain)
    )

    # calculate the humidity factor
    humidity_factor = np.exp(
        1.660 + 0.0214 * relative_humidity - 0.0292 * dew_point_temp
    )

    # calculate the fuel moisture content
    fuel_moisture = rainfall_factor + humidity_factor

    return fuel_moisture


def calc_fuel_load(time_since_fire, productivity):
    r"""Estimate fuel load (ton/ha) based on time since fire and productivity. 

    ### Technical Guide

    Predicted fuel load is used in calculating the predicted fireline intensity,
    and is based on time since fire. @marsden1999 separates this out into the
    total fuel load and the dead fuel loads for 'low' and 'medium' productivity
    sites:

    $$ 
    \begin{aligned} 
    Fuel_{low} &= 11.73 \left( 1 - e^{- 0.106 TSF} \right) \\ 
    Dead_{low} &= 0.873 \left( 1 - e^{- 0.036 TSF} \right) Fuel_{low} \\ 
    \end{aligned} 
    $$ {#eq-fuel-load-low}

    $$ 
    \begin{aligned}
    Fuel_{med} &= 44.61 \left( 1 - e^{ - 0.041 TSF} \right) \\ 
    Dead_{med} &= 0.950 \left( 1 - e^{ - 0.054 TSF} \right) Fuel_{med} \\
    \end{aligned}
    $$ {#eq-fuel-load-med}
    
    It is unclear from the @marsden1999 if it expected that the total fuel will
    burn, or just a fraction of it (e.g. dead fuel load). Determining this is
    most likely related to the current fire weather, rate of spread and fire
    intensity.  
    
    At present, the AFDRS uses total fuel load, chosen according to the
    productivity level fuel parameter (i.e. $Fuel_{low}$ or $Fuel_{med}$). This
    may lead to overestimation of intensity, because it is unlikely that all of
    this fuel will burn with a moving fire front (though @cheney1990 indicates
    there might be prolonged smouldering).

    ### Usage

    ```python
    fuel_load = calc_fuel_load(time_since_fire, productivity)
    ```

    ### Parameters

    - **time_since_fire** (*array_like*) - Time since the last fire (years).
    - **productivity** (*int*) - Productivity level (1 for low, or 2 for
      medium), generally provided from the fuel parameter table.

    ### Returns

    - **fuel_load** (*array_like*) - Estimated fuel load (ton/ha).
    """
    # start with an nan array of the same shape as time_since_fire
    fuel_load = np.full(np.shape(time_since_fire), np.nan)

    # calculate the fuel load based on the productivity level
    if productivity == 1:
        fuel_load = 11.73 * (1 - np.exp(-0.106 * time_since_fire))
    elif productivity == 2:
        fuel_load = 44.61 * (1 - np.exp(-0.041 * time_since_fire))

    return fuel_load


def calc_spread_probability(
    wind_speed, fuel_moisture, time_since_fire, productivity
):
    r"""Probability of sustained fire spread ('go/no-go', value between 0 and 1)

    ### Technical Guide

    In Appendix 2 of @marsden1999, the probability of sustained fire spread is
    calculated as a function of 2m wind speed, fuel moisture, and productivity:

    $$
    P_{sf} = \frac{1}{
        1 + e^{-(-1 + 0.68 U_2 - 0.07 MC - 0.0037 U_2 MC + 2.1 PROD)}
    }
    $$ {#eq-spread-probability}

    where $U_2$ is the 2m wind speed (m/s), $MC$ is the fuel moisture content
    (%), and $PROD$ is the productivity level (1 for low productivity or 2 for
    high productivity).

    In order to convert from 10m wind speeds that are provided as input to the
    AFDRS, the 2m wind speed is calculated (K. Tolhurst pers comm.) as:

    $$
    U_2 = \frac{U_{10}}{1.2}
    $$ {#eq-convert-wind-speed}

    ::: {.callout-note}
    The equation in @marsden1999 has a typo, with a minus sign at the beginning
    of the denominator (it should be $\frac{1}{1 + e^{\ldots}}$, not
    $\frac{1}{-1 + e^{\ldots}}$). This has been corrected in the AFDRS
    implementation.
    :::

    ### Implementation Details

    The Python implementation of this function also takes in a `time_since_fire`
    parameter, but this is not used in the calculations. This may be removed in
    future versions.

    ### Usage

    ```python
    spread_probability = calc_spread_probability(
        wind_speed, fuel_moisture, time_since_fire, productivity
    )
    ```

    ### Parameters

    - **wind_speed** (*array_like*) - Wind speed at 10m (km/h).
    - **fuel_moisture** (*array_like*) - Fuel moisture content (%).
    - **time_since_fire** (*array_like*) - Time since the last fire (years).
    - **productivity** (*int*) - Productivity level (1 for low, or 2 for
      medium), generally provided from the fuel parameter table.

    ### Returns

    - **spread_probability** (*array_like*) - Probability of sustained fire,
      between 0 and 1
    """
    # TODO: Should we remove the time since fire parameter? It's not used in
    # this function at present. See
    # https://gitlab.com/afdrs/afdrs-dev/packages/python-packages/fdrs_calcs/-/issues/21

    # convert wind speed from 10m to 2m
    wind_speed_2m = wind_speed / 1.2

    # calculate the probability of sustained fire spread from @marsden1999
    spread_probability = 1 / (
        1
        + np.exp(
            -(
                -1
                + 0.68 * wind_speed_2m
                - 0.07 * fuel_moisture
                - 0.0037 * wind_speed_2m * fuel_moisture
                + 2.1 * productivity
            )
        )
    )

    return spread_probability


def calc_rate_of_spread(
    wind_speed, fuel_moisture, spread_probability, time_since_fire, productivity
):
    r"""Calculate forward rate of spread in m/h

    ### Technical Guide

    In Appendix 2 of @marsden1999, the forward rate of spread is calculated with
    an alternative form of the fuel moisture (referred to as the Humidity Factor
    $H_F$ in the paper). When it is reformulated to incorporate the fuel
    moisture as a single variable, and converted from m/min to m/hr the equation
    becomes:

    $$
    ROS = 60 \times 0.678 U_2^{1.312} e^{-0.0243 MC}
        \left( 1 - e^{-0.116 TSF} \right)
    $$ {#eq-rate-of-spread}

    where $U_2$ is the 2m wind speed (m/s), $MC$ is the fuel moisture content
    (%), and $TSF$ is the time since the last fire (years).

    In order to convert from 10m wind speeds that are provided as input to the
    AFDRS, the 2m wind speed is calculated (K. Tolhurst pers comm.) as:

    $$
    U_2 = \frac{U_{10}}{1.2}
    $$ {#eq-convert-wind-speed}

    In the AFDRS implementation, the rate of spread is only calculated using the
    above equation if the probability of sustained fire spread ($P_{sf}$) is
    greater than 50%. Otherwise, the rate of spread is set to 0 m/h.

    ### Implementation Details

    The Python implementation of this function also takes in a `productivity`
    parameter, but this is not used in the calculations. This may be removed in
    future versions.

    ### Usage

    ```python
    rate_of_spread = calc_rate_of_spread(
        wind_speed, fuel_moisture, spread_probability, time_since_fire,
        productivity
    )
    ```

    ### Parameters

    - **wind_speed** (*array_like*) - Wind speed at 10m (km/h).
    - **fuel_moisture** (*array_like*) - Fuel moisture content (%).
    - **spread_probability** (*array_like*) - Probability of sustained fire,
      between 0 and 1
    - **time_since_fire** (*array_like*) - Time since the last fire (years).
    - **productivity** (*int*) - Productivity level (1 for low, or 2 for
      medium), generally provided from the fuel parameter table.

    ### Returns

    - **rate_of_spread** (*array_like*) - Forward rate of spread (m/h).
    """
    # TODO: Should we remove the productivity parameter? It's not used in this
    # function at present. See
    # https://gitlab.com/afdrs/afdrs-dev/packages/python-packages/fdrs_calcs/-/issues/21

    # convert wind speed from 10m to 2m
    wind_speed_2m = wind_speed / 1.2

    # calculate the rate of spread from @marsden1999
    rate_of_spread = (
        60
        * 0.678
        * np.power(wind_speed_2m, 1.312)
        * np.exp(-0.0243 * fuel_moisture)
        * (1 - np.exp(-0.116 * time_since_fire))
    )

    # set the rate of spread to 0 if the probability of sustained fire spread
    # is less than 50%
    mask = spread_probability <= 0.5
    if mask.any():
        rate_of_spread[mask] = 0

    return rate_of_spread


def calc_intensity(rate_of_spread, time_since_fire, productivity):
    r"""
    Calculate buttongrass fireline intensity (kW/m)

    ### Technical Guide

    The fireline intensity is calculated using @byram1959:

    $$
    I = h \times F \times ROS
    $$ {#eq-fire-intensity}

    where $h$ is the heat yield, assumed here to be 19,900 kJ/kg (based on
    @marsden1995b), $F$ is the fuel load (kg/m^2) and $ROS$ is the rate of
    spread in m/s.

    ### Implementation Details

    Rather than taking in the fuel load directly, the python implementation of
    this function takes in the time since fire and productivity and calculates
    the fuel load using the `calc_fuel_load` function, then passes it to
    `common.calc_fire_intensity` to calculate the intensity using the above
    equation.

    ### Usage

    ```python
    intensity = calc_intensity(rate_of_spread, time_since_fire, productivity)
    ```

    ### Parameters

    - **rate_of_spread** (*array_like*) - Forward rate of spread (m/h).
    - **time_since_fire** (*array_like*) - Time since the last fire (years).
    - **productivity** (*int*) - Productivity level (1 for low, or 2 for
      medium), generally provided from the fuel parameter table.

    ### Returns

    - **intensity** (*array_like*) - Fireline intensity (kW/m).
    """
    # calculate the fuel load
    fuel_load = calc_fuel_load(time_since_fire, productivity)

    # calculate the intensity
    intensity = common.calc_fire_intensity(
        rate_of_spread, fuel_load, HEAT_CONTENT
    )

    return intensity


def calc_flame_height(intensity):
    r"""Calculate flame height in (m)

    ### Technical Guide

    The flame height (m) was modelled by @marsden1995b as a power function of
    @byram1959 intensity:

    $$
    F_H = 0.148 I_B^{0.403}
    $$ {#eq-flame-height}

    Where $I_B$ is the fireline intensity (kW/m).

    ### Usage

    ```python
    flame_height = calc_flame_height(intensity)
    ```

    ### Parameters

    - **intensity** (*array_like*) - Fireline intensity (kW/m).

    ### Returns

    - **flame_height** (*array_like*) - Flame height (m).
    """
    return 0.148 * np.power(intensity, 0.403)


def calc_spotting_distance(air_temperature):
    r"""
    Calculate spotting distance (m)

    ### Technical Guide

    A spotting model is not currently implemented for buttongrass.

    ### Implementation Details

    As a spotting model is not currently implemented for buttongrass, this
    function returns an array of NaN values of the same shape as the
    air_temperature array.

    ### Usage

    ```python
    spotting_distance = calc_spotting_distance(air_temperature)
    ```

    ### Parameters

    - **air_temperature** (*array_like*) - Air temperature (°C).

    ### Returns

    - **spotting_distance** (*array_like*) - Spotting distance (m).
    """
    return np.full(air_temperature.shape, np.nan)


def calculate(
    dataset: ButtongrassInputVariables,
    fuel_parameters: ButtongrassFuelParameters,
) -> ft.CommonOutputIndices:
    r"""
    Main entry point for buttongrass fire behaviour calculations.

    ### Usage

    ```python
    indices = buttongrass.calculate(dataset, fuel_parameters)
    ```

    ### Parameters

    - **dataset** (*dict*) - A dictionary of *array_like* containing the input
        variables.

        From these input variables, only the following are used by this model

        - **T_SFC** : Surface temperature (C)
        - **RH_SFC** : Surface relative humidity (%)
        - **WindMagKmh_10m** : Wind magnitude at 10m (km/h)
        - **precipitation** : Precipitation in the last 48 hours (mm)
        - **time_since_rain** : Time since the last rain event (hours)
        - **Td_SFC** : Surface dew point temperature (°C)
        - **time_since_fire** : Time since the last fire (years)

    - **fuel_parameters** A dictionary of scalars containing the fuel
      parameters.

        From these fuel parameters, only the following are used by this model

        - **Prod_BG** : Productivity level (1 for low, or 2 for medium)

    ### Returns

    - **indices** (*dict*) - A dictionary of *array_like* containing the output
        variables of the same shape as the input arrays with the following keys

        - **dead_fuel_moisture** : Dead fuel moisture content (%)
        - **rate_of_spread** : Rate of spread (m/hr)
        - **flame_height** : Flame height (m)
        - **intensity** : Fire intensity (kW/m)
        - **spotting_distance** : Spotting distance (m)
        - **rating_1** : Fire danger rating (unitless)
        - **index_1** : Fire behaviour index (unitless)
    """
    # standardize the dataset variables
    dataset = standardize_dataset_variables(dataset)

    # Calculate dead fuel moisture content
    dead_fuel_moisture = calc_fuel_moisture(
        dataset["precipitation"],
        dataset["time_since_rain"],
        dataset["RH_SFC"],
        dataset["Td_SFC"],
    )

    # calculate spread probability
    spread_probability = calc_spread_probability(
        dataset["WindMagKmh_10m"],
        dead_fuel_moisture,
        dataset["time_since_fire"],
        int(fuel_parameters["Prod_BG"]),
    )

    # calculate the rate of spread
    rate_of_spread = calc_rate_of_spread(
        dataset["WindMagKmh_10m"],
        dead_fuel_moisture,
        spread_probability,
        dataset["time_since_fire"],
        int(fuel_parameters["Prod_BG"]),
    )

    # calculate the intensity
    intensity = calc_intensity(
        rate_of_spread,
        dataset["time_since_fire"],
        int(fuel_parameters["Prod_BG"]),
    )

    # calculate the flame height
    flame_height = calc_flame_height(intensity)

    # calculate the spotting distance
    spotting_distance = calc_spotting_distance(dataset["T_SFC"])

    # calculate fire danger rating and fire behaviour index from the rate of
    # spread only
    index_1 = fire_behaviour_index.buttongrass(rate_of_spread)
    rating_1 = fire_danger_rating.fire_danger_rating(index_1)

    return {
        "dead_fuel_moisture": dead_fuel_moisture,
        "rate_of_spread": rate_of_spread,
        "flame_height": flame_height,
        "intensity": intensity,
        "spotting_distance": spotting_distance,
        "rating_1": rating_1,
        "index_1": index_1,
    }
