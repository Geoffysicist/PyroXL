r"""
Fire behaviour calculations for spinifex

## Technical Guide

The AFDRS Spinifex Model is used for the hummock spinifex grasslands of central
Australia, which cover 26% of the nation. Spinifex dominates 16 FWAs across NT
and WA and has an influence on FWAs in the arid regions of all mainland states.

### What is the AFDRS Spinifex Model? {#sec-spinifex-model}

AFDRS uses the desert spinifex model developed by @burrows2018 and adapted by
@holmes2023. This model is the latest iteration of many years of work and uses
data from 150 experimental fires in WA and QLD from 1991 to 2018. Because of the
discontinuous nature of spinifex clumps, it has go/no-go threshold (in this case
a spread index) to determine if a fire is likely to spread.

### Inputs and outputs {#sec-inputs}

The spinifex model is a simple model and outputs Rate of Spread (ROS),
intensity, and flame height. It requires inputs of 10m wind speed, relative
humidity, years since fire, and monthly relative soil moisture content

### Model behaviour and limitations {#sec-limitations}

This is a simple model and can be considered well balanced as it is not overly
sensitive to any of the inputs, though as Time Since Fire is used to estimate
both moisture content and fuel coverage, it can have a large influence.

The strongest (10m) wind speeds in the experimental data were around 27 km/h and
it is not known how well the model performs at stronger wind speeds. 

In @burrows2018, both live and dead spinifex were included and were not
distinguished between by that model, but those two states of the fuel will
respond differently to changing dewpoint and temperature. However, this has been
explicitly included in the @holmes2023 model, which now includes contributions
of both live and dead fuel moisture to the overall fuel moisture model.

Spinifex fuels are discontinuous and the spread index accounts for this however
it assumes the distribution of fuel is uniform over an area with a single spread
index value. Larger gaps in fuel, either natural or artificial (such as a road)
may interrupt fire spread.

If there is a continuous (>70%) cover of cured soft grassy plants (e.g. after
exceptional rainfall), the assumption of no fire spread within three years would
be incorrect. Spinifex could be temporarily remapped as a grass type in this
situation (if deemed important). This model works best at the local scale as it
relies on accurate inputs of "eye-level" wind speed and fuel moisture which in
AFDRS are both estimated from other variables

### Fuel Sub-Types {#sec-fuel-types}

All vegetation communities with a spinifex hummock grass understorey have been
classified to the spinifex fuel type in AFDRS and they are split in two
sub-types depending on overstorey coverage.

#### Spinifex {#sec-fuel-types-spinifex}

Spinifex hummock grassland with less than 5% tree/shrub cover.

#### Spinifex woodland {#sec-fuel-types-woodland}

Woodland and shrubland with a hummock grass (spinifex) understorey. This
includes vegetation described as mallee if the understorey is spinifex. ROS is
reduced by calculating the 1.7m wind using a wind reduction factor based on
canopy cover, similarly to the Grassy Woodland (Savanna) adaptation of the CSIRO
Grassland model.

"""

import numpy as np

from . import fire_behaviour_index
from . import fire_danger_rating
from .. import typing as ft
from . import common
from .common import standardize_dataset_variables
from . import savanna

HEAT_CONTENT = 16700  # KJ/kg Malcolm Possell pers comm.


# add additional type hints for spinifex specific inputs
class SpinifexInputVariables(ft.CommonInputVariables):
    r"""Spinifex specific additional input variables"""

    AWAP_uf: ft.AWAP_uf_Array
    time_since_fire: ft.time_since_fire_Array


class SpinifexFuelParameters(ft.NoFuelParameters):
    r"""Spinifex specific fuel parameters"""

    FTno_FDR: ft.FTno_FDR_Value
    WF_Sav: savanna.WF_Sav_Value


spread_index_Array = ft.InputVariableArray[np.float64]


class SpinifexOutputIndices(ft.CommonOutputIndices):
    r"""Spinifex specific additional output indices"""

    spread_index: spread_index_Array


def calc_fuel_cover(time_since_fire, log_tsf, fuel_is_spinifex_woodland):
    r"""
    Calculate fuel cover (%)

    ### Technical Guide

    Based on the work of @holmes2023, this model uses a logistic mixed model to
    predict fuel cover. The model is split into two sub-types depending on
    woodland fuel presence: Spinifex and Spinifex Woodland.

    Both models use the same base equation, but the Spinifex Woodland model has
    an additional term to account for woodland fuels interspesed with spinifex.

    The base equation (in logit space) for the spinifex fuel type $lC_s$:

    $$
    lC_s = -2.5599 - 0.038382 TSF + 1.1048 \ln(TSF)
    $$ {#eq-spinifex-fuel-cover}

    where $TSF$ is time since fire (years).

    The Spinifex Woodland model has an additional term to term to account for 
    woodland fuels interspesed with spinifex ($lC_w$):

    $$
    lC_w = -0.13992 + 0.12047 \ln(TSF)
    $$ {#eq-spinifex-woodland-fuel-cover}

    ::: {.callout-note}
    Before calculating $lC_s$ and $lC_w$, $TSF$ is first clipped to be between 1
    and 25 years to avoid undefined values in the natural log term. 
    :::

    The total fuel cover is then calculated in logit space as the sum of the
    Spinifex and Spinifex Woodland fuel covers (if applicable), and transformed back
    to the linear scale:

    $$
    \begin{aligned}
    lC_T &= \begin{cases}
        lC_s & \text{if Spinifex} \\
        lC_s + lC_w & \text{if Spinifex Woodland}
    \end{cases} \\
    C_T &= 100 * \frac{1}{1 + e^{-lC_T}}
    \end{aligned}
    $$ {#eq-spinifex-total-fuel-cover}

    where $lC_T$ is the total fuel cover in logit space and $C_T$ is the
    total fuel cover (in percentage) in linear space.

    ### Implementation Details

    The choice of whether a fuel type is Spinifex or Spinifex Woodland is
    determined by the sub fuel type ID in the `FTno_FDR` parameter. If
    `FTno_FDR` is 400, the fuel type is Spinifex, otherwise it is Spinifex
    Woodland.

    Clipping of $TSF$ to 1-25 years is done before passing it to this function,
    in the `calculate` function. If you are calling this function directly, you
    will need to clip $TSF$ yourself.

    ### Usage

    ```python
    fuel_cover = calc_fuel_cover(
        time_since_fire, log_tsf, fuel_is_spinifex_woodland
    )
    ```

    ### Parameters

    - **time_since_fire** (*array-like*) Time since fire (years)
    - **log_tsf** (*array-like*) Natural log of time since fire
    - **fuel_is_spinifex_woodland** (*array-like*) Boolean array indicating
        whether the fuel type is Spinifex Woodland

    ### Returns

    - **fuel_cover** (*array-like*) Fuel cover (%)
    """
    # Predict natural log-space fuel cover of spinifex
    log_cover = (
        -2.55991763 - 0.03838217 * time_since_fire + 1.10476581 * log_tsf
    )

    # add in woodland term if fuel is woodland
    if fuel_is_spinifex_woodland:
        log_cover = log_cover - 0.13992188 + 0.12047025 * log_tsf

    # Back transform to percentage
    fuel_cover = (1 / (1 + np.exp(-log_cover))) * 100

    return fuel_cover


def calc_fuel_load(time_since_fire, log_tsf, fuel_is_spinifex_woodland):
    r"""
    Calculate fuel load (t/ha)

    ### Technical Guide

    Based on the work of @holmes2023, this model uses a linear mixed model in
    natural log space to predict fuel load. The model is split into two sub-types 
    depending on woodland fuel presence: Spinifex and Spinifex Woodland.

    Both models use the same base equation, but the Spinifex Woodland model has
    an additional term to account for woodland fuels interspesed with spinifex.

    The base equation (in natural log space) for the Spinifex fuel type $lF_s$:

    $$
    lF_s = -0.68926 - 0.036074 TSF + 1.1553 \ln(TSF)
    $$ {#eq-spinifex-fuel-load}

    where $TSF$ is time since fire (years).

    The Spinifex Woodland model has an additional term to term to account for 
    woodland fuels interspesed with spinifex ($lF_w$):

    $$
    lF_w = 0.42530 - 0.17232 \ln(TSF)
    $$ {#eq-spinifex-woodland-fuel-load}

    ::: {.callout-note}
    Before calculating $lF_s$ and $lF_w$, $TSF$ is first clipped to be between 1
    and 25 years to avoid undefined values in the natural log term. 
    :::

    The total fuel load is then calculated in natural log space as the sum of the
    Spinifex and Spinifex Woodland fuel loads (if applicable), and transformed
    back to the linear scale:

    $$
    F = \begin{cases}
        e^{lF_s} & \text{if Spinifex} \\
        e^{lF_s + lF_w} & \text{if Spinifex Woodland}
    \end{cases}
    $$ {#eq-spinifex-total-fuel-load}

    ### Implementation Details

    The choice of whether a fuel type is Spinifex or Spinifex Woodland is
    determined by the sub fuel type ID in the `FTno_FDR` parameter. If
    `FTno_FDR` is 400, the fuel type is Spinifex, otherwise it is Spinifex
    Woodland.

    Clipping of $TSF$ to 1-25 years is done before passing it to this function,
    in the `calculate` function. If you are calling this function directly, you
    will need to clip $TSF$ yourself.

    ### Usage

    ```python
    fuel_load = calc_fuel_load(
        time_since_fire, log_tsf, fuel_is_spinifex_woodland
    )
    ```

    ### Parameters

    - **time_since_fire** (*array-like*) Time since fire (years)
    - **log_tsf** (*array-like*) Natural log of time since fire
    - **fuel_is_spinifex_woodland** (*array-like*) Boolean array indicating
        whether the fuel type is Spinifex Woodland

    ### Returns

    - **fuel_load** (*array-like*) Fuel load (t/ha)
    """
    # Predict natural log-space fuel load of spinifex
    log_FL = -0.6892583 - 0.0360736 * time_since_fire + 1.1552554 * log_tsf

    # add in woodland term if fuel is woodland
    if fuel_is_spinifex_woodland:
        log_FL = log_FL + 0.4253039 - 0.1723223 * log_tsf

    # Back transform to the original scale and return
    return np.exp(log_FL)


def calc_fuel_moisture(
    AWAP_uf, time_since_fire, relative_humidity, air_temperature, fuel_cover
):
    r"""
    Calculate fuel moisture (%)

    ### Technical Guide

    Based on the work of @holmes2023, this model uses multiple non-linear
    regression models to predict the percentage of both dead and live fuel
    moisture, reported as a single value representing the total moisture content
    of all fuels.

    Having already calculated the total fuel cover ($C_T$) elsewhere, the
    percentage of dead fuel cover ($C_d$) is calculated using the following
    logistic regression model:

    $$
    \begin{aligned}
    lC_d &= -4.0937 + 0.86199 TSF - 1.6136 \ln(TSF) - 0.17393 TSF
        \ln(TSF) \\
    C_d &= \frac{1}{1 + e^{-lC_d}}
    \end{aligned}
    $$ {#eq-spinifex-dead-fuel-cover}

    where $TSF$ is time since fire (years).

    ::: {.callout-note}
    Before calculating $lC_d$, $TSF$ is first clipped to be between 1 and 25
    years to avoid undefined values in the natural log term. 
    :::

    The percentage of live fuel moisture ($MC_l$) is calculated using the
    following logistic regression model:

    $$
    \begin{aligned}
    lMC_l &= 0.41913 + 0.15898 \sqrt{AWAP_{uf}} - 0.27136 \sqrt{C_T} 
        - 0.0073803 VPD \\
    MC_l &= \frac{1}{1 + e^{-lMC_l}} * 100
    \end{aligned}
    $$ {#eq-spinifex-live-fuel-moisture}

    where $AWAP_{uf}$ is the relative soil moisture content, and $C_T$ is the 
    total fuel cover.
     
    $VPD$ is the vapour pressure deficit, calculated as the difference between
    the saturation vapor pressure ($e_s$) and the measured vapor pressure
    ($e_a$). The saturation vapour pressure is calculated using the Tetens
    equation (@tetens1930) and the measured vapor pressure is calculated from
    the relative humidity ($RH$) and the saturation vapor pressure:
    
    $$
    \begin{aligned}
    e_s &= 0.61078 e^{\left(\frac{17.269 T}{237.3 + T}\right)} \\
    e_a &= RH * e_s / 100 \\
    VPD &= e_s - e_a \\
    \end{aligned}
    $$ {#eq-spinifex-vapour-pressure-deficit}

    ::: {.callout-note}
    It can be difficult to find consistent English language sources for Tetens
    equation, with slight differences from different sources. For AFDRS, the 
    equation from 
    [Tetens equation](https://en.wikipedia.org/wiki/Tetens_equation) for 
    temperatures above 0 °C, as referenced from @monteith2008 was used. 
    :::    

    The percentage of dead fuel moisture ($MC_d$) is calculated using the
    following logistic regression model:

    $$
    \begin{aligned}
    lMC_d &= -9.3400 - 0.37649 RH + 3.1759 \ln(RH) + 0.068057 RH \ln(RH) \\
    MC_d &= \frac{1}{1 + e^{-lMC_d}} * 100
    \end{aligned}
    $$ {#eq-spinifex-dead-fuel-moisture}

    ::: {.callout-note}
    In calculating $\ln(RH)$, the relative humidity is first clipped to 1 - 100%
    to avoid ln(0) errors. It is not clipped for the $RH$-only term.
    :::

    Finally, the total fuel moisture $MC$ (%) is calculated by converting the
    moisture content of the dead and live fuel covers by their respective
    proportions, and then summing them:
    
    $$
    \begin{aligned}
    C_l &= C_T - C_d \\
    MC &= \frac{MC_l C_l + MC_d C_d}{C_T}
    \end{aligned}
    $$ {#eq-spinifex-total-fuel-moisture}

    where $C_l$ represents the live fuel cover and $C_d$ was calculated above.

    ### Implementation Details

    The relative soil moisture content ($AWAP_{uf}$) is calculated and provided
    by the Bureau of Meteorology as in input to AFDRS, using the relative root
    zone soil moisture calculations from the Australian Water Resources
    Assessment Landscape model [AWRA-Lv7, @viney2015]

    Clipping of $TSF$ to 1-25 years is done before passing it to this function,
    in the `calculate` function. If you are calling this function directly, you
    will need to clip $TSF$ yourself.

    ### Usage

    ```python
    fuel_moisture = calc_fuel_moisture(
        AWAP_uf, time_since_fire, relative_humidity, air_temperature, fuel_cover
    )
    ```

    ### Parameters

    - **AWAP_uf** (*array-like*) Relative soil moisture content (%)
    - **time_since_fire** (*array-like*) Time since fire (years)
    - **relative_humidity** (*array-like*) Relative humidity (%)
    - **air_temperature** (*array-like*) Air temperature (°C)
    - **fuel_cover** (*array-like*) Total fuel cover (%)

    ### Returns

    - **fuel_moisture** (*array-like*) Fuel moisture (%)
    """

    def calc_vpd(air_temperature, relative_humidity):
        """Vapor pressure deficit"""
        es = 0.61078 * np.exp(
            (17.269 * air_temperature) / (237.3 + air_temperature)
        )
        return es - (relative_humidity * es / 100)

    def dead_cov(time_since_fire):
        """Dead fuel cover percentage"""
        lp = (
            -4.0936696
            + 0.8619864 * time_since_fire
            - 1.6136030 * np.log(time_since_fire)
            - 0.1739302 * time_since_fire * np.log(time_since_fire)
        )
        # TODO: check why this is not * 100, but the others are
        # See https://gitlab.com/afdrs/afdrs-dev/packages/python-packages/fdrs_calcs/-/issues/31
        return 1 / (1 + np.exp(-lp))

    def fmc_live(AWAP_uf, fuel_cover, vpd):
        """Live fuel moisture percentage"""
        lp = (
            0.419130229421894
            + 0.158980195 * np.sqrt(AWAP_uf)
            - 0.271357085 * np.sqrt(fuel_cover)
            - 0.007380343 * vpd
        )
        return (1 / (1 + np.exp(-lp))) * 100

    def fmc_dead(relative_humidity):
        """Dead fuel moisture percentage"""
        # clip relative humidity to 1-100% to avoid log(0) errors
        log_rh = np.log(np.clip(relative_humidity, 1, 100))
        lp = (
            -9.34004475
            - 0.37649308 * relative_humidity
            + 3.17594774 * log_rh
            + 0.06805771 * relative_humidity * log_rh
        )
        return np.nan_to_num((1 / (1 + np.exp(-lp))) * 100)

    # Compute % dead cover
    pct_dead = dead_cov(time_since_fire)

    # Compute VPD
    vpd = calc_vpd(air_temperature, relative_humidity)

    # Compute live fuel moisture
    live = fmc_live(AWAP_uf, fuel_cover, vpd)

    # Compute dead fuel moisture
    dead = fmc_dead(relative_humidity)

    # Compute total fuel moisture from proportion of dead to live cover versus
    # total fuel cover
    fmc_tot = (
        (live * (fuel_cover - pct_dead)) + (dead * pct_dead)
    ) / fuel_cover

    return fmc_tot


def calc_spread_index(wind_speed_10m, fuel_moisture, fuel_cover, wrf):
    r"""
    Calculate spread index

    ### Technical Guide

    Estimating fire behaviour in spinifex vegetation follows a two-step process:
    (i) determining the probability that a fire will spread ("go/no-go"); (ii)
    predicting the rate of spread, flame height and intensity.

    To determine if a fire will spread, a spread index ($SI$) logistic
    regression model was developed by @holmes2023:

    $$
    \begin{aligned}
    lSI &= -5.8577 + 0.33694 U_{1.7} - 0.49640 MC + 0.27248 C_T \\
    SI &= \frac{e^{lSI}}{1 + e^{lSI}}
    \end{aligned}
    $$ {#eq-spinifex-spread-index}

    where $U_{1.7}$ is the 1.7m wind speed (km/h), $MC$ is the combined dead &
    live fuel moisture (%), and $C_T$ is the total fuel cover (%).

    In order to convert the 10m wind speed ($U_{10}$) to 1.7m wind speed
    ($U_{1.7}$), a wind reduction factor ($WRF$) is provided by the
    jurisdictional fire agencies in the fuel parameters table. This is used to
    calculate the 1.7m wind speed as:

    $$
    U_{1.7} = WRF * U_{10}
    $$ {#eq-spinifex-wind-speed}

    The calculated spread index will range from 0.0 to 1.0, with higher values
    indicating higher probability of fire spread.

    ### Usage

    ```python
    spread_index = calc_spread_index(
        wind_speed_10m, fuel_moisture, fuel_cover, wrf
    )
    ```

    ### Parameters

    - **wind_speed_10m** (*array-like*) 10m wind speed (km/h)
    - **fuel_moisture** (*array-like*) Combined Dead & Live fuel moisture (%)
    - **fuel_cover** (*array-like*) Total fuel cover (%)
    - **wrf** (*float*) Wind reduction factor

    ### Returns

    - **spread_index** (*array-like*) Spread index (0.0 - 1.0)
    """
    intercept_value = -5.856812517808251
    wind_speed_coefficient = 0.33694008855397894
    fuel_moisture_coefficient = -0.4964041354255363
    fuel_cover_coefficient = 0.27247526035326597

    # Conversion of 10m wind speed to 1.7m wind speed.
    wind_speed_1_7m = wind_speed_10m * wrf

    # calculate the linear predictions
    lin_preds = (
        intercept_value
        + (wind_speed_coefficient * wind_speed_1_7m)
        + (fuel_moisture_coefficient * fuel_moisture)
        + (fuel_cover_coefficient * fuel_cover)
    )

    # convert to spread index
    spread_index = np.exp(lin_preds) / (1 + np.exp(lin_preds))

    return spread_index


def calc_rate_of_spread(wind_speed_10m, fuel_moisture, fuel_cover, wrf):
    r"""
    Calculate rate of spread (m/h)

    ### Technical Guide

    The rate of spread ($ROS$) is calculated using the following equation from
    @burrows2018:

    $$
    ROS = 40.982 \frac{U_{1.7}^{1.399} C_T^{1.201}}{MC^{1.699}}
    $$ {#eq-spinifex-rate-of-spread}

    where $U_{1.7}$ is the 1.7m wind speed (km/h), $MC$ is the combined (live
    and dead) fuel moisture (%), and $C_T$ is the total (live and dead) fuel
    cover (%).

    In order to convert the 10m wind speed ($U_{10}$) to 1.7m wind speed
    ($U_{1.7}$), a wind reduction factor ($WRF$) is provided by the
    jurisdictional fire agencies in the fuel parameters table. This is used to
    calculate the 1.7m wind speed as:

    $$
    U_{1.7} = WRF * U_{10}
    $$ {#eq-spinifex-wind-speed}

    ::: {.callout-note}
    The rate of spread calculations are not directly affected by the spread
    index, and will still return values even if the spread index is low. The
    effect of the spread index is only included when calculating the fire
    behaviour index itself.
    :::

    ### Usage

    ```python
    rate_of_spread = calc_rate_of_spread(
        wind_speed_10m, fuel_moisture, fuel_cover, wrf
    )
    ```

    ### Parameters

    - **wind_speed_10m** (*array-like*) 10m wind speed (km/h)
    - **fuel_moisture** (*array-like*) Combined dead & live fuel moisture (%)
    - **fuel_cover** (*array-like*) Total fuel cover (%)
    - **wrf** (*float*) Wind reduction factor

    ### Returns

    - **rate_of_spread** (*array-like*) Rate of spread (m/h)
    """
    # Conversion of 10m wind speed to 1.7m wind speed.
    wind_speed_1_7m = wind_speed_10m * wrf

    # Calculate rate of spread
    rate_of_spread = 40.982 * (
        (np.power(wind_speed_1_7m, 1.399) * np.power(fuel_cover, 1.201))
        / (np.power(fuel_moisture, 1.699))
    )

    return rate_of_spread


def calc_intensity(rate_of_spread, fuel_load):
    r"""
    Calculate fireline intensity (kW/m)

    ### Technical Guide

    The fireline intensity is calculated using the @byram1959 equation:

    $$
    I = h \times F \times ROS
    $$ {#eq-intensity}

    where $h$ is the heat yield, assumed here to be 16,700 kJ/kg (Malcolm
    Possell pers comm.), $F$ is the fuel load (kg/m^2), and $ROS$ is the rate of
    spread (m/s).

    ### Implementation Details

    This function is just a light wrapper around the
    `common.calc_fire_intensity` function, which is used by multiple fuel
    models.

    ### Usage

    ```python
    intensity = calc_intensity(rate_of_spread, fuel_load)
    ```

    ### Parameters

    - **rate_of_spread** (*array-like*) Rate of spread (m/h)
    - **fuel_load** (*array-like*) Fuel load (t/ha)

    ### Returns

    - **intensity** (*array-like*) Fireline intensity (kW/m)
    """
    return common.calc_fire_intensity(rate_of_spread, fuel_load, HEAT_CONTENT)


def calc_flame_height(rate_of_spread, fuel_load):
    r"""Calculate flame height in m

    ### Technical Guide

    Flame height (m) is calculated using the following equation from
    @burrows2018:

    $$
    H = 0.097 ROS^{0.424} + 0.102 F
    $$ {#eq-flame-height}

    where $ROS$ is the rate of spread (m/h) and $F$ is the fuel load (t/ha).

    ### Usage

    ```python
    flame_height = calc_flame_height(rate_of_spread, fuel_load)
    ```

    ### Parameters

    - **rate_of_spread** (*array-like*) Rate of spread (m/h)
    - **fuel_load** (*array-like*) Fuel load (t/ha)

    ### Returns

    - **flame_height** (*array-like*) Flame height (m)
    """
    flame_height = 0.097 * np.power(rate_of_spread, 0.424) + 0.102 * fuel_load

    return flame_height


def calc_spotting_distance(air_temperature):
    r"""Calculate spotting distance

    ### Technical Guide

    A spotting model is not currently implemented for spinifex.

    ### Implementation Details

    As a spotting fuction is not currently implemented for spinifex, this
    function just returns and array of NaNs of the same shape as the
    `air_temperature` parameter.

    ### Usage

    ```python
    spotting_distance = calc_spotting_distance(air_temperature)
    ```

    ### Parameters

    - **air_temperature** (*array-like*) Air temperature (°C)

    ### Returns

    - **spotting_distance** (*array-like*) Spotting distance (m)
    """
    return np.full(air_temperature.shape, np.nan)


def calculate(
    dataset: SpinifexInputVariables, fuel_parameters: SpinifexFuelParameters
) -> SpinifexOutputIndices:
    r"""
    Main entry point for spinifex fire behaviour calculations

    ### Technical Guide

    ::: {.callout-note}
    AWRA/AWUP_uf must be in %fullness between 0-100. if 0-1 supplied then this
    needs to be multiplied by 100
    :::

    ### Usage

    ```python
    indices = calculate(dataset, fuel_parameters)
    ```

    ### Parameters

    - **dataset** (*dict*) - A dictionary of *array_like* containing the input
      variables.

        From these input variables, only the following are used by this model:

        - **T_SFC** - Surface air temperature (°C)
        - **RH_SFC** - Relative humidity (%)
        - **WindMagKmh_10m** : Wind magnitude at 10m (km/h)
        - **AWAP_uf** - Relative soil moisture content (%)
        - **time_since_fire** - Time since fire (years)

    - **fuel_parameters** A dictionary of scalars containing the fuel
      parameters.

        From these fuel parameters, only the following are used by this model:

            - **WF_Sav** (*float*) - Wind reduction factor
            - **FTno_FDR** (*int*) - Fuel type number

    ### Returns

    - **indices** (*dict*) - A dictionary of *array_like* containing the
        output variables of the same shape as the input variables with the
        following keys:

        - **dead_fuel_moisture** - Combined live/dead fuel moisture (%)
        - **rate_of_spread** - Rate of spread (m/h)
        - **spread_index** - Spread index (0.0 - 1.0)
        - **flame_height** - Flame height (m)
        - **intensity** - Fireline intensity (kW/m)
        - **spotting_distance** - Spotting distance (m)
        - **rating_1** - Fire danger rating
        - **index_1** - Fire behaviour index
    """
    # standardize the dataset variables
    dataset = standardize_dataset_variables(dataset)

    wind_reduction_factor = fuel_parameters["WF_Sav"]

    # TODO Clarify if wrf clip is being done elsewhere during ingestion of FLUT.
    # Not currently implemented by BoM.
    # This will be covered alongside other work with respect to wind reduction
    # factors in https://gitlab.com/afdrs/afdrs-dev/packages/python-packages/fdrs_calcs/-/issues/29

    # check if fuel type is spinifex woodland (FTno_FDR == 450)
    fuel_is_spinifex_woodland = fuel_parameters["FTno_FDR"] == 450

    # clip the time since fire to 1-25 years
    time_since_fire = dataset["time_since_fire"]
    time_since_fire = np.clip(time_since_fire, 1, 25)
    # calculate natural log of time since fire
    log_tsf = np.log(time_since_fire)

    # convert AWRA/AWUP_uf to percentage
    soil_moisture_pct = dataset["AWAP_uf"] * 100

    # calculate fuel load
    fuel_load = calc_fuel_load(
        time_since_fire,
        log_tsf,
        fuel_is_spinifex_woodland,
    )

    # calculate fuel cover
    fuel_cover = calc_fuel_cover(
        time_since_fire,
        log_tsf,
        fuel_is_spinifex_woodland,
    )

    # calculate fuel moisture
    fuel_moisture = calc_fuel_moisture(
        soil_moisture_pct,
        time_since_fire,
        dataset["RH_SFC"],
        dataset["T_SFC"],
        fuel_cover,
    )

    # calculate spread index
    spread_index = calc_spread_index(
        dataset["WindMagKmh_10m"],
        fuel_moisture,
        fuel_cover,
        wind_reduction_factor,
    )

    # calculate rate of spread
    rate_of_spread = calc_rate_of_spread(
        dataset["WindMagKmh_10m"],
        fuel_moisture,
        fuel_cover,
        wind_reduction_factor,
    )

    # calculate flame height
    flame_height = calc_flame_height(rate_of_spread, fuel_load)

    # calculate fire intensity
    intensity = calc_intensity(rate_of_spread, fuel_load)

    # calculate spotting distance
    spotting_distance = calc_spotting_distance(dataset["T_SFC"])

    # calculate fire danger rating and fire behaviour index from spread_index
    # and rate_of_spread
    index_1 = fire_behaviour_index.spinifex(spread_index, rate_of_spread)
    rating_1 = fire_danger_rating.fire_danger_rating(index_1)

    return {
        "dead_fuel_moisture": fuel_moisture,
        "rate_of_spread": rate_of_spread,
        "spread_index": spread_index,
        "flame_height": flame_height,
        "intensity": intensity,
        "spotting_distance": spotting_distance,
        "rating_1": rating_1,
        "index_1": index_1,
    }
