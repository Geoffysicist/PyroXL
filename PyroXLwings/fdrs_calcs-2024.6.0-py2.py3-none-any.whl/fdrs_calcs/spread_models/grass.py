r"""
Fire behaviour calculations for grasslands

## Technical Guide

Grass includes continuous and tussock grasslands. This is the fuel that the
CSIRO grassland model was specifically developed for, so it does not have
additional variation applied as a sub-fuel.
"""

from . import fire_behaviour_index
from . import fire_danger_rating
from .. import typing as ft
from .common import standardize_dataset_variables

from .csiro_grassland import calc_fuel_moisture
from .csiro_grassland import calc_rate_of_spread
from .csiro_grassland import calc_intensity
from .csiro_grassland import calc_flame_height
from .csiro_grassland import calc_spotting_distance

HEAT_CONTENT = 18600  # KJ/kg
KGSQM_TO_TPH = 10.0
M_PER_KM = 1000
SECONDS_PER_HOUR = 3600  # s


# add additional type hints for grassland specific inputs
class GrassInputVariables(ft.CommonInputVariables):
    r"""Grassland specific additional input variables"""

    Curing_SFC: ft.Curing_SFC_Array
    grass_condition: ft.grass_condition_Array
    GrassFuelLoad_SFC: ft.GrassFuelLoad_SFC_Array


def calculate(
    dataset: GrassInputVariables, fuel_parameters: ft.NoFuelParameters
) -> ft.CommonOutputIndices:
    r"""
    Main entry point for grassland fire behaviour calculations.

    ### Implementation Details

    This model is based on the CSIRO grassland model, with the grass condition
    and grass fuel loads provided as grid-level inputs. No fuel parameters are
    used for this model.

    ### Usage

    ```python
    indices = grass.calculate(dataset, fuel_parameters)
    ```

    ### Parameters

    - **dataset** (*dict*) - A dictionary of *array_like* containing the input
        variables.

        From these input variables, only the following are used by this model

        - **T_SFC** : Surface temperature (C)
        - **RH_SFC** : Surface relative humidity (%)
        - **WindMagKmh_10m** : Wind magnitude at 10m (km/h)
        - **Curing_SFC** : Surface grassland curing (%)
        - **grass_condition** : Grass condition (3-1, corresponding to natural,
            grazed, eaten out)
        - **GrassFuelLoad_SFC** : Surface grass fuel load (tonnes/ha)

    - **fuel_parameters** A dictionary of scalars containing the fuel
      parameters.

        These are not used by this model.

    ### Returns

    - **indices** (*dict*) - A dictionary of *array_like* containing the output
      variables of the same shape as the input arrays with the following keys

        - **dead_fuel_moisture** : Dead fuel moisture content (%)
        - **rate_of_spread** : Rate of spread (m/hr)
        - **flame_height** : Flame height (m)
        - **intensity** : Fire intensity (kW/m)
        - **spotting_distance** : Spotting distance (m)
        - **rating_1** : Fire danger rating (unitless)
        - **index_1** : Fire behaviour index (unitless)
    """
    # standardize the dataset variables
    dataset = standardize_dataset_variables(dataset)

    # Calculate dead fuel moisture content
    dead_fuel_moisture = calc_fuel_moisture(dataset["T_SFC"], dataset["RH_SFC"])

    # Calculate rate of spread from the dead fuel moisture content, wind speed,
    # curing and grass condition
    rate_of_spread = calc_rate_of_spread(
        dead_fuel_moisture,
        dataset["WindMagKmh_10m"],
        dataset["Curing_SFC"],
        dataset["grass_condition"],
    )

    # Calculate flame height from the rate of spread and the fuel load
    flame_height = calc_flame_height(rate_of_spread, dataset["grass_condition"])

    # Calculate fire intensity from the rate of spread and the fuel load
    intensity = calc_intensity(rate_of_spread, dataset["GrassFuelLoad_SFC"])

    # Calculate spotting distance from the surface temperature
    spotting_distance = calc_spotting_distance(dataset["T_SFC"])

    # Calculate fire danger rating and fire behaviour index from the intensity
    # only
    index_1 = fire_behaviour_index.grass(intensity)
    rating_1 = fire_danger_rating.fire_danger_rating(index_1)

    # return the outputs
    return {
        "dead_fuel_moisture": dead_fuel_moisture,
        "rate_of_spread": rate_of_spread,
        "flame_height": flame_height,
        "intensity": intensity,
        "spotting_distance": spotting_distance,
        "rating_1": rating_1,
        "index_1": index_1,
    }
