r"""Fire behaviour calculations for low wetland

## Technical Guide

Wetland with low or no overstorey; for example, low swamp heath, sedgeland, and
rushland. Fuel availability is limited by moisture content in this sub-type.
Drought and lowering of the water table will increase the flammability of this
fuel. This sub-fuel has no influence on setting FDRs and only covers 0.6% of
Australia. Both the buttongrass and grassland models were considered for this
sub-fuel. Buttongrass is most suitable for coastal swamps where there is
flammable material above inundated ground, however the substantial majority of
the low wetland fuel type is inland floodplain wetlands where fire is most
likely to be associated with ephemeral grass growth, so the grassland model with
the eaten out fuel condition was chosen.
"""
from . import chenopod
from .. import typing as ft

def calculate(
    dataset : chenopod.ChenopodInputVariables,
    fuel_parameters : ft.NoFuelParameters
) -> ft.CommonOutputIndices:
    r"""
    Main entry point for low wetland fire behaviour calculations.

    ### Implementation Details

    In the current implementation, low wetland is treated identically as
    chenopod, so refer to that sub-fuel for more information on the
    implementation.    
    """
    return chenopod.calculate(dataset, fuel_parameters)
