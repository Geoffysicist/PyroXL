r"""
Fire behaviour calculations for rural areas

## Technical Guide

This sub-fuel is for rural residential areas and hobby farms, which typically
consist of continuous grass with variable tree cover. Fuel management strategies
in this fuel sub-type may be highly variable. This sub-fuel uses the grazed
grass condition.

"""

import numpy as np

from . import fire_behaviour_index
from . import fire_danger_rating
from .. import typing as ft
from .common import standardize_dataset_variables

from .csiro_grassland import calc_fuel_moisture
from .csiro_grassland import calc_rate_of_spread
from .csiro_grassland import calc_flame_height
from .csiro_grassland import calc_intensity
from .csiro_grassland import calc_spotting_distance
from .csiro_grassland import GRASS_CONDITION_GRAZED

from . import savanna


# add additional type hints for rural specific inputs
class RuralInputVariables(ft.CommonInputVariables):
    r"""Rural specific additional input variables"""

    Curing_SFC: ft.Curing_SFC_Array
    GrassFuelLoad_SFC: ft.GrassFuelLoad_SFC_Array


def calculate(
    dataset: RuralInputVariables,
    fuel_parameters: savanna.SavannaFuelParameters,
) -> ft.CommonOutputIndices:
    r"""
    Main entry point for calculating fire behaviour in rural areas.

    ### Implementation Details

    Implemented using the CSIRO Grassland Fire Spread Model, with the following
    modifications:

    - The grass condition is set to `GRASS_CONDITION_GRAZED`
    - A provided wind reduction factor (`WF_Sav`) is applied to the calculated
      rate of spread

    ### Usage

    ```python
    indices = rural.calculate(dataset, fuel_parameters)
    ```

    ### Parameters

    - **dataset** (*dict*) - A dictionary of *array_like* containing the input
        variables.

        From these input variables, only the following are used by this model

        - **T_SFC** : Surface temperature (C)
        - **RH_SFC** : Relative humidity (%)
        - **WindMagKmh_10m** : Wind magnitude at 10m (km/h)
        - **Curing_SFC** : Fuel curing (%)
        - **GrassFuelLoad_SFC** : Grass fuel load (kg/m^2)

    - **fuel_parameters** A dictionary of scalars containing the fuel
      parameters.

        For this model the following parameters are used

        - **WF_Sav** : Wind reduction factor (unitless)

    ### Returns

    - **indices** (*dict*) - A dictionary of *array_like* containing the output
        variables of the same shape as the input arrays with the following keys

        - **dead_fuel_moisture** : Dead fuel moisture content (%)
        - **rate_of_spread** : Rate of spread (m/hr)
        - **flame_height** : Flame height (m)
        - **intensity** : Fire intensity (kW/m)
        - **spotting_distance** : Spotting distance (m)
        - **rating_1** : Fire danger rating (unitless)
        - **index_1** : Fire behaviour index (unitless)
    """
    # standardize the dataset variables
    dataset = standardize_dataset_variables(dataset)

    # Calculate dead fuel moisture content
    dead_fuel_moisture = calc_fuel_moisture(dataset["T_SFC"], dataset["RH_SFC"])

    # Calculate rate of spread from the dead fuel moisture content, wind speed
    # and curing using the CSIRO grassland model. However, for rural, we set the
    # grass condition to GRASS_CONDITION_GRAZED, and multiply by the wind
    # reduction factor (WF_Sav) to account for the reduced wind speed due to the
    # presence of trees.
    rate_of_spread = calc_rate_of_spread(
        dead_fuel_moisture,
        dataset["WindMagKmh_10m"],
        dataset["Curing_SFC"],
        np.full(dataset["WindMagKmh_10m"].shape, GRASS_CONDITION_GRAZED),
    )
    rate_of_spread = rate_of_spread * fuel_parameters["WF_Sav"]

    # calculate the flame height from the rate of spread using the CSIRO
    # grassland model, with a grass condition of GRASS_CONDITION_GRAZED
    flame_height = calc_flame_height(
        rate_of_spread, np.full(rate_of_spread.shape, GRASS_CONDITION_GRAZED)
    )

    # Calculate fire intensity from the rate of spread and the fuel load
    intensity = calc_intensity(rate_of_spread, dataset["GrassFuelLoad_SFC"])

    # Calculate spotting distance from the surface temperature
    spotting_distance = calc_spotting_distance(dataset["T_SFC"])

    # Calculate fire danger rating and fire behaviour index from the intensity
    index_1 = fire_behaviour_index.grass(intensity)
    rating_1 = fire_danger_rating.fire_danger_rating(index_1)

    # return the outputs
    return {
        "dead_fuel_moisture": dead_fuel_moisture,
        "rate_of_spread": rate_of_spread,
        "flame_height": flame_height,
        "intensity": intensity,
        "spotting_distance": spotting_distance,
        "rating_1": rating_1,
        "index_1": index_1,
    }
