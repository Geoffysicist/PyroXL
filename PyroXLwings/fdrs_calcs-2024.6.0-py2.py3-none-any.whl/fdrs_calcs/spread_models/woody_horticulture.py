r"""
Fire behaviour calculations for woody_horticulture

## Technical Guide

Perennial woody horticulture which usually has a managed (morn and/or irrigated)
grass understorey. This includes orchards and vineyards. Some fire propagation
is possible in this sub-fuel, however the condition of potential fuel will be
highly variable. This sub-fuel uses the eaten-out grass condition.
"""
from .. import typing as ft
from . import acacia_woodland


def calculate(
    dataset : acacia_woodland.AcaciaWoodlandInputVariables,
    fuel_parameters : acacia_woodland.AcaciaWoodlandFuelParameters
) -> ft.CommonOutputIndices:
    r"""
    Main entry point for woody_horticulture fire behaviour calculations.

    ### Implementation Details

    In the current implementation, woody_horticulture is treated identically as
    acacia_woodland, so refer to that sub-fuel for more information on the
    implementation. 
    """

    return acacia_woodland.calculate(dataset, fuel_parameters)
