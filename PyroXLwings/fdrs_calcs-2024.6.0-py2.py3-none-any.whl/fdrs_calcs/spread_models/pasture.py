r"""
Fire behaviour calculations for pasture

## Technical Guide

Modified or native pasture where the primary land use is grazing. The fuel
availability will vary depending on the land management approach used. This
sub-fuel does not have a specific variation set for AFDRS (fuel condition is set
by reported fuel load).
"""
from . import grass
from .. import typing as ft

def calculate(
    dataset : grass.GrassInputVariables,
    fuel_parameters : ft.NoFuelParameters
) -> ft.CommonOutputIndices:
    r"""
    Main entry point for pasture fire behaviour calculations.

    ### Implementation Details

    In the current implementation, pasture is treated identically as grass,
    so refer to that sub-fuel for more information on the implementation.
    """

    return grass.calculate(dataset, fuel_parameters)
