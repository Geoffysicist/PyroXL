r"""
Fire Behaviour Index (FBI) calculations

## Technical Guide

The Fire Behaviour Index (FBI) is an index that can be used consistently across
all eight models, allowing users to make decisions that require more detail than
the four rating categories allow and to identify conditions where the index is
near the top or bottom of a rating category.

Thresholds between columns in the (up to) six FBI definitions
(<https://fdv.afdrs.org.au/definitions>) translate to memorable, round numbers
similar to those used in the previous FFDI/GFDI system.

* For index values from 0 to 100, linear scaling between threshold values is
  used.

* For index values above the top threshold, a scale that gives a similar
  increase in FBI with fire behaviour metric to that used in the next highest
  range is used, aiming to have known 'reasonable worst case' historical fires
  around 200.

FBI values are based on continuous quantities such as rate of spread. This means
that the assignment of threshold values (6, 12, 24, 50, 100) to defined FBI
ranges can be ambiguous. To avoid this ambiguity in published FBI products,
calculated values are rounded down to the nearest whole number (for example, a
FBI of 5.999 would be rounded down to 5). In published tables, the rounding down
is expressed by having the upper bound expressed as the largest whole number in
that FBI range.

| FBI Range          | Colour                 |
| ------------------ | ---------------------- |
| [0 - 5]{.fbinrl}   | \fbinrl{} Dark Purple  |
| [6 - 11]{.fbinrh}  | \fbinrh{} Mid Purple   |
| [12 - 23]{.fbimod} | \fbimod{} Light Purple |
| [24 - 49]{.fbihi}  | \fbihi{}  Yellow       |
| [50 - 99]{.fbiex}  | \fbiex{}  Orange       |
| [100 +]{.fbicat}   | \fbicat{} Red          |

: Fire Behaviour Index ranges and their associated colours 
    {#tbl-fbi-ranges}
"""

import numpy as np

# Common 'round numbers' to be used for all fuel types
FBI_thresholds = [0, 6, 12, 24, 50, 100]

# High values to anchor FBI above the top threshold at 200, based on the
# Killmore East Fire during the 2009 'Black Saturday' fires
FBI_HIGH = 200
INTENSITY_HIGH = 90000


def _fbi_from_thresholds(metric, thresholds, METRIC_HIGH):
    r"""Calculate FBI based on metric and thresholds

    ### Implementation Details

    Between each of the FBI and metric thresholds, FBI is linearly
    interpolated, and above the top metric threshold it is set to be 100 at the
    top metric threshold and continue indefinitely such that the top metric
    threshold has a FBI of 200.

    ### Usage

    ```python
    thresholds = [0, 100, 3000, 9000, 17500, 25000]
    metric = np.random.uniform(0, 25000, size=(10, 10))
    FBI = _fbi_from_thresholds(metric, thresholds)
    ```

    ### Parameters

    - **metric** (*array_like*) - Metric to calculate FBI from
    - **thresholds** (*array_like*) - Thresholds to use for FBI calculation.
      Should be six values to be one more than the number of FBI categories.
    - **METRIC_HIGH** (*float*) - Arbitrary high value to anchor FBI above the
        top threshold

    ### Returns

    - **FBI** (*array_like*) - Fire Behaviour Index (dimensionless)
    """
    # setup FBI array the same shape as metric
    FBI = np.full(metric.shape, np.nan)

    # use numpy.interp to do the interpolation with the thresholds
    mask = metric < thresholds[-1]
    FBI[mask] = np.interp(metric[mask], thresholds, FBI_thresholds)

    # above top threshold scale so that METRIC_HIGH has FBI of FBI_HIGH, but
    # continue rising above that if metric is greater than METRIC_HIGH
    mask = metric >= thresholds[-1]
    FBI[mask] = FBI_thresholds[-1] + (FBI_HIGH - FBI_thresholds[-1]) * (
        metric[mask] - thresholds[-1]
    ) / (METRIC_HIGH - thresholds[-1])

    # round to nearest integer
    FBI = np.trunc(FBI)

    return FBI


def forest(intensity):
    r"""
    Calculate FBI for forest and related fuel types

    ### Technical Guide

    The forest FBI is calculated based on the fireline intensity (kW/m), and is
    aligned to have round number values at the category boundaries in the fire
    danger rating definition tables. An additional category is added to anchor a
    FBI of 200 to a fire intensity of 90,000 kW/m - that of the Killmore East
    Fire during the 2009 'Black Saturday' fires.

    For forest, the intensity ranges are translated to FBI as follows:

    | Intensity range (kW/m) | FBI range                    |
    |------------------------|------------------------------|
    | 0 - 100                | \fbinrl{} [0 - 5]{.fbinrl}   |
    | 100 - 750              | \fbinrh{} [6 - 11]{.fbinrh}  |
    | 750 - 4,000            | \fbimod{} [12 - 23]{.fbimod} |
    | 4,000 - 10,000         | \fbihi{}  [24 - 49]{.fbihi}  |
    | 10,000 - 30,000        | \fbiex{}  [50 - 99]{.fbiex}  |
    | 30,000 +               | \fbicat{} [100 +]{.fbicat}   |

    : Fire Behaviour Index ranges for forest and related fuel types
        {#tbl-fbi-forest-ranges}

    ### Implementation Details

    Between each of the FBI and intensity thresholds, FBI is linearly
    interpolated, and above 30,000 kW/m it is set to be 100 at 30,000 kW/m and
    continue indefinitely such that 90,000 kW/m has a FBI of 200.

    ### Usage

    ```python
    FBI = forest(intensity)
    ```

    ### Parameters

    - **intensity** (*array_like*) - Fire intensity (kW/m)

    ### Returns

    - **FBI** (*array_like*) - Fire Behaviour Index (dimensionless)
    """
    intensity_thresholds = [0, 100, 750, 4000, 10000, 30000]

    return _fbi_from_thresholds(intensity, intensity_thresholds, INTENSITY_HIGH)


def pine(intensity):
    r"""
    Calculate FBI for pine and related fuel types

    ### Technical Guide

    The pine FBI is calculated based on the fireline intensity (kW/m), and is
    aligned to have round number values at the category boundaries in the fire
    danger rating definition tables. An additional category is added to anchor a
    FBI of 200 to a fire intensity of 90,000 kW/m - that of the Killmore East
    Fire during the 2009 'Black Saturday' fires.

    For pine, the intensity ranges are translated to FBI the same as for forest.

    | Intensity range (kW/m) | FBI range                    |
    |------------------------|------------------------------|
    | 0 - 100                | \fbinrl{} [0 - 5]{.fbinrl}   |
    | 100 - 750              | \fbinrh{} [6 - 11]{.fbinrh}  |
    | 750 - 4,000            | \fbimod{} [12 - 23]{.fbimod} |
    | 4,000 - 10,000         | \fbihi{}  [24 - 49]{.fbihi}  |
    | 10,000 - 30,000        | \fbiex{}  [50 - 99]{.fbiex}  |
    | 30,000 +               | \fbicat{} [100 +]{.fbicat}   |

    : Fire Behaviour Index ranges for pine and related fuel types
        {#tbl-fbi-pine-ranges}

    ### Implementation Details

    Because the thresholds are the same as for forest, the implementation is
    just a call to forest.

    ### Usage

    ```python
    FBI = pine(intensity)
    ```

    ### Parameters

    - **intensity** (*array_like*) - Fire intensity (kW/m)

    ### Returns

    - **FBI** (*array_like*) - Fire Behaviour Index (dimensionless)
    """
    return forest(intensity)


def grass(intensity):
    r"""
    Calculate FBI for grassland and related fuel types

    ### Technical Guide

    The grassland FBI is calculated based on the fireline intensity (kW/m), and
    is aligned to have round number values at the category boundaries in the
    fire danger rating definition tables. An additional category is added to
    anchor a FBI of 200 to a fire intensity of 90,000 kW/m - that of the
    Killmore East Fire during the 2009 'Black Saturday' fires.

    For grassland, the intensity ranges are translated to FBI as follows:

    | Intensity range (kW/m) | FBI range                    |
    |------------------------|------------------------------|
    | 0 - 100                | \fbinrl{} [0 - 5]{.fbinrl}   |
    | 100 - 3,000            | \fbinrh{} [6 - 11]{.fbinrh}  |
    | 3,000 - 9,000          | \fbimod{} [12 - 23]{.fbimod} |
    | 9,000 - 17,500         | \fbihi{}  [24 - 49]{.fbihi}  |
    | 17,500 - 25,000        | \fbiex{}  [50 - 99]{.fbiex}  |
    | 25,000 +               | \fbicat{} [100 +]{.fbicat}   |

    : Fire Behaviour Index ranges for grassland and related fuel types
        {#tbl-fbi-grass-ranges}

    ### Implementation Details

    Between each of the FBI and intensity thresholds, FBI is linearly
    interpolated, and above 25,000 kW/m it is set to be 100 at 25,000 kW/m and
    continue indefinitely such that 90,000 kW/m has a FBI of 200.

    ### Usage

    ```python
    FBI = grass(intensity)
    ```

    ### Parameters

    - **intensity** (*array_like*) - Fire intensity (kW/m)

    ### Returns

    - **FBI** (*array_like*) - Fire Behaviour Index (dimensionless)
    """

    intensity_thresholds = [0, 100, 3000, 9000, 17500, 25000]

    return _fbi_from_thresholds(intensity, intensity_thresholds, INTENSITY_HIGH)


def heathland(rate_of_spread):
    r"""
    Calculate FBI for shrubland and related fuel types

    ### Technical Guide

    For shrublands the fire behaviour metric is rate of spread (m/hr), and is
    aligned to have round number values at the category boundaries in the fire
    danger rating definition tables. An additional category is added to anchor a
    FBI of 200 to a rate of spread of 30,000 m/hr - that of the Killmore East
    Fire during the 2009 'Black Saturday' fires.

    |   Rate of Spread (m/hr)   |   FBI range                  |
    | ------------------------- | ---------------------------- |
    | 0 - 1,250                 | \fbinrl{} [0 - 5]{.fbinrl}   |
    | 1,250 - 2,300             | \fbinrh{} [6 - 11]{.fbinrh}  |
    | 2,300 - 3,800             | \fbimod{} [12 - 23]{.fbimod} |
    | 3,800 - 7,000             | \fbihi{}  [24 - 49]{.fbihi}  |
    | 7,000 - 14,000            | \fbiex{}  [50 - 99]{.fbiex}  |
    | 14,000 +                  | \fbicat{} [100 +]{.fbicat}   |

    : Fire Behaviour Index ranges for shrubland and related fuel types
        {#tbl-fbi-heathland-ranges}

    ### Implementation Details

    Between each of the FBI and rate of spread thresholds, FBI is linearly
    interpolated, and above 14,000 m/hr it is set to be 100 at 14,000 m/hr and
    continue indefinitely such that 30,000 m/hr has a FBI of 200.

    ### Usage

    ```python
    FBI = heathland(rate_of_spread)
    ```

    ### Parameters

    - **rate_of_spread** (*array_like*) - Rate of spread (m/hr)

    ### Returns

    - **FBI** (*array_like*) - Fire Behaviour Index (dimensionless)
    """
    rate_of_spread_thresholds = [0, 1250, 2300, 3800, 7000, 14000]
    rate_of_spread_high = 30000

    return _fbi_from_thresholds(
        rate_of_spread, rate_of_spread_thresholds, rate_of_spread_high
    )


def buttongrass(rate_of_spread):
    r"""
    Calculate FBI for buttongrass

    ### Technical Guide

    The buttongrass FBI is calculated based on the rate of spread (m/hr), and
    is aligned to have round number values at the category boundaries in the
    fire danger rating definition tables. An additional category is added to
    anchor a FBI of 200 to a rate of spread of 16,800 m/hr.

    For buttongrass, the rate of spread ranges are translated to FBI as follows:

    | Rate of spread (m/hr) | FBI range                    |
    |-----------------------|------------------------------|
    | 0 - 30                | \fbinrl{} [0 - 5]{.fbinrl}   |
    | 30 - 480              | \fbinrh{} [6 - 11]{.fbinrh}  |
    | 480 - 2,040           | \fbimod{} [12 - 23]{.fbimod} |
    | 2,040 - 4,200         | \fbihi{}  [24 - 49]{.fbihi}  |
    | 4,200 - 8,400         | \fbiex{}  [50 - 99]{.fbiex}  |
    | 8,400 +               | \fbicat{} [100 +]{.fbicat}   |

    : Fire Behaviour Index ranges for buttongrass {#tbl-fbi-buttongrass-ranges}

    ### Implementation Details

    Between each of the FBI and rate of spread thresholds, FBI is linearly
    interpolated, and above 8,400 m/hr it is set to be 100 at 8,400 m/hr and
    continue indefinitely such that 16,800 m/hr has a FBI of 200.

    ### Usage

    ```python
    FBI = buttongrass(rate_of_spread)
    ```

    ### Parameters

    - **rate_of_spread** (*array_like*) - Rate of spread (m/hr)

    ### Returns

    - **FBI** (*array_like*) - Fire Behaviour Index (dimensionless)
    """
    rate_of_spread_thresholds = [0, 30, 480, 2040, 4200, 8400]
    rate_of_spread_high = 16800

    return _fbi_from_thresholds(
        rate_of_spread, rate_of_spread_thresholds, rate_of_spread_high
    )


def spinifex(spread_index, ros):
    r"""
    Calculate FBI for spinifex

    ### Technical Guide

    The spinifex FBI is calculated based on the spread index and rate of spread
    (m/hr), and is aligned to have round number values at the category
    boundaries in the fire danger rating definition tables. An additional
    category is added to anchor a FBI of 200 to a rate of spread of 20,000 m/hr.

    For spinifex, the spread index and rate of spread ranges are translated to
    FBI as follows:

    | Spread Index | Rate of spread (m/hr) | FBI range                    |
    |--------------|-----------------------|------------------------------|
    | $\leq$ 0.5   | *not used*            | \fbinrl{} [0]{.fbinrl}       |
    | > 0.5        | 0 - 500               | \fbinrl{} [0 - 5]{.fbinrl}   |
    | > 0.5        | 500 - 1,000           | \fbinrh{} [6 - 11]{.fbinrh}  |
    | > 0.5        | 1,000 - 2,500         | \fbimod{} [12 - 23]{.fbimod} |
    | > 0.5        | 2,500 - 4,500         | \fbihi{}  [24 - 49]{.fbihi}  |
    | > 0.5        | 4,500 - 8,000         | \fbiex{}  [50 - 99]{.fbiex}  |
    | > 0.5        | 8,000 +               | \fbicat{} [100 +]{.fbicat}   |

    : Fire Behaviour Index ranges for spinifex {#tbl-fbi-spinifex-ranges}

    ### Implementation Details

    Between each of the FBI and rate of spread thresholds, FBI is linearly
    interpolated, and above 8,000 m/hr it is set to be 100 at 8,000 m/hr and
    continue indefinitely such that 20,000 m/hr has a FBI of 200.

    ### Usage

    ```python
    FBI = spinifex(spread_index, ros)
    ```

    ### Parameters

    - **spread_index** (*array_like*) - Spread index (dimensionless)
    - **ros** (*array_like*) - Rate of spread (m/hr)

    ### Returns

    - **FBI** (*array_like*) - Fire Behaviour Index (dimensionless)
    """
    rate_of_spread_thresholds = [0, 500, 1000, 2500, 4500, 8000]
    rate_of_spread_high = 20000

    fbi = _fbi_from_thresholds(
        ros, rate_of_spread_thresholds, rate_of_spread_high
    )

    # if spread_index <= 0.5, FBI = 0
    mask = spread_index <= 0.5
    if mask.any():
        fbi[mask] = 0

    return fbi


def mallee_heath(spread_probability, crown_probability, intensity):
    r"""
    Calculate FBI for mallee heath

    ### Technical Guide

    The mallee heath FBI is calculated based on the spread probability, crown
    probability and fire intensity, and is aligned to have round number values
    at the category boundaries in the fire danger rating definition tables. An
    additional category is added to anchor a FBI of 200 to a fire intensity of
    90,000 kW/m - that of the Killmore East Fire during the 2009 'Black
    Saturday' fires.

    For mallee heath, the spread probability, crown probability and intensity
    ranges are translated to FBI as follows:

    +----------------+-------------+------------+------------------------------+
    | Spread         | Crown       | Intensity  | FBI range                    |
    | Probability    | Probability | (kW/m)     |                              |
    +================+=============+============+==============================+
    | 0 - 0.5        | *not used*  | *not used* | \fbinrl{} [0 -  5]{.fbinrl}  |
    +----------------+-------------+------------+------------------------------+
    | 0.5 +          | 0 - 0.33    | *not used* | \fbinrh{} [6 - 11]{.fbinrh}  |
    +----------------+-------------+------------+------------------------------+
    | 0.5 +          | 0.33 - 0.66 | *not used* | \fbimod{} [12 - 23]{.fbimod} |
    +----------------+-------------+------------+------------------------------+
    | 0.5 +          | 0.66 +      | 0 - 20,000 | \fbihi{}  [24 - 49]{.fbihi}  |
    +----------------+-------------+------------+------------------------------+
    | 0.5 +          | 0.66 +      | 20,000     | \fbiex{}  [50 - 99]{.fbiex}  |
    |                |             | - 40,000   |                              |
    +----------------+-------------+------------+------------------------------+
    | 0.5 +          | 0.99 +      | 40,000 +   | \fbicat{} [100 +]{.fbicat}   |
    +----------------+-------------+------------+------------------------------+

    : Fire Behaviour Index ranges for mallee heath
        {#tbl-fbi-mallee-heath-ranges}

    ### Implementation Details

    Between each of the FBI and metric thresholds, FBI is linearly
    interpolated using spread_probability for FBIs up to 5, then crown
    probability for FBIs up to 23, then intensity for all higher FBIs.

    Above the top metric threshold it is set to be 100 at the top metric
    threshold and continue indefinitely such that the 90,000 kW/m has a FBI of
    200.

    ### Usage

    ```python
    FBI = mallee_heath(spread_probability, crown_probability, intensity)
    ```

    ### Parameters

    - **spread_probability** (*array_like*) - Spread probability (dimensionless)
    - **crown_probability** (*array_like*) - Crown probability (dimensionless)
    - **intensity** (*array_like*) - Fire intensity (kW/m)

    ### Returns

    - **FBI** (*array_like*) - Fire Behaviour Index (dimensionless)
    """
    # setup nan FBI array the same shape as intensity
    FBI = np.full(intensity.shape, np.nan)

    # if 0 < spread_probability < 0.5, FBI = ranges from 0 to 5 based on the
    # spread probability
    mask = spread_probability < 0.5
    if mask.any():
        FBI[mask] = FBI_thresholds[0] + (
            FBI_thresholds[1] - FBI_thresholds[0]
        ) * (spread_probability[mask] / 0.5)

    # if spread_probability is >= 0.5, and the crown probability is less than
    # 0.33, FBI = ranges from 6 to 11 based on the crown probability
    mask = (spread_probability >= 0.5) & (crown_probability < 0.33)
    if mask.any():
        FBI[mask] = FBI_thresholds[1] + (
            FBI_thresholds[2] - FBI_thresholds[1]
        ) * (crown_probability[mask] / 0.33)

    # if spread_probability is >= 0.5, and the crown probability is between 0.33
    # and 0.66, FBI = ranges from 12 to 23 based on the crown probability
    mask = (
        (spread_probability >= 0.5)
        & (crown_probability >= 0.33)
        & (crown_probability < 0.66)
    )
    if mask.any():
        FBI[mask] = FBI_thresholds[2] + (
            FBI_thresholds[3] - FBI_thresholds[2]
        ) * (crown_probability[mask] - 0.33) / (0.66 - 0.33)

    # if spread_probability is >= 0.5, the crown probability is >= 0.66, and the
    # intensity is less than 20,000 kW/m, FBI = ranges from 24 to 49 based on
    # the intensity
    mask = (
        (spread_probability >= 0.5)
        & (crown_probability >= 0.66)
        & (intensity < 20000)
    )
    if mask.any():
        FBI[mask] = FBI_thresholds[3] + (
            FBI_thresholds[4] - FBI_thresholds[3]
        ) * (intensity[mask] / 20000)

    # if spread_probability is >= 0.5, the crown probability is >= 0.66, and the
    # intensity is between 20,000 and 40,000 kW/m, FBI = ranges from 50 to 99
    # based on the intensity
    mask = (
        (spread_probability >= 0.5)
        & (crown_probability >= 0.66)
        & (intensity >= 20000)
        & (intensity < 40000)
    )
    if mask.any():
        FBI[mask] = FBI_thresholds[4] + (
            FBI_thresholds[5] - FBI_thresholds[4]
        ) * (intensity[mask] - 20000) / (40000 - 20000)

    # if spread_probability is >= 0.5, the crown probability is >= 0.99, and the
    # intensity is between 40,000 kW/m and 90,000 kW/m, FBI = ranges from 100 to
    # 200 based on the intensity
    mask = (
        (spread_probability >= 0.5)
        & (crown_probability >= 0.99)
        & (intensity >= 40000)
    )
    if mask.any():
        FBI[mask] = FBI_thresholds[5] + (FBI_HIGH - FBI_thresholds[5]) * (
            intensity[mask] - 40000
        ) / (INTENSITY_HIGH - 40000)

    # Handle the edge case where crown_probability<=0.99 and intensity>4000
    # (This should not be physically possible)

    # TODO - this isn't covered in the technical guide, and could be
    # accomplished more succinctly by ignoring the crown probability in the
    # previous block
    # See https://gitlab.com/afdrs/afdrs-dev/packages/python-packages/fdrs_calcs/-/issues/24
    mask = (
        (spread_probability >= 0.5)
        & (crown_probability < 0.99)
        & (intensity > 40000)
    )
    if mask.any():
        FBI[mask] = FBI_thresholds[5] + (FBI_HIGH - FBI_thresholds[5]) * (
            intensity[mask] - 40000
        ) / (INTENSITY_HIGH - 40000)

    # round to nearest integer and return
    return np.trunc(FBI)
