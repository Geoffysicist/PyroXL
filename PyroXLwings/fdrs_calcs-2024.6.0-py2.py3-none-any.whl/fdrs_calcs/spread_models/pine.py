r"""Fire behaviour calculations for pine forests

## Technical Guide

The Pine Model in AFDRS is used for softwood plantations, mainly of pine
species, across Australia. Pine plantation fuels cover approx. 2% of Australia.

### What is the AFDRS Pine model? {#sec-pine-model}

The Pine Plantation Pyrometrics (PPPY) model system [cruz2008] was developed in
a collaboration between CSIRO, the Canadian forest service, and University of
Trás-os-Montes and Alto Douro (UTAD) in Portugal. It aimed to predict the rate
of spread and type of fire over the full range of fire behaviour in industrial
pine plantations for a variety of fuel complex structures (previous models for
pine were specific to the species or location of the plantation).

In contrast with other empirical-based models, this model combines some
empirical components with simplified physical descriptions of the heat
transferred to unburned fuels. The full PPPY system is very complicated,
consisting of over 100 equations, so for computational efficiency a simplified
version is used in the AFDRS. This 'light' version replaces some of the
semi-physical modelling components with empirical-based equations.

### Inputs and outputs {#sec-inputs}

The simplified pine model still requires a significant number of inputs, however
the key inputs for this model are 10m open wind speed, temperature, relative
humidity, surface fuel load and depth, fuel strata gap (distance between surface
fuel layer and bottom of the canopy), and the canopy bulk density.

This model does not have a go/no-go threshold, but it does vary the calculation
of Rate of Spread (ROS) based on the parts of the fuel (surface litter and/or
canopy) involved in the fire. The surface ROS and intensity is calculated, then
the system determines if crowning is likely to occur. If the crowning condition
is met, the system then calculates canopy ROS and determines if it will be a
passive or active crown fire, refining canopy ROS based on this crown fire
state.

### Model behaviour and limitations {#sec-limitations}

The simplification of the model for AFDRS replaces some of the semi-physical
modelling with empirical equations for the transition between surface and crown
fires, which results in a loss of predictive power. However, at the
landscape-scale of AFDRS, it is not a noticeable loss as the input values are
already more averaged than what the original PPPY system was designed for.

A standardised description for fuel age and type is used, with fuels assumed to
evolve in a certain way through time. Different varieties/species of pine than
those used in the model development may develop differently, and the
idealisation used in the model does not capture the full variety of surface
fuels possible within a pine forest.

The adjustments made to the 10m wind to achieve the stand height and flame
height winds are assumed from other research, but they have not been
investigated further and it is not clear if they are appropriate for pine
plantations. The effect of recent rainfall and its integration into the model
through the drought factor is also assumed; the impact of rain on fuel
availability is an area that needs further research.

This model assumes the fire has reached a quasi-steady state, so it may
overpredict in the initial stages of a fire. It is most sensitive to wind speed
and generally has a weak response to changes in fuel moisture content, however
it tends to underestimate surface fires burning in marginal conditions, namely
$MC_{litter} > 25%$.

Natural variation in wind speeds can cause a cycling between surface and crown
fires, but the model assumes only one mode is present, so when forecast winds
speeds are just below the threshold for crown fires the model may underpredict
ROS (actual fires may propagate as a combination of both surface & crown fires,
and crown fires spread faster).

### Fuel Sub-Types {#sec-fuel-types}

This model was developed specifically for pine plantations, so it has just the
one fuel sub-type. All softwood plantations, which in Australia are
predominantly pinus radiata, have been classified into the pine fuel type.
"""

import numpy as np

from . import grass
from .csiro_grassland import GRASS_CONDITION_EATENOUT
from . import wet_forest
from . import fire_behaviour_index
from . import fire_danger_rating
from .. import typing as ft
from . import common
from .common import standardize_dataset_variables

TPH_TO_KGSQM = 0.1
r"""Convert tonnes per hectare to kg per square metre"""

KGM2_PER_LBFT2 = 4.8824276
r"""Covert kg/m2 to lb/ft2"""

KGM3_PER_LBFT3 = 16.018463
r"""Covert kg/m3 to lb/ft3"""

KJKG_PER_BTULB = 2.326
r"""Convert kg/kJ to Btu/lb"""

MHR_PER_FTMIN = 18.288
r"""Convert m/h to ft/min"""

FTMIN_PER_KMH = 54.68
r"""Convert ft/min to km/h"""

FT_PER_M = 3.28084
r"""Convert ft to m"""

SURFACE_VOLUME_RATIO = 1700 * FT_PER_M
r"""Surface area to volume ratio, m^2/m^3"""

PACKING_RATIO_OP = 3.348 * np.power(SURFACE_VOLUME_RATIO / FT_PER_M, -0.8189)
r"""Optimum packing ratio, unitless [eqn 37 in @rothermel1972]"""

# TODO: Should this be dependent on the canopy height?
# See https://gitlab.com/afdrs/afdrs-dev/packages/python-packages/fdrs_calcs/-/issues/26
STAND_HEIGHT = 15
r"""Stand height, m"""

HEAT_CONTENT = 18608
r"""Heat content, kJ/kg"""


# add additional type hints for pine specific inputs
class PineInputVariables(grass.GrassInputVariables):
    r"""Pine specific additional input variables"""

    DF_SFC: ft.DF_SFC_Array
    drought_index: ft.drought_index_Array


def fuel_availability(drought_factor, drought_index, WRF):
    """Fuel availability function

    ### Technical Guide

    While a well-tested fuel moisture model is part of the Canadian Fire Weather
    Index (FWI) system [@vanwagner1987] it was not possible to implement this
    within the constraints of the AFDRS, instead the fuel availability function
    implemented for wet forests was used with a wind reduction factor ($WRF$) of
    5. For more information on the fuel availability function, see the technical
    documentation for the forest models.

    ### Usage

    ```python
    fuel_availability = fuel_availability(
        drought_factor, drought_index, WRF
    )
    ```

    ### Parameters

    - **drought_factor** (*array-like*) - drought factor (0-10, unitless)
    - **drought_index** (*array-like*) - either SDI or KBDI (0-203.2, mm)
    - **WRF** (*array-like*) - wind reduction factor (3 or 5)

    ### Returns

    - **fuel_availability** (*array-like*) - fuel availability (0.0-1.0)
    """
    return wet_forest.fuel_availability(drought_factor, drought_index, WRF)


def fuel_moisture_model(air_temperature, relative_humidity):
    r"""Calculate dead fuel moisture (%)

    ### Technical Guide

    @cruz2015a recommend using the @cruz2008 for plantation fires. Due to the
    complexity of the model, it was not possible to implement it for the
    Research Prototype. Instead, we used a simplified version originally
    developed for use with the Spark modelling framework [@miller2015].

    Fuel moisture of the litter content is calculated using a simplified
    equation based on @rothermel1983 (Cruz pers comm):

    $$
    MC_{litter} = 4.3426 + 0.1188 RH - 0.0211 T
    $$ {#eq-mc-litter}

    ### Usage

    ```python
    dead_fuel_moisture = fuel_moisture_model(air_temperature, relative_humidity)
    ```

    ### Parameters

    - **air_temperature** (*array-like*) - air temperature (C)
    - **relative_humidity** (*array-like*) - relative humidity (%)

    ### Returns

    - **dead_fuel_moisture** (*array-like*) - dead fuel moisture (%)
    """
    fuel_moisture = (
        4.3426 + 0.1188 * relative_humidity - 0.0211 * air_temperature
    )

    return fuel_moisture


def calc_wind_coefficient(
    wind_speed,
    packing_ratio,
    stand_height=STAND_HEIGHT,
    surface_volume_ratio=SURFACE_VOLUME_RATIO,
    packing_ratio_op=PACKING_RATIO_OP,
):
    r"""
    Calculate wind coefficient

    ### Technical Guide

    The wind coefficient $\Phi_w$ was modelled by @rothermel1972 to control the
    effect of wind speed on the surface rate of spread, and is calculated as a
    function of the mid-flame wind speed $U_{mid-flame}$ and the packing ratio
    $\beta$:

    $$
    \Phi_{w} = C \times (54.68 \times U_{mid-flame})^B 
        \times \left(\frac{\beta}{\beta_{op}}\right)^{-E}
    $$ {#eq-wind-coefficient}

    ::: {.callout-note}
    54.68 is included to convert the wind speed from km/h to ft/min for use in
    the original equation. 
    :::

    where $\beta_{op}$ is the optimum packing ratio calculated as $3.348 \left(
    0.3048\sigma \right)^{-0.8189}$, where $\sigma$ is the surface to volume
    ratio, assumed here to be 5577 $\frac{m^2}{m^3}$ (1700 $\frac{ft^2}{ft^3}$).

    ::: {.callout-note}
    $0.3048\sigma$ is included here and in other equations to convert the
    surface to volume ratio $\sigma$ from $\frac{m^2}{m^3}$ to
    $\frac{ft^2}{ft^3}$ for use in the original equation.
    :::   
    
    $C$, $B$ and $E$ are defined as:

    $$
    \begin{aligned}
    C &= 7.47 e^{-0.133 \left(0.3048\sigma\right)^{0.55}}, \\
    B &= 0.02526 \left(0.3048\sigma\right)^{0.54}, \\
    E &= 0.715 e^{-0.000359 \times 0.3048\sigma}.
    \end{aligned}
    $$ {#eq-wind-coefficient-constants}

    In order to calculate the mid-flame wind speed, the wind
    speed at the stand height is first calculated using the following equation
    from @cruz2006a:

    $$
    U_{stand} = U_{10} \frac{\ln \left(\frac{0.36 h}{0.13 h}\right)}
        {\ln \left(\frac{10 + 0.36 h}{0.13 h}\right)},
    $$ {#eq-wind-stand}

    where $U_{10}$ is the wind speed at 10m, and $h$ is the stand height,
    assumed here to be 15m.

    Having the stand wind-speed, the mid-flame wind speed can then calculated
    as:

    $$
    U_{mid-flame} = U_{stand} e^{-0.48},
    $$ {#eq-wind-mid-flame} 

    allowing the wind coefficient to be calculated in full for later use in the
    rate of spread calculations.

    ### Usage

    ```python
    wind_coefficient = calc_wind_coefficient(wind_speed, packing_ratio)
    ```

    ### Parameters

    - **wind_speed** (*array-like*) - wind speed at 10m (km/h)
    - **packing_ratio** (*array-like*) - fuel packing ratio (unitless)

    #### Optional Parameters

    These parameters define the physical characteristics of the model, and
    generally should not be adjusted unless you are experimenting with the
    model itself

    - **stand_height** (*float*) - stand height (m) (default: 15m)
    - **surface_volume_ratio** (*float*) - surface volume ratio (m^2/m^3)
        (default: 5577 m^2/m^3, or 1700 ft^2/ft^3)
    - **packing_ratio_op** (*float*) - optimum packing ratio (unitless)
        (default: 3.348 * 1700 ^ -0.8189)

    ### Returns

    - **wind_coefficient** (*array-like*) - wind coefficient (unitless)
    """
    # Calculate below canopy winds using (@cruz2006a)
    # TODO: This is similar to Eq 11 in cruz2006a, but not the same. Would be
    # good to understand why.
    # See https://gitlab.com/afdrs/afdrs-dev/packages/python-packages/fdrs_calcs/-/issues/27
    wind_stand_height = (
        wind_speed
        * np.log((0.36 * stand_height) / (0.13 * stand_height))
        / np.log((10 + 0.36 * stand_height) / (0.13 * stand_height))
    )
    wind_mid_flame = wind_stand_height * np.exp(-0.48)

    # calculate the wind coefficient from eqn 47 in @rothermel1972
    E = 0.715 * np.exp(-0.000359 * surface_volume_ratio / FT_PER_M)
    B = 0.02526 * np.power(surface_volume_ratio / FT_PER_M, 0.54)
    C = 7.47 * np.exp(-0.133 * np.power(surface_volume_ratio / FT_PER_M, 0.55))
    wind_coefficient = (
        C
        * np.power(wind_mid_flame * FTMIN_PER_KMH, B)
        * np.power(packing_ratio / packing_ratio_op, -E)
    )

    return wind_coefficient


def calc_surface_rate_of_spread(
    surface_fuel_load,
    dead_fuel_moisture,
    wind_speed,
    fuel_depth=0.3499104,
    particle_density=512.591,
    mineral_content_ratio=0.0555,
    mineral_content_silica_free_ratio=0.010,
    moisture_percent_extinction=30.0,
    surface_volume_ratio=SURFACE_VOLUME_RATIO,
    packing_ratio_op=PACKING_RATIO_OP,
    heat_yield=HEAT_CONTENT,
):
    r"""
    Calculate surface rate of spread

    ### Technical Guide

    The surface rate of spread is calculated using @rothermel1972, which
    describes the rate of spread as a function of the surface fuel load, dead
    fuel moisture, wind speed and fuel depth. The surface rate of spread is

    $$
    ROS_{surface} = 18.288 \frac{I_R \xi (1 + \Phi_{wind})}{\rho E H_{p}}
    $$ {#eq-surface-ros}

    where $I_R$ is the reaction intensity, $\xi$ is the propagation flux ratio,
    $\Phi_{wind}$ is the wind coefficient described above, $\rho$ is the bulk
    density, $E$ is the effective heating number, and $H_{p}$ is the heat of
    preignition.

    Except for the wind coefficient, which was described elsewhere, the
    remaining parameters are described below.

    #### Calculating the Reaction Intensity $I_R$

    The reaction intensity is calculated as:

    $$
    I_R = \gamma F_{net} H_Y \eta_M \eta_S
    $$ {#eq-reaction-intensity}

    where $\gamma$ is the optimal reaction velocity, $F_{net}$ is the net fuel
    load, $H_Y$ is the heat yield (assumed here to be 18608 kJ/kg, or 8000
    Btu/lb), $\eta_M$ is the moisture damping coefficient and $\eta_S$ is the
    mineral damping coefficient.

    The optimal reaction velocity, $\gamma$, is calculated as:

    $$
    \gamma = \gamma_{max} \left(\frac{\beta}{\beta_{op}}\right)^A e^A \left(1 -
        \frac{\beta}{\beta_{op}}\right)
    $$ {#eq-optimal-reaction-velocity}

    where $\gamma_{max}$ is the maximum reaction velocity, $\beta$ is the fuel
    packing ratio, $\beta_{op}$ is the optimum packing ratio, and $A$ is a
    constant defined as:

    $$
    A = \frac{1}{4.77 \left(0.3048\sigma\right)^{0.1} - 7.27}
    $$ {#eq-constant-a}

    where $\sigma$ is the surface to volume ratio, assumed here to be 5577
    $\frac{m^2}{m^3}$ (1700 $\frac{ft^2}{ft^3}$).

    ::: {.callout-note}
    $0.3048\sigma$ is included here and in other equations to convert the
    surface to volume ratio $\sigma$ from $\frac{m^2}{m^3}$ to
    $\frac{ft^2}{ft^3}$ for use in the original equation.
    :::

    The maximum reaction velocity, $\gamma_{max}$, is calculated as:

    $$
    \gamma_{max} = \frac{\left(0.3048\sigma\right)^{1.5}}
        {495 + 0.0594 \left(0.3048\sigma\right)^{1.5}}
    $$ {#eq-maximum-reaction-velocity}

    The net fuel load, $F_{net}$, is calculated by removing the mineral
    content from the surface fuel load, $F_{surface}$, based on the mineral
    content ratio, $\frac{M_{mineral}}{M_{wood}}$. For surface spread in the
    pine model in the AFDRS, $M_{mineral}$ is assumed to be 5.55% of the
    oven-dry wood mass.

    $$
    F_{net} = \frac{F_{surface}}{1 + \frac{M_{mineral}}{M_{wood}}}
    $$ {#eq-net-fuel-load}

    The moisture damping coefficient, $\eta_M$, is calculated based on the ratio
    between the dead fuel moisture content and the moisture content of
    extinction, $\frac{MC_{litter}}{MC_{ext}}$, which is the moisture content at
    which the reaction velocity is zero. For surface spread in the pine model in
    the AFDRS, $MC_{ext}$ is assumed to be 30.0%.

    $$
    \eta_M = 1 - 2.59 \left(\frac{MC_{litter}}{MC_{ext}}\right) + 5.11
        \left(\frac{MC_{litter}}{MC_{ext}}\right)^2 - 3.52
        \left(\frac{MC_{litter}}{MC_{ext}}\right)^3
    $$ {#eq-moisture-damping-coefficient}

    The mineral damping coefficient, $\eta_S$, is calculated based on the ratio
    between the silica-free mineral content and the oven-dry wood mass,
    $\frac{M_{mineral}}{M_{wood}}$, which is the mineral content at which the
    reaction velocity is zero. For surface spread in the pine model in the
    AFDRS, $M_{mineral}$ is assumed to be 1.0% of the oven-dry wood mass.

    $$
    \eta_S = 0.174 \left(\frac{M_{mineral}}{M_{wood}}\right)^{-0.19}
    $$ {#eq-mineral-damping-coefficient}

    #### Calculating the Propagation Flux Ratio $\xi$

    The propagation flux ratio, $\xi$, is calculated as:

    $$
    \xi = \frac{e^{0.792 \times 0.681 \left(0.3048\sigma\right)^{0.5}
        \left(\beta + 0.1\right)}}
        {192 + 0.2595 \left(0.3048\sigma\right)}
    $$ {#eq-propagation-flux-ratio}

    where $\beta$ is the fuel packing ratio, calculated based on the bulk
    density $\rho$ in the next section.

    #### Calculating the Bulk Density $\rho$ and the packing ratio $\beta$

    The bulk density is calculated by dividing the fuel load by the fuel depth:

    $$
    \rho = \frac{F_{surface}}{D}
    $$ {#eq-bulk-density}

    where $F_{surface}$ is the surface fuel load and $D$ is the surface fuel
    depth, assumed here to be around 0.35 metres.

    Given the bulk density, the packing ratio can be calculated as:

    $$
    P = \frac{\rho}{\rho_p}
    $$ {#eq-packing-ratio}

    where $\rho_p$ is the particle density, assumed here to be 512.591 kg/m^3
    (32 lb/ft^3).

    #### Calculating the Effective Heating Number $E$

    The effective heating number, $E$, is calculated as:

    $$
    E = e^{-138 / \left(0.3048\sigma\right)}
    $$ {#eq-effective-heating-number}

    #### Calculating the Heat of Preignition $H_p$

    The heat of preignition, $H_p$, is calculated as:

    $$
    H_p = 250 + 1116 \frac{MC_{litter}}{100}
    $$ {#eq-heat-of-preignition}

    ### Usage

    ```python
    ros_surface, intensity_surface = calc_surface_spread(
        surface_fuel_load, dead_fuel_moisture, wind_speed
    )
    ```

    ### Parameters

    - **surface_fuel_load** (*array-like*) - surface fuel load (t/h)
    - **dead_fuel_moisture** (*array-like*) - dead fuel moisture (%)
    - **wind_speed** (*array-like*) - wind speed at 10m (km/h)

    #### Optional Parameters

    These parameters define the physical characteristics of the model, and
    generally should not be adjusted unless you are experimenting with the
    model itself

    - **fuel_depth** (*float*) - surface fuel depth (m) (default: 0.35m)
    - **particle_density** (*float*) - fuel particle density (kg/m^3)
        (default: 512.591 kg/m^3)
    - **mineral_content_ratio** (*float*) - Ratio of mineral to oven-dry wood
        mass, unitless (default: 0.0555:1)
    - **mineral_content_silica_free_ratio** (*float*) - Ratio of silica-free
        minerals to oven-dry wood mass, unitless (default: 0.010:1)
    - **moisture_percent_extinction** (*float*) - Moisture content of
        extinction (%), mass water / mass ovendry wood (default: 30.0%)
    - **surface_volume_ratio** (*float*) - Surface area to volume ratio,
        m^2/m^3 (default: 5577 m^2/m^3, or 1700 ft^2/ft^3)
    - **packing_ratio_op** (*float*) - optimum packing ratio, unitless
        (default: 3.348 * 1700 ^ -0.8189)
    - **heat_yield** (*float*) - heat yield, kJ/kg (default: 18608 kJ/kg, or
        8000 Btu/lb)

    ### Returns

    - **ros_surface** (*array-like*) - surface rate of spread (m/h)
    """
    # use the fuel height to calculate the bulk density in kg/m^3
    bulk_density = surface_fuel_load * TPH_TO_KGSQM / fuel_depth

    # calculate the fuel packing ratio by comparing the fuel load to the
    # particle density
    packing_ratio = bulk_density / particle_density

    # calculate the propagation flux ratio
    xi = np.exp(
        (0.792 * 0.681 * np.power(surface_volume_ratio / FT_PER_M, 0.5))
        * (packing_ratio + 0.1)
    ) / (192 + 0.2595 * surface_volume_ratio / FT_PER_M)

    # calculate the mineral damping coefficient
    ETA_S = 0.174 * np.power(mineral_content_silica_free_ratio, -0.19)

    # calculate the moisture damping coefficient
    moisture_extinction_ratio = dead_fuel_moisture / moisture_percent_extinction
    eta_M = (
        1
        - 2.59 * moisture_extinction_ratio
        + 5.11 * np.power(moisture_extinction_ratio, 2)
        - 3.52 * np.power(moisture_extinction_ratio, 3)
    )

    # calculate the optimal reaction velocity, gamma
    A = 1 / (4.77 * np.power(surface_volume_ratio / FT_PER_M, 0.1) - 7.27)
    GAMMA_MAX = np.power(surface_volume_ratio / FT_PER_M, 1.5) / (
        495 + 0.0594 * np.power(surface_volume_ratio / FT_PER_M, 1.5)
    )
    gamma = (
        GAMMA_MAX
        * np.power((packing_ratio / packing_ratio_op), A)
        * np.exp(A * (1 - packing_ratio / packing_ratio_op))
    )

    # calculate the net fuel by removing the mineral content based on the
    # mineral content ratio
    net_fuel_load = surface_fuel_load / (1 + mineral_content_ratio)
    net_fuel_load_IMP = net_fuel_load * TPH_TO_KGSQM / KGM2_PER_LBFT2

    # calculate the reaction intensity in Btu/ft^2 min
    reaction_intensity = (
        gamma * net_fuel_load_IMP * heat_yield / KJKG_PER_BTULB * eta_M * ETA_S
    )  # Btu/ft^2 min

    # calculate the wind coefficient
    wind_coefficient = calc_wind_coefficient(wind_speed, packing_ratio)

    # calculate the effective heating number
    effective_heating_number = np.exp(-138 / (surface_volume_ratio / FT_PER_M))

    # calculate the heat of preignition
    heat_of_preignition = 250 + 1116 * dead_fuel_moisture / 100.0  # Btu/lb

    # calculate the surface rate of spread
    ros_surface = (
        MHR_PER_FTMIN
        * reaction_intensity
        * xi
        * (1 + wind_coefficient)
        / (
            bulk_density
            / KGM3_PER_LBFT3
            * effective_heating_number
            * heat_of_preignition
        )
    )

    return ros_surface


def calc_fire_spread_single(
    dead_fuel_moisture,
    wind_speed,
    drought_factor,
    drought_index,
    canopy_fuel_load=11.0,
    canopy_base_height=5,
    canopy_bulk_density=0.1,
    surface_load=10.5,
    wrf=5,
    heat_yield=HEAT_CONTENT,
):
    r"""Calculate rate of spread, intensity and flame_height for a single fuel
     model
    
    ### Technical Guide

    #### Criteria for Active Crowning

    In order to include the effect of the canopy on the fire behaviour, the
    criteria for active crowning developed by @vanwagner1977 was calculated
    based on the potential active crown fire spread rate, the critical mass flow
    rate for solid crown flame, and the canopy bulk density. This criteria is
    used to determine whether the fire can be characterised as surface, passive
    crowning or active crowning.

    The surface rate of spread is calculated elsewhere using @rothermel1972, and
    the active crown fire spread rate is calculated using the following equation
    from @cruz2005:

    $$
    ROS_{active} = 60 * 11.021 U_{10}^{0.8966} \rho_C^{0.1901}
         e^{-0.1714 MC_{litter}}
    $$ {#eq-active-ros}

    where $U_{10}$ is the wind speed at 10m, $\rho_C$ is the canopy bulk
    density, and $MC_{litter}$ is the dead fuel moisture content of the litter.

    ::: {.callout-note}
    60 is included to convert the spread rate from m/min to m/h for use in the
    AFDRS.
    :::

    The critical mass flow rate for solid crown flame ($MFR_o$) is assumed here
    to be 180.0 $kg/m^2/hr$, and the canopy bulk density ($\rho_C$) is provided
    to each ensemble member.

    Given these values, the criteria for active crowning is calculated as:

    $$
    CAC = \frac{ROS_{active}}{MFR_o / \rho_C}
    $$ {#eq-cac}

    #### Crowning Ratio

    In addition to the criteria for active crowning, a crowning ratio was also
    constructed comparing the surface intensity to crowning intensity, which is
    calculated as:

    $$
    I_{crown} = 0.01 H_{crown} H_{ignition}^{1.5}
    $$ {#eq-crowning-intensity}

    where $H_{crown}$ is the canopy base height (provided to each ensemble
    member), and $H_{ignition}$ is the heat of ignition, calculated based on the
    foliar moisture content:

    $$
    \begin{aligned}
    MC_{foliar} &= 150 - 5 DF, \\
    H_{ignition} &= 460 + 26 MC_{foliar}.
    \end{aligned}
    $$ {#eq-heat-of-ignition}

    where $DF$ is the drought factor, calculated by the Bureau of Meteorology in
    the range of 0 - 10, and provided to the AFDRS.

    The surface intensity is calculated using the following equation from
    @byram1959:

    $$
    I_{surface} = h \times F'_{surface} \times ROS'_{surface}
    $$ {#eq-surface-intensity}

    where $h$ is the heat yield, assumed here to be 18608 kJ/kg, or 8000 Btu/lb,
    $F'_{surface}$ is the surface fuel load in kg/m^2, and $ROS'_{surface}$ is
    the surface rate of spread in m/s.

    The crowning ratio is then calculated as:

    $$
    CR = \frac{I_{surface}}{I_{crown}}
    $$ {#eq-crowning-ratio}

    Where values greater than 1 indicate that crowning is predicted.

    #### Total Rate of Spread

    Given the criteria for active crowning and the crowning ration, the final
    rate of spread is calculated based on the surface, active crowning and
    passive crowning rates of spread according to the following rules:

    $$
    ROS = 
    \begin{cases}
    ROS_{surface} & \text{if } CR \leq 1, \\
    \max(ROS_{passive}, ROS_{surface}) & 
        \text{if } CR > 1 \text{ and } CAC < 1, \\
    \max(ROS_{active}, ROS_{surface}) 
        & \text{if } CR > 1 \text{ and } CAC \geq 1. \\
    \end{cases}
    $$ {#eq-ros}

    Where $ROS_{surface}$ and $ROS_{active}$ are outlined above, and
    $ROS_{passive}$ is calculated as:

    $$
    ROS_{passive} = ROS_{active} e^{-CAC}
    $$ {#eq-passive-ros}

    #### Total Intensity

    In order to calculate the total surface/crowning intensity, @byram1959 was
    used again (similar to @eq-surface-intensity) with $F_{total}$ in place of
    $F_{surface}$:

    $$
    I_{total} = h \times F_{total}' \times ROS'
    $$ {#eq-total-intensity}

    where $F_{total}'$ is the total fuel load F_{total} in kg/m^2,
    ROS' is the rate of spread in m/s, and $h$ is the heat yield, assumed here
    to be 18608 kJ/kg, or 8000 Btu/lb.

    The total fuel load is calculated (in t/h) as:

    $$
    F_{total} = F_{surface} +
    \begin{cases}
    0 & \text{if } CR \leq 1, \\
    F_{canopy} & \text{if } CR > 1, \\
    \end{cases}
    $$ {#eq-total-fuel-load}

    That is, if either passive or active crowning is predicted, the canopy fuel
    load is added to the surface fuel load before intensity is calculated.

    #### Flame Length

    Finally, the flame length is calculated using the flame length calculations
    from @alexander2011 using the equation from @byram1959 in Table S1:

    $$
    L_{flame} = 0.0775 I_{total}^{0.46}
    $$ {#eq-flame-height}

    ### Usage

    ```python
    rate_of_spread, intensity_total, flame_length = calc_fire_spread_single(
        dead_fuel_moisture, wind_speed, drought_factor, drought_index
    )
    ```

    ### Parameters

    - **dead_fuel_moisture** (*array-like*) - dead fuel moisture (%)
    - **wind_speed** (*array-like*) - wind speed at 10m (km/h)
    - **drought_factor** (*array-like*) - drought factor (0-10, unitless)
    - **drought_index** (*array-like*) - either SDI or KBDI (0-203.2, mm)

    #### Ensemble Parameters

    These parameters define the physical characteristics of the model, and are
    provided to each member of the ensemble:

    - **canopy_fuel_load** (*float*) - canopy fuel load (t/ha) (default: 11.0
        t/ha)
    - **canopy_base_height** (*float*) - canopy base height (m) (default: 5m)
    - **canopy_bulk_density** (*float*) - canopy bulk density (kg/m^3)
        (default: 0.1 kg/m^3)
    - **surface_load** (*float*) - surface fuel load (t/ha) (default: 10.5 t/ha)
    
    #### Optional Parameters

    These parameters define the physical characteristics of the model, and
    generally should not be adjusted unless you are experimenting with the
    model itself

    - **wrf** (*float*) - wind reduction factor (3 or 5) (default: 5)
    - **heat_yield** (*float*) - heat yield, kJ/kg (default: 18608 kJ/kg, or
        8000 Btu/lb)

    ### Returns

    - **rate_of_spread** (*array-like*) - rate of spread (m/h)
    - **intensity_total** (*array-like*) - total intensity (kW/m)
    - **flame_length** (*array-like*) - flame length (m)
    """

    # Use the fuel availability function to calculate the available surface load
    surface_fuel_load = surface_load * fuel_availability(
        drought_factor, drought_index, wrf
    )

    # calculate the surface rate of spread
    ros_surface = calc_surface_rate_of_spread(
        surface_fuel_load, dead_fuel_moisture, wind_speed
    )

    # calculate the active crown fire spread rate in m/min (eqn 3 in @cruz2005)
    speed_active = (
        60
        * 11.021
        * np.power(wind_speed, 0.8966)
        * np.power(canopy_bulk_density, 0.1901)
        * np.exp(-0.1714 * dead_fuel_moisture)
    )

    # Criteria for Active Crowning (CAC)
    CRITICAL_MASS_FLOW_RATE = 3.0 * 60  # kg/m^2/hour
    criteria_active_crowning = speed_active / (
        CRITICAL_MASS_FLOW_RATE / canopy_bulk_density
    )

    # Heat of ignition, kJ/kg
    foliar_moisture_content = 150 - 5 * drought_factor
    heat_of_ignition = 460 + 26 * foliar_moisture_content

    # calculate the surface intensity in kW/m
    intensity_surface = common.calc_fire_intensity(
        ros_surface, surface_fuel_load, heat_yield
    )
    # Crowning threshold intensity, kW/m
    crowning_intensity = np.power(
        0.01 * canopy_base_height * heat_of_ignition, 1.5
    )
    # if the crowning ratio is greater than 1, then crowning is predicted
    crowning_ratio = intensity_surface / crowning_intensity

    # calculate the passive rate of spread using the active rate of spread and
    # the crowning criteria
    speed_passive = speed_active * np.exp(-1 * criteria_active_crowning)

    # apply the crowning criteria to determine whether the fire is surface,
    # passive crown or active crown
    passive_mask = (crowning_ratio > 1) & (criteria_active_crowning < 1)
    active_mask = (crowning_ratio > 1) & (criteria_active_crowning >= 1)
    surface_mask = crowning_ratio <= 1

    # use the crowning criteria masks to determine the rate of spread for all
    rate_of_spread = np.empty(ros_surface.shape)
    rate_of_spread[surface_mask] = ros_surface[surface_mask]
    rate_of_spread[passive_mask] = np.maximum(
        speed_passive[passive_mask], ros_surface[passive_mask]
    )
    rate_of_spread[active_mask] = np.maximum(
        speed_active[active_mask], ros_surface[active_mask]
    )

    # add the canopy fuel load to the surface fuel load for passive and active
    # crowning
    fuel_load = surface_fuel_load * TPH_TO_KGSQM
    fuel_load[passive_mask] += canopy_fuel_load * TPH_TO_KGSQM
    fuel_load[active_mask] += canopy_fuel_load * TPH_TO_KGSQM

    # use the fuel load to calculate the fire intensity in kW/m
    intensity_total = HEAT_CONTENT * fuel_load * rate_of_spread / 3600

    # calculate the flame length in m
    flame_length = 0.0775 * np.power(intensity_total, 0.46)
    # add the stand height to the flame height for active crowning
    flame_height = flame_length
    flame_height[active_mask] += STAND_HEIGHT
    # TODO: flame height is ignored, and only flame_length is included in the
    # return statement
    # See https://gitlab.com/afdrs/afdrs-dev/packages/python-packages/fdrs_calcs/-/issues/28

    # return all outputs
    return rate_of_spread, intensity_total, flame_length


def calc_fire_spread(
    dead_fuel_moisture, wind_speed, drought_factor, drought_index
):
    r"""Calculate rate of spread, intensity and flame_height

    ### Technical Guide

    Because information about time since harvesting and silvicultural management
    is not available in the AFDRS, fire behaviour in pine plantations is
    calculated using an ensemble of 6 different stages from @cruz2011 :

    +-------+-------+----------+---------+--------+------------+-------------+
    | Fuel  | Model | Ensemble | Surface | Canopy | Canopy     | Canopy bulk |
    | class | used  | weight   | load    | load   | base       | density     |
    |       |       |          | (t/ha)  | (t/ha) | height (m) | (kg/m^3)    |
    +=======+=======+=========:+========:+=======:+===========:+============:+
    | 1     | Grass | 9.1%     | 1.5     | *n/a*  | *n/a*      | *n/a*       |
    +-------+-------+----------+---------+--------+------------+-------------+
    | 2     | Pine  | 15.1%    | 4.0     | 11.5   | 0.7        | 0.17        |
    +-------+-------+----------+---------+--------+------------+-------------+
    | 3     | Pine  | 15.1%    | 5.0     | 12.0   | 1.5        | 0.18        |
    +-------+-------+----------+---------+--------+------------+-------------+
    | 4     | Pine  | 12.1%    | 8.5     | 12.0   | 2.5        | 0.18        |
    +-------+-------+----------+---------+--------+------------+-------------+
    | 5     | Pine  | 9.1%     | 10.0    | 8.0    | 6.0        | 0.12        |
    +-------+-------+----------+---------+--------+------------+-------------+
    | 6     | Pine  | 39.4%    | 7.0     | 10.0   | 14.0       | 0.15        |
    +-------+-------+----------+---------+--------+------------+-------------+

    : Fuel model parameters for pine plantations {.striped .hover}

    Model 1 represents a newly harvested pine forest, which is modelled using a
    100% cured, eaten-out grassland model with a fuel load of 1.5 t/ha. Models
    2-6 represent different stages of regrowth, with the surface fuel load,
    canopy fuel load, canopy base height and canopy bulk density varying as pine
    plantations mature.

    Each of these stages calculate the rate of spread (m/h), intensity (kW/m)
    and flame length (m) for a given set of fuel model parameters. The final
    values are calculated by weighting each stage by it's ensemble weight and
    combining them to get the final values.

    ### Usage

    ```python
    rate_of_spread, intensity, flame_height = calc_fire_spread(
        dead_fuel_moisture, wind_speed, drought_factor, drought_index
    )
    ```

    ### Parameters

    - **dead_fuel_moisture** (*array-like*) - dead fuel moisture (%)
    - **wind_speed** (*array-like*) - wind magnitude (km/h)
    - **drought_factor** (*array-like*) - drought factor (0-10, unitless)
    - **drought_index** (*array-like*) - either SDI or KBDI (0-203.2, mm)

    ### Returns

    - **rate_of_spread** (*array-like*) - rate of spread (m/h)
    """
    fuel_models = [
        {
            "model": "grass",
            "proportion": 0.091,
            "surface_load": 1.5,
            "curing": 100,
            "grass_condition": GRASS_CONDITION_EATENOUT,
        },
        {
            "model": "pine",
            "proportion": 0.151,
            "surface_load": 4.0,
            "canopy_fuel_load": 11.5,
            "canopy_base_height": 0.7,
            "canopy_bulk_density": 0.17,
        },
        {
            "model": "pine",
            "proportion": 0.151,
            "surface_load": 5.0,
            "canopy_fuel_load": 12.0,
            "canopy_base_height": 1.5,
            "canopy_bulk_density": 0.18,
        },
        {
            "model": "pine",
            "proportion": 0.121,
            "surface_load": 8.5,
            "canopy_fuel_load": 12.0,
            "canopy_base_height": 2.5,
            "canopy_bulk_density": 0.18,
        },
        {
            "model": "pine",
            "proportion": 0.091,
            "surface_load": 10.0,
            "canopy_fuel_load": 8.0,
            "canopy_base_height": 6.0,
            "canopy_bulk_density": 0.12,
        },
        {
            "model": "pine",
            "proportion": 0.394,
            "surface_load": 7.0,
            "canopy_fuel_load": 10.0,
            "canopy_base_height": 14.0,
            "canopy_bulk_density": 0.15,
        },
    ]

    # setup rate of spread, intensity and flame_length with zeros, the same size
    # as the input arrays
    rate_of_spread = np.zeros(dead_fuel_moisture.shape)
    intensity = np.zeros(dead_fuel_moisture.shape)
    flame_length = np.zeros(dead_fuel_moisture.shape)

    # go through each of the fuel models and calculate the rate of spread,
    # intensity and flame length for each one, adding the weighted values to the
    # total according to the ensemble weights
    for parameters in fuel_models:

        if parameters["model"] == "pine":
            # calculate the rate of spread, intensity and flame length for the
            # pine model according to the parameters
            r, i, f = calc_fire_spread_single(
                dead_fuel_moisture,
                wind_speed,
                drought_factor,
                drought_index,
                surface_load=parameters["surface_load"],
                canopy_fuel_load=parameters["canopy_fuel_load"],
                canopy_base_height=parameters["canopy_base_height"],
                canopy_bulk_density=parameters["canopy_bulk_density"],
            )

        elif parameters["model"] == "grass":
            # create arrays of the same size as the input arrays, filled with
            # the parameters for the grass model
            curing = np.full(dead_fuel_moisture.shape, parameters["curing"])
            grass_condition = np.full(
                dead_fuel_moisture.shape, parameters["grass_condition"]
            )
            grass_load = np.full(
                dead_fuel_moisture.shape, parameters["surface_load"]
            )
            # calculate the rate of spread, intensity and flame height using
            # this grass model
            r = grass.calc_rate_of_spread(
                dead_fuel_moisture, wind_speed, curing, grass_condition
            )
            i = grass.calc_intensity(r, grass_load)
            f = grass.calc_flame_height(r, grass_condition)

        # add the weighted values to the total
        rate_of_spread += parameters["proportion"] * r
        intensity += parameters["proportion"] * i
        flame_length += parameters["proportion"] * f

    # return the final combined values
    return rate_of_spread, intensity, flame_length


def calc_spotting_distance(air_temperature):
    r"""
    Calculate pine spotting distance

    ### Technical Guide

    A spotting model is not currently implemented for pine forests.

    ### Implementation Details

    As a spotting model is not currently implemented for pine forests, this
    function returns an empty array (all values NaN) of the same shape as the
    input array.

    ### Usage

    ```python
    spotting_distance = calc_spotting_distance(air_temperature)
    ```

    ### Parameters

    - **air_temperature** (*array-like*) - air temperature (C)

    ### Returns

    - **spotting_distance** (*array-like*) - spotting distance (m)
    """
    return np.full(air_temperature.shape, np.nan)


def calculate(
    dataset: PineInputVariables, fuel_parameters: ft.NoFuelParameters
) -> ft.CommonOutputIndices:
    r"""
    Main entry point for calculating fire behaviour for pine forests.

    ### Usage

    ```python
    indices = calculate(dataset, fuel_parameters)
    ```

    ### Parameters

    - **dataset** (*dict*) - A dictionary of *array_like* containing the input
        variables.

        From these input variables, only the following are used by this
        model:

        - **T_SFC** - Temperature (C)
        - **RH_SFC** - Relative humidity (%)
        - **WindMagKmh_10m** : Wind magnitude at 10m (km/h)
        - **DF_SFC** - drought factor (0-10, unitless)
        - **drought_index** - either SDI or KBDI (0-200, mm)

    - **fuel_parameters** A dictionary of scalars containing the fuel
      parameters.

        No fuel parameters are used by this model.

    ### Returns

    - **output** (*dict*) - A dictionary of *array_like* containing the output
        variables of the same shape as the input arrays with the following keys:

        - **dead_fuel_moisture** - dead fuel moisture (%)
        - **rate_of_spread** - rate of spread (m/hr)
        - **flame_height** - flame length (m)
        - **intensity** - intensity (kW/m)
        - **spotting_distance** - spotting distance (m)
        - **rating_1** - fire danger rating (unitless)
        - **index_1** - fire behaviour index (unitless)
    """
    # standardize the dataset variables
    dataset = standardize_dataset_variables(dataset)

    # Calculate dead fuel moisture
    dead_fuel_moisture = fuel_moisture_model(
        dataset["T_SFC"], dataset["RH_SFC"]
    )

    # Calculate fire behaviour
    rate_of_spread, intensity, flame_length = calc_fire_spread(
        dead_fuel_moisture,
        dataset["WindMagKmh_10m"],
        dataset["DF_SFC"],
        dataset["drought_index"],
    )

    # Calculate spotting distance
    spotting_distance = calc_spotting_distance(dataset["T_SFC"])

    # calculate the fire behaviour index and fire danger rating from the fire
    # intensity only
    index_1 = fire_behaviour_index.pine(intensity)
    rating_1 = fire_danger_rating.fire_danger_rating(index_1)

    # return the outputs
    return {
        "dead_fuel_moisture": dead_fuel_moisture,
        "rate_of_spread": rate_of_spread,
        "flame_height": flame_length,
        "intensity": intensity,
        "spotting_distance": spotting_distance,
        "rating_1": rating_1,
        "index_1": index_1,
    }
