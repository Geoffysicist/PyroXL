r"""
Fire behaviour calculations for dry forests

## Technical Guide

The Forest Model for AFDRS is used for all dry sclerophyll forests and temperate
woodlands where litter and shrubs dominate the understorey. Forest fuels cover
only 6% of Australia but coincide with the areas of greatest population.
Nationally, forest dominates 18% of Fire Weather Areas (FWAs) and is significant
in 38%, though these are much higher in the southeast of the country; 90% of
Tasmanian FWAs and more than 75% of Victorian FWAs are significantly influenced
by forest fuels.

### What is the AFDRS Forest model? {#sec-forest-model}

AFDRS uses the dry eucalyptus forest fire model (DEFFM, also known as the Vesta
model), which was developed by @cheney2012, extending the work of previous
research, including @gould2007. Project Vesta was a broad, multi-agency
experimental study that aimed to develop a nationally applicable fire behaviour
model for dry eucalyptus forests in summer conditions. It used data from 116
experimental burns carried out in southwest WA in the summers of 1998, 1999 and
2001.

### Inputs and outputs {#sec-inputs}

The forest model specifically incorporates the structure of forest fuels into
its calculations. It can do this in one of two ways: by using a Fuel Hazard
Score (FHS, also known as Vesta fuel score), or by using a Fuel Hazard Rating
(FHR). AFDRS uses FHS, which is a subjective assessment of the flammability of
the fuel based on the bark type, density, continuity, structural development of
vegetation, and accumulation of litter fuels. For instances where FHS's are not
available for an area, if FHRs are available, they are converted into FHSs,
otherwise default FHS values are used.

The FHS has several components: the surface FHS and the near-surface FHS, both
of which are numbers between 0 and 4. The final piece of information in the FHS
is the near-surface height which, unsurprisingly, is the height of the
near-surface fuels.

Other inputs required for this model include the fuel moisture content, which is
derived from the relative humidity and the temperature, and the 10m open wind
speed, which has a reduction factor applied to account for the forest canopy.

This model does not have a go/no-go threshold; once the inputs are known, the
Rate of Spread (ROS) can be calculated.

The outputs of this model are Rate of Spread, Spotting Distance, Intensity, and
Flame Height. Spotting Distance calculations are not currently included in AFDRS
as they can be quite site-specific.

### Model behaviour and limitations

The Vesta model is a straightforward model with a simple algebraic equation for
ROS. However, hazard scores are modelled at a landscape level for AFDRS with
requires several assumptions and does not account for variations in different
areas. This is an issue as the Vesta model is highly sensitive to the fuel
classification (fuel hazard score); for example, a change of 1 in FHS can double
the ROS output. 

This model is also sensitive to the near-surface fuel height and
is somewhat sensitive to moisture when RH < approx. 6%. The original model
assumes a Drought Factor of 10. AFDRS applies a correction if DF < 10 (see fuel
availability equations under fuel sub-types, below), but the effect of this
correction is not fully understood. It has also been noted that the assumed heat
yield of 18,600 kJ/kg needs further investigation.

For all DEFFM/Vesta fire behaviour calculations both fuel hazard scores and fuel
loads were multiplied by the fuel availability factor. Fuel heights were not
modified. Development of more suitable methods of including fuel availability
effects on the DEFFM/Vesta model is a high priority for future research and
development.

### Fuel sub-types

#### Forest

This fuel sub-type is for dry eucalypt forests and temperate woodlands with a
shrubby understorey and litter surface fuel. The Dry Eucalypt Forest Fire
(Vesta) Model was developed for this type of fuel, where the litter and shrub
dominated understorey provide vertical fuel continuity.

For AFDRS, forests/woodlands with a continuous grassy understorey have been
classified to savanna, and open woodlands (woodlands with < 10% canopy cover)
with a heath understorey have been classified to Heathland (Shrubland).
"""

from typing import Annotated
import numpy as np

from . import fire_behaviour_index
from . import fire_danger_rating
from .. import typing as ft
from . import common
from .common import standardize_dataset_variables

START_PEAK_MONTH = 10  # October
END_PEAK_MONTH = 3  # March
START_AFTERNOON = 12
END_AFTERNOON = 17
SUNRISE = 6
SUNSET = 19
THRESHOLD_WIND_SPEED = 5.0  # km/h
THRESHOLD_ROS = 30  # m/h
FLAME_HEIGHT_ELEVATED = 1  # m
FLAME_HEIGHT_CROWN_FRACTION = 0.66  # unitless
HEAT_CONTENT = 18600  # KJ/kg


# add additional type hints for forest specific inputs
class DryForestInputVariables(ft.CommonInputVariables):
    r"""Dry forest specific additional input variables"""

    DF_SFC: ft.DF_SFC_Array
    time_since_fire: ft.time_since_fire_Array
    months: ft.months_Array
    hours: ft.hours_Array


FHS_s_Value = Annotated[int, ft.Bounds(0, 4)]
"""Steady-state surface fuel hazard score (0-4)"""

FHS_ns_Value = Annotated[int, ft.Bounds(0, 4)]
"""Steady-state near-surface fuel hazard score (0-4)"""

H_ns_Value = float
"""Steady-state near-surface fuel height (cm)"""

Fk_s_Value = float
"""Surface fuel accumulation rate (1/year)"""

Fk_ns_Value = float
"""Near-surface fuel accumulation rate (1/year)"""

Hk_ns_Value = float
"""Near-surface fuel height accumulation rate (1/year)"""

WRF_For_Value = Annotated[int, ft.Bounds(3, 5)]
"""Wind reduction factor (3 or 5)"""

FL_s_Value = float
"""Steady-state surface fuel load (ton/ha)"""

FL_ns_Value = float
"""Steady-state near-surface fuel load (ton/ha)"""

FL_el_Value = float
"""Steady-state elevated fuel load (ton/ha)"""

FL_b_Value = float
"""Steady-state bark fuel load (ton/ha)"""

FL_o_Value = float
"""Steady-state canopy fuel load (ton/ha)"""

H_o_Value = float
"""Canopy height (m)"""

H_el_Value = float
"""Elevated fuel height (m)"""

Fk_el_Value = float
"""Elevated fuel accumulation rate (1/year)"""

Fk_b_Value = float
"""Bark fuel accumulation rate (1/year)"""


class DryForestFuelParameters(ft.NoFuelParameters):
    r"""Forest specific fuel parameters"""

    FHS_s: FHS_s_Value
    FHS_ns: FHS_ns_Value
    H_ns: H_ns_Value
    Fk_s: Fk_s_Value
    Fk_ns: Fk_ns_Value
    Hk_ns: Hk_ns_Value
    WRF_For: WRF_For_Value
    FL_s: FL_s_Value
    FL_ns: FL_ns_Value
    FL_el: FL_el_Value
    FL_b: FL_b_Value
    FL_o: FL_o_Value
    H_o: H_o_Value
    H_el: H_el_Value
    Fk_el: Fk_el_Value
    Fk_b: Fk_b_Value


def calc_fuel_amount(time_since_fire, fuel_max, k):
    r"""Calculate fuel accumulated in the time since last fire

    ### Technical Guide

    In order to calculate the accumulated fuel load, each layer uses @olson1963
    curves to take the steady state fuel loads ($FL_x$) and fuel accumulation
    rates ($k_x$) and accumulate fuel based on the time since the last fire.
    These equations are based on @olson1963, and are defined as:

    $$
    Fuel\_Load_{x} = FL_{x} \left( 1 - e^{-k_{x} t} \right)
    $$ {#eq-fuel-accumulation}

    As well as calculating the amount of fuel available for flame height, the
    same equations are also used for calculating the accumulation of the
    fuel hazard scores, and the growth of the near-surface fuel height since the
    last fire.

    ### Implementation Details

    This function is just a light wrapper around
    `common.calc_accumulation_since_fire`, which shares Olson curves between the
    various spread models that use them.

    This function is used to calculate the fuel load, hazard score, or height
    for each layer of fuel based on the time since the last fire. The choice of
    which steady-state value and growth rates to use is currently done in the
    `calc_rate_of_spread` and `calc_intensity` functions. Some work is currently
    underway to separate out the fuel load calculations to be independent of the
    fire behaviour calculations.

    In the AFDRS Implementation, the steady state fuel loads, hazard scores or
    heights and their accumulation rates are provided and taken from the fuel
    parameters table.

    ### Usage

    ```python
    fuel_load = calc_fuel_amount(time_since_fire, fuel_max, k)
    ```

    ### Parameters

    - **time_since_fire** (*array_like*) - time since last fire (years)
    - **fuel_max** (*array_like*) - steady state fuel load (ton/ha)
    - **k** (*array_like*) - fuel accumulation rate (1/year)

    ### Returns

    - **fuel_load** (*array_like*) - accumulated fuel load (ton/ha)
    """
    return common.calc_accumulation_since_fire(time_since_fire, fuel_max, k)


def fuel_availability(drought_factor):
    r"""Calculate fuel availability based on drought factor

    ### Technical Guide

    The DEFFM/Vesta model of @cheney2012 does not include fuel availability or
    rainfall effects in its fuel moisture models and no recommendations are made
    for treatment of these effects on either fuel moisture or fuel hazard
    scores. While @matthews2006 provides a model which can be used for forest
    fuel moisture, implementation of a system of this complexity is not
    currently feasible and the model requires more work to improve accuracy
    across a range of conditions [@zhao2021; @zhao2022]. Instead, the AFDRS uses
    a simple function of drought factor provided by the Bureau of Meterorology
    loosely based on fire occurrence observations presented by @cawson2017.

    For dry forest, the fraction of fuel available for combustion for a given
    drought factor, $DF$, is given by:

    $$
    Fuel\_ availability\  = 0.1 \times DF
    $$ {#eq-fuel-availability-simple}

    Where $DF$ is a drought factor in the range 0 - 10, calculated and provided
    independently of the AFDRS by the Bureau of Meteorology, based on the
    accumulated soil moisture deficit, calculated using the Keetch-Byram Drought
    Index [@keetch1968] using daily rainfall and maximum temperature
    [@dowdy2018].

    ### Usage

    ```python
    fuel_modifier = fuel_availability(drought_factor)
    ```

    ### Parameters

    - **drought_factor** (*array_like*) - drought factor (0-10, unitless)

    ### Returns

    - **fuel_modifier** (*array_like*) - fraction of fuel available for
        combustion (0.0-1.0)
    """
    return 0.1 * drought_factor


def fuel_moisture_model(
    air_temperature, relative_humidity, time, wet_forest=False
):
    r"""
    Calculate dead fuel moisture (%)

    ### Technical Guide

    For dry forests, the dead fuel moisture is calculated using tables from
    @gould2007b and @matthews2010, by approximating from air temperature and
    relative humidity [@cruz2015b]:

    Sunny Afternoons: October to March, 12pm to 5pm

    $$
    MC_{sunny} = 2.76 + 0.124 RH - 0.0187 T
    $$ {#eq-moisture-content-sunny}

    Nighttime: All Year, 7pm to 6am

    $$
    MC_{night} = 3.08 + 0.198 RH - 0.0483 T
    $$ {#eq-moisture-content-night}

    Other: All other times

    $$
    MC_{other} = 3.60 + 0.169 RH - 0.0450 T
    $$ {#eq-moisture-content-other}

    Where $RH$ is the relative humidity (%), $T$ is the air temperature (°C),
    and $MC_x$ is the dead fuel moisture in condition $x$ (%).

    For wet forest, the dead fuel moisture is calculated using the same
    equations, but the sunny afternoon conditions is not used, so the two
    conditions are:

    - Nighttime: All Year, 7pm to 6am
    - Other: All other times

    ### Implementation Details

    This function can also be used to calculate the dead fuel moisture for wet
    forests by setting the `wet_forest` parameter to `True`.

    ### Usage

    ```python
    dead_fuel_moisture = fuel_moisture_model(
        air_temperature, relative_humidity, time
    )
    ```

    ### Parameters

    - **air_temperature** (*array_like*) - air temperature (°C)
    - **relative_humidity** (*array_like*) - relative humidity (%)
    - **time** (*tuple*) - (months, hours) - tuple of two *array_like*
      containing the month and hour of the day
    - **wet_forest** (*bool*) - optional, if `True`, calculate the dead fuel
        moisture for wet forests instead of dry forests. Default is `False`.

    ### Returns

    - **dead_fuel_moisture** (*array_like*) - dead fuel moisture (%)
    """
    # split time into months and hours
    months, hours = time

    # start with an nan array, of the same shape as relative_humidity
    fuel_moisture = np.full(relative_humidity.shape, np.nan)

    # for sunny afternoons, calculate the dead fuel moisture using the sunny
    # afternoon equation (only for dry forest)
    if wet_forest:
        # no sunny afternoon equation for wet forest, so set the mask to False
        sunny_mask = np.zeros(relative_humidity.shape, dtype=bool)
    else:
        sunny_mask = (
            ((months >= START_PEAK_MONTH) | (months <= END_PEAK_MONTH))
            & (hours >= START_AFTERNOON)
            & (hours <= END_AFTERNOON)
        )
    if sunny_mask.any():
        fuel_moisture[sunny_mask] = (
            2.76
            + 0.124 * relative_humidity[sunny_mask]
            - 0.0187 * air_temperature[sunny_mask]
        )

    # for nighttime, calculate the dead fuel moisture using the nighttime
    # equation
    night_mask = (hours <= SUNRISE) | (hours >= SUNSET)
    if night_mask.any():
        fuel_moisture[night_mask] = (
            3.08
            + 0.198 * relative_humidity[night_mask]
            - 0.0483 * air_temperature[night_mask]
        )

    # for all other times, calculate the dead fuel moisture using the other
    # equation
    other_mask = np.logical_not(sunny_mask | night_mask)
    if other_mask.any():
        fuel_moisture[other_mask] = (
            3.60
            + 0.169 * relative_humidity[other_mask]
            - 0.0450 * air_temperature[other_mask]
        )

    return fuel_moisture


def calc_rate_of_spread(
    fuel_moisture,
    wind_speed,
    drought_factor,
    time_since_fire,
    FHS_s,
    FHS_ns,
    H_ns,
    Fk_s,
    Fk_ns,
    Hk_ns,
    wind_reduction_factor,
    fuel_modifier=None,
):
    r"""
    Calculate rate of spread for dry forest (m/h)

    ### Technical Guide

    The DEFFM/Vesta model of @cheney2012 is used to calculate the rate of a
    going fire with a shrubby understory in dry eucalyptus forests, under dry
    summer conditions. It assumes that the fire has reached its quasi-steady
    state.

    DEFFM/Vesta incorporates the fuel structure of a forest, namely litter
    fuels, near-surface fuels, elevated fuels and bark. Following @cheney2012,
    there are two options to represent the fuel strata, i.e. by using Fuel
    Hazards Scores (FHS, a number ranging from 0 to 4), and Fuel Hazard Ratings
    (FHR, categories ranging from low to extreme). If available, using the
    scores (FHS) is the preferred option. If none of this information is
    available, default values as presented by @gould2011, @csiro2015 and
    @plucinski2017 can be used.

    For the AFDRS, the FHS option is taken. In cases where we information is not
    available on near-surface fuel height--which is an important input
    for using the FHS--a default value is used. Where data was available as
    ratings rather than scores, these were converted as described in
    Chapter 4 of @matthews2019.

    In its general form, potential rate of spread (steady state) can be
    written as:

    $$
    ROS_{SS} = \Phi_{U}(U_{10}) 
        \times \Phi_{f}(F_1, F_2, \ldots, F_n)
        \times \Phi_{M}(MC)
        \times \Phi_{\theta}(\theta)
    $$ {#eq-rate-of-spread-general}

    where $\Phi_x$ are functions of the wind speed $\Phi_{U}$, fuel structure
    $\Phi_{f}$, fuel moisture $\Phi_{M}$ and slope $\Phi_{\theta}$ contributing
    to the rate of spread. $U_{10}$ is the 10m open wind speed (km/h), $F_1,
    F_2, \ldots, F_n$ are the fuel parameters, $MC$ is the fuel moisture
    content, and $\theta$ is the slope.

    :::{.callout-note}
    The AFDRS does not currently include slope in the rate of spread
    calculations, and therefore $\Phi_{\theta}$ is always set to 1, or
    alternatively, ignored.
    :::

    When the wind speed is below a threshold speed of 5 km/h then conditions are
    light and fire spread will be erratic and speed and direction. Therefore a
    threshold of 5km/h was used to define the behaviour of the $ROS$, below
    which the rate of spread is set to 30 m/h in conditions of 7% fine-fuel
    moisture content. Below this threshold, the rate of spread is only modified
    by moisture content. Above this threshold, the rate of spread is
    modified by wind speed, fuel structure and moisture content:

    $$
    \begin{aligned}
    \Delta ROS &= \left\{
        \begin{array}{ll}
            0 & \text{if } U_{10} \leq U_T \\
            \Phi_{U}(U_{10} - U_T)
            \times \Phi_{f}(F_1, F_2, \ldots, F_n)
                & \text{if } U_{10} > U_T
        \end{array} \right. \\
    ROS &= \Phi_{M}(MC) \times (ROS_T + \Delta ROS)
    \end{aligned}
    $$ {#eq-rate-of-spread-threshold}

    where $ROS_T$ is the threshold rate of spread, set at 30 m/h, and $U_T$ is
    the threshold wind speed, set at 5 km/h.

    #### Wind speed ($\Phi_{U}$)

    The additional rate of spread (above 30 m/h) due to wind speed is modelled
    as a power function of the wind speed above 5 km/h:

    $$
    \Phi_{U}(U_{10} - U_T) = 1.5308(U_{10} - U_T)^{0.8576}
    $$ {#eq-rate-of-spread-wind-speed}

    In the AFDRS, the rate of spread was further modified with a wind reduction
    factor first (since the presence of trees will reduce the wind speed near
    the ground and therefore the rate of spread through the surface and
    near-surface fuels), by replacing $U_{10}$ in @eq-rate-of-spread-threshold
    (and @eq-rate-of-spread-wind-speed if applicable) with $U_{mod}$, defined as

    $$
    U_{mod} = \frac{3}{WRF} U_{10}
    $$ {#eq-rate-of-spread-wind-speed-mod}

    where $WRF$ is the wind reduction factor, which is 3 for forests (K.
    Tolhurst pers. comm.).

    #### Fuel structure ($\Phi_{f}$)

    For the FHS option, the fuel structure is represented by a combination of
    the surface FHS ($FHS_s$), the near-surface FHS ($FHS_{ns}$) and the
    near-surface height ($H_{ns}$):

    $$
    \Phi_{f}(FHS_s, FHS_{ns}, H_{ns}) = FHS_s^{0.9301} 
        \times \left( FHS_{ns} H_{ns} \right)^{0.6366} 
        \times 1.03
    $$ {#eq-rate-of-spread-fuel-structure-fhs}

    where the choice of fuel parameters and the coefficients were determined by
    @cheney2012 using a stepwise multiple regression analysis.

    :::{.callout-note} 
    Testing during the Research Prototype phase showed over
    prediction of rate of spread in forests with high near-surface heights
    ($H_{ns}$). As this parameter was uncertain for many fuel types, the default
    and maximum value of $H_{ns}$ used was changed from 25 cm to 20 cm. Missing
    values will be set to 20 cm, and larger values will be clipped to 20 cm.
    :::

    Before using the FHS values, the steady-state fuel hazard scores are
    replaced by the currently predicted fuel hazard that has accumulated since
    the last fire, calculated elsewhere in this model, and then adjusted for
    fuel availability based on the drought factor.

    #### Fuel moisture ($\Phi_{M}$)

    The fuel moisture content is based on the relationship between fuel moisture
    content and rate of fire spread established in jarrah forest by
    @burrows1999, but modified with upper and lower limits estimated from
    @cruz2021:
    
    $$
        \Phi_{M}(MC) = \left\{
        \begin{array}{ll}
            18.35 \times 4^{-1.495} & \text{if } MC \leq 4 \\
            18.35 \times MC^{-1.495} & \text{if } 4 < MC \leq 20 \\
            0.05 & \text{if } MC > 20
        \end{array} \right.
    $$ {#eq-rate-of-spread-fuel-moisture}

    where $MC$ is the fuel moisture content (%) estimated elsewhere in this
    model.

    :::{.callout-note} 
    This is not the exactly the same as any of the three
    approaches taken by @cruz2021 ($\Phi Md_B$, $\Phi Md_L$, or $\Phi Md_P$),
    but is a compromise between the three approaches, with adjusted thresholds.
    :::

    ### Implementation Details

    In order to adjust the forest ROS according to individual fuel types, the
    following parameters are provided in the fuel parameters table, which is
    updated by each jurisdiction for their fuel types:
    
    - $FHS_s$ (`FHS_s`) - steady-state surface fuel hazard score (0-4)
    - $FHS_{ns}$ (`FHS_ns`) - steady-state near-surface fuel hazard score (0-4)
    - $H_{ns}$ (`H_ns`) - steady-state near-surface fuel height (cm)
    - $Fk_s$ (`Fk_s`) - surface fuel accumulation rate (1/year)
    - $Fk_{ns}$ (`Fk_ns`) - near-surface fuel accumulation rate (1/year)
    - $Hk_{ns}$ (`Hk_ns`) - near-surface fuel height accumulation rate (1/year)
    - $WRF$ - (`WRF_For`) wind reduction factor (unitless)

    If a `fuel_modifier` *array_like* is provided, it will be used to adjust
    the fuel hazard scores before calculating the rate of spread, instead of
    calling the `fuel_availability` function. This is used for the wet forest
    model, where the fuel availability is calculated differently.

    ### Usage

    ```python
    rate_of_spread = calc_rate_of_spread(
        fuel_moisture, wind_speed, drought_factor, time_since_fire,
        FHS_s, FHS_ns, H_ns, Fk_s, Fk_ns, Hk_ns, wind_reduction_factor
    )
    ``` 

    ### Parameters

    - **fuel_moisture** (*array_like*) - dead fuel moisture (%)
    - **wind_speed** (*array_like*) - 10m open wind speed (km/h)
    - **drought_factor** (*array_like*) - drought factor (0-10, unitless)
    - **time_since_fire** (*array_like*) - time since last fire (years)
    - **FHS_s** (*int*) - steady-state surface fuel hazard score (0-4)
    - **FHS_ns** (*int*) - steady-state near-surface fuel hazard score (0-4)
    - **H_ns** (*float*) - steady-state near-surface fuel height (cm)
    - **Fk_s** (*float*) - surface fuel accumulation rate (1/year)
    - **Fk_ns** (*float*) - near-surface fuel accumulation rate (1/year)
    - **Hk_ns** (*float*) - near-surface fuel height accumulation rate (1/year)
    - **wind_reduction_factor** (*float*) - wind reduction factor (unitless)
    - **fuel_modifier** (*array_like*) - optional, fraction of fuel
        available for combustion (0.0-1.0) - if not provided, the
        `fuel_availability` function will be used to calculate this. 

    ### Returns

    - **rate_of_spread** (*array_like*) - rate of spread (m/h)
    """
    ### Calculate the wind speed factor

    # setup a nan array of the same shape as the inputs
    wind_speed_factor = np.full(wind_speed.shape, np.nan)

    # calculate the modified wind speed due to the wind reduction factor
    wind_speed_mod = wind_speed * 3.0 / wind_reduction_factor

    # additional wind_speed_factor is 0 for wind speeds below 5 km/h
    below_threshold_mask = wind_speed_mod <= THRESHOLD_WIND_SPEED
    if below_threshold_mask.any():
        wind_speed_factor[below_threshold_mask] = 0

    # additional wind_speed_factor is calculated using the power function for
    # wind speeds above 5 km/h
    above_threshold_mask = np.logical_not(below_threshold_mask)
    if above_threshold_mask.any():
        wind_speed_factor[above_threshold_mask] = 1.5308 * np.power(
            wind_speed_mod[above_threshold_mask] - THRESHOLD_WIND_SPEED, 0.8576
        )

    ### Calculate the fuel structure factor

    # for winds below 5 km/h, the fuel structure factor is 1.0
    fuel_structure_factor = np.full(wind_speed.shape, np.nan)
    if below_threshold_mask.any():
        fuel_structure_factor[below_threshold_mask] = 1.0

    # For winds above 5 km/h, adjust the fuel hazards scores and heights
    # according to the time since the last fire
    if above_threshold_mask.any():
        aFHS_s = calc_fuel_amount(
            time_since_fire[above_threshold_mask], FHS_s, Fk_s
        )
        aFHS_ns = calc_fuel_amount(
            time_since_fire[above_threshold_mask], FHS_ns, Fk_ns
        )
        aH_ns = calc_fuel_amount(
            time_since_fire[above_threshold_mask], H_ns, Hk_ns
        )
        aH_ns = np.clip(aH_ns, 0, 20)  # clip to 20 cm

        # Further adjust the fuel hazard scores according to the fuel
        # availability modifier
        if fuel_modifier is None:
            fuel_modifier = fuel_availability(
                drought_factor[above_threshold_mask]
            )
        else:
            fuel_modifier = fuel_modifier[above_threshold_mask]

        aFHS_s = fuel_modifier * aFHS_s
        aFHS_ns = fuel_modifier * aFHS_ns

        # Calculate the fuel structure factor for winds above 5 km/h
        fuel_structure_factor[above_threshold_mask] = (
            np.power(aFHS_s, 0.9301) * np.power(aFHS_ns * aH_ns, 0.6366) * 1.03
        )

    ### Calculate the fuel moisture factor

    fuel_moisture_factor = np.full(fuel_moisture.shape, np.nan)

    # clip the fuel moisture to be above 4%
    fuel_moisture = np.clip(fuel_moisture, 4, None)

    # below 20% fuel moisture, the fuel moisture factor is calculated
    # using the power function
    low_moisture_mask = fuel_moisture <= 20
    if low_moisture_mask.any():
        fuel_moisture_factor[low_moisture_mask] = 18.35 * np.power(
            fuel_moisture[low_moisture_mask], -1.495
        )

    # above 20% fuel moisture, the fuel moisture factor is 0.05
    high_moisture_mask = fuel_moisture > 20
    if high_moisture_mask.any():
        fuel_moisture_factor[high_moisture_mask] = 0.05

    ### Calculate the delta rate of spread based on the wind speed and fuel
    ### structure factors, thresholded by the wind speed threshold

    deltaROS = np.full(wind_speed.shape, np.nan)
    if below_threshold_mask.any():
        deltaROS[below_threshold_mask] = 0
    if above_threshold_mask.any():
        deltaROS[above_threshold_mask] = (
            wind_speed_factor[above_threshold_mask]
            * fuel_structure_factor[above_threshold_mask]
        )

    ### Calculate the rate of spread, modified by the fuel moisture factor

    rate_of_spread = (THRESHOLD_ROS + deltaROS) * fuel_moisture_factor

    return rate_of_spread


def calc_intensity(
    drought_factor,
    time_since_fire,
    flame_height,
    rate_of_spread,
    FL_s,
    FL_ns,
    FL_el,
    FL_b,
    FL_o,
    H_o,
    Fk_s,
    Fk_ns,
    Fk_el,
    Fk_b,
    fuel_modifier=None,
):
    r"""Calculate fireline intensity (kW/m)

    ### Technical Guide

    For calculating fire-line intensity in forests, fuel is added progressively
    into based on flame height, before calculating the intensity using the
    @byram1959 equation. Surface and near-surface fuels are always included,
    elevated fuels are included if flame height is over 1 m and 50% of the
    canopy fuels are included if flame height is more than two thirds (66%) of
    the canopy height.

    Similarly to the hazard scores in the ROS calculations, the steady-state
    fuel loads provided in the fuel parameters table are replaced by the
    currently predicted fuel load that has accumulated since the last fire,
    calculated elsewhere in this model, and then adjusted for fuel availability
    based on the drought factor.

    Once the fuel loads have been calculated, the intensity is calculated using
    the following equation from @byram1959:

    $$
    I = h \times F \times ROS
    $$ {#eq-fire-intensity}

    Where $h$ is the heat yield, assumed here to be 18,600 kJ/kg, $F$ is the
    fuel load in kg/m^2 and $ROS$ is the rate of spread in m/s.

    ### Implementation Details

    In order to adjust the forest ROS according to individual fuel types, the
    following parameters are provided in the fuel parameters table, which is
    updated by each jurisdiction for their fuel types:

    - $FL_s$ (`FL_s`) - steady-state surface fuel load (ton/ha)
    - $Fk_s$ (`Fk_s`) - surface fuel accumulation rate (1/year)
    - $FL_{ns}$ (`FL_ns`) - steady-state near-surface fuel load (ton/ha)
    - $Fk_{ns}$ (`Fk_ns`) - near-surface fuel accumulation rate (1/year)
    - $FL_{el}$ (`FL_el`) - steady-state elevated fuel load (ton/ha)
    - $Fk_{el}$ (`Fk_el`) - elevated fuel accumulation rate (1/year)
    - $FL_b$ (`FL_b`) - steady-state bark fuel load (ton/ha)
    - $Fk_b$ (`Fk_b`) - bark fuel accumulation rate (1/year)
    - $FL_o$ (`FL_o`) - steady-state canopy fuel load (ton/ha)
    - $H_o$ (`H_o`) - canopy height (m)

    The canopy fuel load is always treated as the steady-state fuel load, but
    all others are treated as the accumulated fuel load since the last fire
    using the `calc_fuel_amount` function. All fuel loads (including the canopy)
    are then adjusted for fuel availability based on the drought factor using
    the `fuel_availability` function. Surface fuel loads are also clipped to a
    maximum of 10 t/ha.

    If a `fuel_modifier` *array_like* is provided, it will be used to adjust
    the fuel loads before calculating the intensity instead of calling the
    `fuel_availability` function. This is used for the wet forest model, where
    the fuel availability is calculated differently.

    :::{.callout-note}
    At present, while the bark fuel load is included in the inputs, it is not
    actually used in the calculations.
    :::

    Once the fuel loads have been calculated, the intensity is calculated using
    `common.calc_fire_intensity`, which implements the equation above.

    ### Usage

    ```python
    intensity = calc_intensity(
        drought_factor, time_since_fire, flame_height, rate_of_spread,
        FL_s, FL_ns, FL_el, FL_b, FL_o,
        H_o, Fk_s, Fk_ns, Fk_el, Fk_b
    )
    ```

    ### Parameters

    - **drought_factor** (*array_like*) - drought factor (0-10, unitless)
    - **time_since_fire** (*array_like*) - time since last fire (years)
    - **flame_height** (*array_like*) - flame height (m)
    - **rate_of_spread** (*array_like*) - rate of spread (m/h)
    - **FL_s** (*float*) - steady-state surface fuel load (ton/ha)
    - **FL_ns** (*float*) - steady-state near-surface fuel load (ton/ha)
    - **FL_el** (*float*) - steady-state elevated fuel load (ton/ha)
    - **FL_b** (*float*) - steady-state bark fuel load (ton/ha)
    - **FL_o** (*float*) - steady-state canopy fuel load (ton/ha)
    - **H_o** (*float*) - canopy height (m)
    - **Fk_s** (*float*) - surface fuel accumulation rate (1/year)
    - **Fk_ns** (*float*) - near-surface fuel accumulation rate (1/year)
    - **Fk_el** (*float*) - elevated fuel accumulation rate (1/year)
    - **Fk_b** (*float*) - bark fuel accumulation rate (1/year)
    - **fuel_modifier** (*array_like*) - optional, fraction of fuel
        available for combustion (0.0-1.0) - if not provided, the
        `fuel_availability` function will be used to calculate this.

    ### Returns

    - **intensity** (*array_like*) - Fireline intensity (kW/m)
    """
    # Adjust the fuel loads based on the time since last fire
    aFL_s = calc_fuel_amount(time_since_fire, FL_s, Fk_s)
    aFL_ns = calc_fuel_amount(time_since_fire, FL_ns, Fk_ns)
    aFL_el = calc_fuel_amount(time_since_fire, FL_el, Fk_el)
    aFL_b = calc_fuel_amount(time_since_fire, FL_b, Fk_b)
    aFL_o = FL_o  # treat canopy fuel load as steady-state

    # Adjust the fuel loads based on the fuel availability
    if fuel_modifier is None:
        fuel_modifier = fuel_availability(drought_factor)

    aFL_s = np.clip(fuel_modifier * aFL_s, 0, 10)  # clip to 10 t/ha
    aFL_ns = fuel_modifier * aFL_ns
    aFL_el = fuel_modifier * aFL_el
    aFL_b = fuel_modifier * aFL_b
    aFL_o = fuel_modifier * aFL_o

    # Always include the surface and near-surface fuels
    fuel_load = aFL_s + aFL_ns

    # Include the elevated fuels if the flame height is over 1 m
    mask = flame_height > FLAME_HEIGHT_ELEVATED
    if mask.any():
        fuel_load[mask] += aFL_el[mask]

    # Include 50% of the canopy fuels if the flame height is more than two
    # thirds (66%) of the canopy height
    mask = flame_height > (H_o * FLAME_HEIGHT_CROWN_FRACTION)
    if mask.any():
        fuel_load[mask] += 0.5 * aFL_o[mask]

    # Calculate the intensity
    intensity = common.calc_fire_intensity(
        fuel_load, rate_of_spread, HEAT_CONTENT
    )

    return intensity


def calc_flame_height(rate_of_spread, height_el):
    r"""Calculate flame height in m

    ### Technical Guide

    For forests with high litter fuel loads, the contribution of the surface
    litter to flame height and intensity was capped at 10 t/ha, to represent the
    process of fire burning across then down into the fuel bed.

    Flame height (m) was calculated using the surface rate-of-spread and the
    elevated fuel height, using the equation from @cheney2012:

    $$
    Flame\_height = 0.0193 ROS^{0.723} e^{0.64 H_{el}} 1.07
    $$ {#eq-flame-height}

    where $ROS$ is the estimated rate of spread (m/h), and $H_{el}$ is the
    elevated fuel height (m), taken from the fuel parameters table.

    :::{.callout-note}
    In @cheney2012, the flame height is calculated with the
    elevated fuel height, $H_{el}$, in centimetres with a coefficient of 0.0064.
    This was converted to metres in the AFDRS (and is provided as such in the
    fuel parameters table), with the coefficient adjusted to 0.64.
    :::

    ### Usage

    ```python
    flame_height = calc_flame_height(rate_of_spread, height_el)
    ```

    ### Parameters

    - **rate_of_spread** (*array_like*) - rate of spread (m/h)
    - **height_el** (*float*) - elevated fuel height (m)

    ### Returns

    - **flame_height** (*array_like*) - flame height (m)
    """
    # calculated using eqn 11 from @cheney2012
    flame_height = (
        0.0193
        * np.power(rate_of_spread, 0.723)
        * np.exp(0.64 * height_el)
        * 1.07
    )

    return flame_height


def calc_spotting_distance(rate_of_spread, wind_speed, FHS_s):
    r"""Calculate spotting distance in m.

    ### Technical Guide

    For spotting the AFDRS uses an equation currently used by Fire Behaviour
    Analysts in Australia (K. Tolhurst pers. comm.)

    If the rate of spread is less than 150 m/h, the spotting distance is set to
    50 m.

    If the rate of spread is greater than 150 m/h, the spotting distance is
    calculated as:

    $$
    \text{Spotting\_distance} = \left| \begin{gathered}
        176.969 \arctan(FHS_s) 
            \left(\frac{ROS}{U_{10}^{0.25}} \right)^{0.5} \\
        + 1568800 FHS_s \left( \frac{ROS}{U_{10}^{0.25}} \right)^{1.5} 
            - 3015.09
    \end{gathered} \right|
    $$ {#eq-spotting-distance}

    where $ROS$ is the estimated rate of spread (m/h), $U_{10}$ is the 10m open
    wind speed (km/h), and $FHS_s$ is the steady state surface fuel hazard score
    (0-4).

    ### Usage

    ```python
    spotting_distance = calc_spotting_distance(
        rate_of_spread, wind_speed, FHS_s
    )
    ```

    ### Parameters

    - **rate_of_spread** (*array_like*) - rate of spread (m/h)
    - **wind_speed** (*array_like*) - 10m open wind speed (km/h)
    - **FHS_s** (*int*) - steady-state surface fuel hazard score (0-4)

    ### Returns

    - **spotting_distance** (*array_like*) - spotting distance (m)
    """

    spotting_distance = np.full(rate_of_spread.shape, np.nan)
    low_ROS_mask = rate_of_spread < 150.0
    if low_ROS_mask.any():
        spotting_distance[low_ROS_mask] = 50.0

    high_ROS_mask = np.logical_not(low_ROS_mask)
    if high_ROS_mask.any():
        spotting_distance[high_ROS_mask] = np.absolute(
            176.969
            * np.arctan(FHS_s)
            * np.power(
                rate_of_spread[high_ROS_mask]
                / np.power(wind_speed[high_ROS_mask], 0.25),
                0.5,
            )
            + 1568800
            * np.power(FHS_s, -1)
            * np.power(
                rate_of_spread[high_ROS_mask]
                / np.power(wind_speed[high_ROS_mask], 0.25),
                -1.5,
            )
            - 3015.09
        )

    return spotting_distance


def calculate(
    dataset: DryForestInputVariables, fuel_parameters: DryForestFuelParameters
) -> ft.CommonOutputIndices:
    r"""
    Main entry point for forest fire behaviour calculations.

    ### Usage

    ```python
    indices = calculate(dataset, fuel_parameters)
    ```

    ### Parameters

    - **dataset** (*dict*) - A dictionary of *array_like* containing the input
        variables.

        From these input variables, only the following are used by this model:

        - **T_SFC** - air temperature (°C)
        - **RH_SFC** - relative humidity (%)
        - **WindMagKmh_10m** : Wind magnitude at 10m (km/h)
        - **DF_SFC** - drought factor (0-10, unitless)
        - **time_since_fire** - time since last fire (years)
        - **months** - month of the year (1-12)
        - **hours** - hour of the day (0-23)

    - **fuel_parameters** A dictionary of scalars containing the fuel
      parameters.

        From these fuel parameters, only the following are used by this model:

        - **FHS_s** : steady-state surface fuel hazard score (0-4)
        - **FHS_ns** : steady-state near-surface fuel hazard score (0-4)
        - **H_ns** : steady-state near-surface fuel height (cm)
        - **Fk_s** : surface fuel accumulation rate (1/year)
        - **Fk_ns** : near-surface fuel accumulation rate (1/year)
        - **Hk_ns** : near-surface fuel height accumulation rate (1/year)
        - **WRF_For** : wind reduction factor (unitless)
        - **FL_s** : steady-state surface fuel load (ton/ha)
        - **FL_ns** : steady-state near-surface fuel load (ton/ha)
        - **FL_el** : steady-state elevated fuel load (ton/ha)
        - **FL_b** : steady-state bark fuel load (ton/ha)
        - **FL_o** : steady-state canopy fuel load (ton/ha)
        - **H_o** : canopy height (m)
        - **H_el** : elevated fuel height (m)
        - **Fk_el** : elevated fuel accumulation rate (1/year)
        - **Fk_b** : bark fuel accumulation rate (1/year)

    ### Returns

    - **indices** (*dict*) - A dictionary of *array_like* containing the
        output variables of the same shape as the input arrays with the
        following keys:

        - **dead_fuel_moisture** - dead fuel moisture (%)
        - **rate_of_spread** - rate of spread (m/h)
        - **flame_height** - flame height (m)
        - **intensity** - fireline intensity (kW/m)
        - **spotting_distance** - spotting distance (m)
        - **rating_1** - fire danger rating (unitless)
        - **index_1** - fire behaviour index (unitless)
    """
    # standardize the dataset variables
    dataset = standardize_dataset_variables(dataset)

    # Calculate the dead fuel moisture
    dead_fuel_moisture = fuel_moisture_model(
        dataset["T_SFC"],
        dataset["RH_SFC"],
        (dataset["months"], dataset["hours"]),
    )

    # Calculate the rate of spread
    rate_of_spread = calc_rate_of_spread(
        dead_fuel_moisture,
        dataset["WindMagKmh_10m"],
        dataset["DF_SFC"],
        dataset["time_since_fire"],
        fuel_parameters["FHS_s"],
        fuel_parameters["FHS_ns"],
        fuel_parameters["H_ns"],
        fuel_parameters["Fk_s"],
        fuel_parameters["Fk_ns"],
        fuel_parameters["Hk_ns"],
        fuel_parameters["WRF_For"],
    )

    # Calculate the flame height
    flame_height = calc_flame_height(rate_of_spread, fuel_parameters["H_el"])

    # Calculate the intensity
    intensity = calc_intensity(
        dataset["DF_SFC"],
        dataset["time_since_fire"],
        flame_height,
        rate_of_spread,
        fuel_parameters["FL_s"],
        fuel_parameters["FL_ns"],
        fuel_parameters["FL_el"],
        fuel_parameters["FL_b"],
        fuel_parameters["FL_o"],
        fuel_parameters["H_o"],
        fuel_parameters["Fk_s"],
        fuel_parameters["Fk_ns"],
        fuel_parameters["Fk_el"],
        fuel_parameters["Fk_b"],
    )

    # calculate the spotting distance
    # TODO: should the FHS_s parameter be adjusted for time since fire? See
    # https://gitlab.com/afdrs/afdrs-dev/packages/python-packages/fdrs_calcs/-/issues/23
    spotting_distance = calc_spotting_distance(
        rate_of_spread,
        dataset["WindMagKmh_10m"],
        fuel_parameters["FHS_s"],
    )

    # calculate the fire danger rating and fire behaviour index from the
    # intensity only
    index_1 = fire_behaviour_index.forest(intensity)
    rating_1 = fire_danger_rating.fire_danger_rating(index_1)

    return {
        "dead_fuel_moisture": dead_fuel_moisture,
        "rate_of_spread": rate_of_spread,
        "flame_height": flame_height,
        "intensity": intensity,
        "spotting_distance": spotting_distance,
        "rating_1": rating_1,
        "index_1": index_1,
    }
