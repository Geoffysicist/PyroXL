r"""
Fire behaviour calculations for mallee-heath

## Technical Guide

The AFDRS Mallee Heath Model is used for semi-arid shrublands with a mallee-form
eucalypt canopy and shrubby understorey. Mallee heath covers approximately 3.5%
of Australia, is found in WA, SA, NSW and VIC, and has a significant influence
in 21 Fire Weather Areas.

### What is the AFDRS Mallee heath model? {#sec-mallee-heath-model}

The model used for mallee heath fuels in AFDRS is the Semi-arid mallee heath
model by @cruz2013. It combines data sets from previous research into mallee
heath fuels. This model has a go/no-go threshold for fire spread.

### Inputs and outputs {#sec-inputs}

The mallee heath model was designed for mallee fuel types with a shrubby
understory. It goes through different steps:

-   The likelihood of fire propagation is determined ("go/no-go").

-   The type of fire is predicted, i.e. surface or crown fire.

-   Rate of spread is determined for either a surface or a crown fire
    (or a weighted average of the two).

These processes require input values for 10m wind speed, moisture content of
dead litter fuels, overstorey coverage, and overstorey height. Moisture content
is derived from temperature and relative humidity as usual, but also includes
terms for precipitation over the previous 48 hours, time since
precipitation/dewfall stopped, cloud cover and the time of year/day. 

The calculation for fuel load (required for intensity calculation) also needs
the steady state fuel loads and fuel accumulation rates for the surface and the
overstorey, as well as time since fire (TSF).

### Fuel Sub-Types {#sec-fuel-types}

The Mallee-Heath fuel type does not have defined sub-fuels. Semi-arid woodlands
and shrublands with similar structure, such as mallee, casuarina woodlands or
shrublands, have been grouped into this fuel type. This type of fuel consists of
fine materials less than 6mm in diameter which becomes flammable quicker than
forest type fuels. Vegetation classified as mallee that has a spinifex
understorey has been classified to the spinifex woodland fuel sub-type as
spinifex is the dominant influence on fire spread in that vegetation

### Model behaviour and limitations {#sec-limitations}

This model is directly applicable to prescribed burn operations (this is what it
was developed for), but it is also considered suitable for first-order
approximations of wildfire behaviour.

The original model assumes the fuels are dry and does not account for recent
rainfall. For AFDRS, a moisture content modifier was added to account for recent
rainfall and the subsequent progressive drying of fuels. Mallee Heath fuels are
expected to become flammable more rapidly than forests, so the moisture modifier
function originally developed for buttongrass fuels was chosen as it has a
response time of 1-2 days.

The model uses generalised mallee heights and coverage as indicators for overall
fuel state (to make the model easier to run), but this does not account for
variation in the understorey fuel characteristics. This model is most sensitive
to wind speed and less sensitive to fuel condition and dead fuel moisture
content. Wind is necessary to sustain fire propagation for fuel moisture
contents of 6% or higher.

:::{.callout-note}
The descriptions of mallee heath, spinifex woodland and
acacia woodland fuels are very similar; the NFDRS report notes that the
classifications of these semi-arid vegetation types could use more careful
review. 
:::
"""

import numpy as np

from . import fire_behaviour_index
from . import fire_danger_rating
from .. import typing as ft
from . import dry_forest
from . import common
from .common import standardize_dataset_variables

START_PEAK_MONTH = 10  # October
END_PEAK_MONTH = 3  # March
START_AFTERNOON = 12
END_AFTERNOON = 17
HEAT_CONTENT = 18600  # KJ/kg


# add additional type hints for mallee heath specific inputs
class MalleeHeathInputVariables(ft.CommonInputVariables):
    r"""Mallee heath specific input variables"""

    precipitation: ft.precipitation_Array
    time_since_rain: ft.time_since_rain_Array
    time_since_fire: ft.time_since_fire_Array
    months: ft.months_Array
    hours: ft.hours_Array


crown_probability_Array = ft.InputVariableArray[np.float64]
"""Probability of crown fire (%)"""

spread_probability_Array = ft.InputVariableArray[np.float64]
"""Probability of fire spread (%)"""


class MalleeHeathOutputIndices(ft.CommonOutputIndices):
    r"""Mallee heath specific additional output variables"""

    crown_probability: crown_probability_Array
    spread_probability: spread_probability_Array


Fk_o_Value = float
"""Crown fuel accumulation rate (1/year)"""

Cov_o_Value = float
"""Percent of over-storey cover (%)"""


class MalleeHeathFuelParameters(ft.NoFuelParameters):
    r"""Mallee heath specific fuel parameters"""

    FL_s: dry_forest.FL_s_Value
    FL_o: dry_forest.FL_o_Value
    Fk_s: dry_forest.Fk_s_Value
    H_o: dry_forest.H_o_Value
    Fk_o: Fk_o_Value
    Cov_o: Cov_o_Value


def calc_fuel_moisture(
    relative_humidity, air_temperature, time, precipitation, time_since_rain
):
    r"""Calculate fuel moisture content (%)

    ### Technical Guide

    The @cruz2013 mallee-heath and @anderson2015 shrubland models do not include
    fuel availability or rainfall effects in their fuel moisture models and no
    recommendations are made for treatment of these effects on either fuel
    moisture or fuel cover/height. Because these fuel types are expected to
    become flammable more rapidly than a forest fuel type, the AFDRS uses the
    @marsden1999 fuel moisture modifier function originally developed for
    buttongrass. While these fuel types are structurally dissimilar, the
    buttongrass fuel moisture modification function has a response time of 1-2
    days, making it suitable for fuel types with a large near-surface and
    elevated fuel component.

    Similar to the heathland (shrubland) model, dead fuel moisture content is
    calculated in the AFDRS as a combination of two components, $MC_1$ and
    $MC_2$, as follows:

    $$
    MC = MC_1 + MC_2
    $$ {#eq-mallee-mc}

    where the two components are defined as follows (@cruz2015a, @marsden1999):

    $$
    \begin{aligned}
    MC_1 &= 4.74 + 0.108 RH - 0.1(T - 25) - \Delta(1.68 + 0.028 RH) \\
    MC_2 &= 67.128(1 - e^{-3.132 P })e^{-0.0858 TSR}
    \end{aligned}
    $$ {#eq-mallee-mc-components}

    where $RH$ is relative humidity (%), $T$ is air temperature (°C), $P$ is
    precipitation (mm) in the last 48 hours, and $TSR$ is time since rain
    (hours).

    In addition, $\Delta$ is the radiation factor, which as per @cruz2015a, is
    set to 1.0 for sunny days in the period 12:00 - 17:00 October - March, and
    0.0 otherwise. 

    ### Usage

    ```python
    fuel_moisture = calc_fuel_moisture(
        relative_humidity, air_temperature, time, precipitation, time_since_rain
    )
    ```

    ### Parameters

    - **relative_humidity** (*array-like*) - relative humidity (%)
    - **air_temperature** (*array-like*) - air temperature (°C)
    - **time** (*array-like*, *array-like*) - time of day and year (months,
        hours)
    - **precipitation** (*array-like*) - precipitation (mm) in the last 48 hours
    - **time_since_rain** (*array-like*) - time since rain (hours)

    ### Returns

    - **fuel_moisture** (*array-like*) - fuel moisture content (%)
    """
    # unpack time
    months, hours = time

    # calculate delta
    delta = (
        (hours >= START_AFTERNOON)
        & (hours < END_AFTERNOON)
        & (months >= START_PEAK_MONTH)
        & (months <= END_PEAK_MONTH)
    ).astype(int)

    # calculate fuel moisture components
    fuel_moisture_1 = (
        4.74
        + 0.108 * relative_humidity
        - 0.1 * (air_temperature - 25)
        - delta * (1.68 + (0.028 * relative_humidity))
    )
    fuel_moisture_2 = (
        67.128
        * (1 - np.exp(-3.132 * precipitation))
        * np.exp(-0.0858 * time_since_rain)
    )

    # calculate and return fuel moisture
    return fuel_moisture_1 + fuel_moisture_2


def calc_spread_probability(wind_speed, fuel_moisture, overstorey_cover):
    r"""Calculate the likelihood of spread sustainability (go/no-go)

    ### Technical Guide

    A number of models were estimated for the likelihood of fire spread in
    mallee heath by @cruz2013. The model chosen for AFDRS was based on the 10m
    wind speed $U_{10}$, fuel moisture content $MC$ and the proportion of
    over-storey cover $O_c$. overstory cover was chosen over using near-surface
    fuel load as it was considered easier to estimate.

    With this model, the probability of spread is calculated as follows:

    $$
    P_{spread} = \frac{1}{1 + e^{-(14.624 + 0.2066 U_{10} - 1.8719 MC -
        3.0442 O_c)}}
    $$ {#eq-mallee-spread-prob}

    ::: {.callout-warning}
    In the current implementation, the coefficient for $O_c$ is -3.0442, rather
    than -30.442 as in @cruz2013. This will be fixed in a future release.
    :::

    ### Usage

    ```python
    spread_probability = calc_spread_probability(
        wind_speed, fuel_moisture, overstorey_cover
    )
    ```

    ### Implementation Notes

    The overstory cover percentage $O_c$ is provided by the jurisdictions in
    the fuel parameters table for each sub fuel type.

    ### Parameters

    - **wind_speed** (*array-like*) - 10m wind speed (km/h)
    - **fuel_moisture** (*array-like*) - fuel moisture content (%)
    - **overstorey_cover** (*float*) - percent of over-storey cover (%)
    """
    # calculate the spread probability
    spread_probability = 1 / (
        1
        + np.exp(
            -(
                14.624
                + 0.2066 * wind_speed
                - 1.8719 * fuel_moisture
                - 3.0442 * (overstorey_cover / 100)
            )
        )
    )

    # TODO: the overstory_cover coefficient should be -30.442 as per @cruz2013
    # See https://gitlab.com/afdrs/afdrs-dev/packages/python-packages/fdrs_calcs/-/issues/25

    return spread_probability


def calc_crown_probability(wind_speed, fuel_moisture):
    r"""Predict the probability that the fire will spread to the crown

    ### Technical Guide

    In order to calculate the characteristics of the fire, knowing whether the
    fire will just affect the surface fuels or will spread to the crown is
    important. The best model for predicting active crowning in mallee heath was
    found by @cruz2013 to be based on the 10m wind speed $U_{10}$ and fuel
    moisture content $MC$:

    $$
    P_{crown} = \frac{1}{1 + e^{-(-11.138 + 1.4054 U_{10} - 3.4217 MC)}}
    $$ {#eq-mallee-crown-prob}

    ### Usage

    ```python
    crown_probability = calc_crown_probability(wind_speed, fuel_moisture)
    ```

    ### Parameters

    - **wind_speed** (*array-like*) - 10m wind speed (km/h)
    - **fuel_moisture** (*array-like*) - fuel moisture content (%)

    ### Returns

    - **crown_probability** (*array-like*) - probability of crown fire
    """
    # calculate the crown probability
    crown_probability = 1 / (
        1 + np.exp(-(-11.138 + 1.4054 * wind_speed - 3.4217 * fuel_moisture))
    )

    return crown_probability


def calc_rate_of_spread(
    wind_speed, fuel_moisture, overstorey_cover, overstorey_height
):
    r""" Calculate rate of spread in m/h. [Range = 0 - 8000].

    ### Technical Guide

    As in @cruz2013, the rate of spread in mallee heath is calculated as a
    combination of a surface model and a crown model, where the combination of
    models is chosen based on the probability of spread, and the probability of
    crown fire:

    $$
    ROS = \begin{cases}
    0 & \text{if } P_{spread} < 0.5 \\
    ROS_{surface} & \text{if } P_{spread} \geq 0.5 \text{ and } P_{crown} \leq
        0.01 \\
    ROS_{crown} & \text{if } P_{spread} \geq 0.5 \text{ and } P_{crown} \geq
        0.99 \\
    ROS_{ensemble} & \text{if } P_{spread} \geq 0.5 \text{ and } 0.01 <
        P_{crown} < 0.99
    \end{cases}
    $$ {#eq-mallee-ros}

    where $ROS_{surface}$ is the surface fire rate of spread, $ROS_{crown}$ is
    the crown fire rate of spread, and $ROS_{ensemble}$ is the weighted average
    of the two, calculated as follows:

    $$
    ROS_{ensemble} = (1 - P_{crown}) ROS_{surface} + P_{crown} ROS_{crown}
    $$ {#eq-mallee-ros-ensemble}

    The surface fire rate of spread is calculated as follows:

    $$
    ROS_{surface} = 3.337 U_{10} e^{-0.1284 MC} H^{-0.7073}
    $$ {#eq-mallee-ros-surface}

    where $U_{10}$ is the 10m wind speed (km/h), $MC$ is the fuel moisture
    content (%), and $H$ is the over-storey height (m).

    The crown fire rate of spread is calculated as follows:

    $$
    ROS_{crown} = 9.5751 U_{10} e^{-0.1795 MC} O_c^{0.3589}
    $$ {#eq-mallee-ros-crown}

    where $O_c$ is the percent of over-storey cover (%).

    ::: {.callout-warning}
    In the current implementation, this model does not ensure that the ROS stays
    at 0 when the spread probability is less than 0.5. This is because the
    choice of surface, crown or ensemble model is made only on the crown
    probability and the spread probability is ignored. This will be fixed in a
    future release.
    :::
        
    ### Implementation Details

    In @cruz2013, the rates of spread are calculated in m/min, but for AFDRS,
    the rates of spread are calculated in m/h, so all the rates of spread
    equations have been multiplied by 60.

    The overstory height $H$, and the overstory cover $O_c$ are provided by
    the jurisdictions in the fuel parameters table for each sub fuel type.

    ### Usage

    ```python
    rate_of_spread = calc_rate_of_spread(
        wind_speed, fuel_moisture, overstorey_cover, overstorey_height
    )
    ```

    ### Parameters

    - **wind_speed** (*array-like*) - 10m wind speed (km/h)
    - **fuel_moisture** (*array-like*) - fuel moisture content (%)
    - **overstorey_cover** (*float*) - percent of over-storey cover (%)
    - **overstorey_height** (*float*) - over-storey height (m)

    ### Returns

    - **rate_of_spread** (*array-like*) - rate of spread (m/h)
    """
    # calculate the probability of fire spread
    spread_probability = calc_spread_probability(
        wind_speed, fuel_moisture, overstorey_cover
    )

    # calculate the probability of crown fire
    crown_probability = calc_crown_probability(wind_speed, fuel_moisture)

    # setup rate of spread arrays as nan arrays the same shape as wind speed
    rate_of_spread = np.full(np.shape(wind_speed), np.nan)
    rate_of_spread_surface = np.full(np.shape(wind_speed), np.nan)
    rate_of_spread_crown = np.full(np.shape(wind_speed), np.nan)

    # calculate the surface model for all cells where crown probability is less
    # than 0.99
    surface_mask = crown_probability <= 0.99
    if surface_mask.any():

        # for experimental purposes, allow overstorey height to be an array.
        # This is not supported or tested and could be removed in future
        if np.ndim(overstorey_height) > 0:
            overstorey_height_masked = overstorey_height[surface_mask]
            # we should have no values below 0
            assert (overstorey_height_masked < 0).sum() == 0
        else:
            # overstorey_height is a scalar
            overstorey_height_masked = overstorey_height

        rate_of_spread_surface[surface_mask] = (
            60
            * 3.337
            * wind_speed[surface_mask]
            * np.exp(-0.1284 * fuel_moisture[surface_mask])
            * np.power(overstorey_height_masked, -0.7073)
        )

    # calculate the crown model for all cells where crown probability is greater
    # than 0.01
    crown_mask = crown_probability > 0.01
    if crown_mask.any():

        # for experimental purposes, allow overstorey cover to be an array. This
        # is not supported or tested and could be removed in future
        if np.ndim(overstorey_cover) > 0:
            overstorey_cover_masked = overstorey_cover[crown_mask]
            # we should have no values below 0
            assert (overstorey_cover_masked < 0).sum() == 0
        else:
            # overstory_cover is a scalar
            overstorey_cover_masked = overstorey_cover

        rate_of_spread_crown[crown_mask] = (
            60
            * 9.5751
            * wind_speed[crown_mask]
            * np.exp(-0.1795 * fuel_moisture[crown_mask])
            * np.power((overstorey_cover_masked / 100), 0.3589)
        )

        # TODO: Issue #13 indicates this should be 0.03589, not 0.3589
        # See https://gitlab.com/afdrs/afdrs-dev/packages/python-packages/fdrs_calcs/-/issues/13

    # only use the surface model for cells where crown probability is less than
    # 0.01
    surface_only_mask = crown_probability <= 0.01
    if surface_only_mask.any():
        rate_of_spread[surface_only_mask] = rate_of_spread_surface[
            surface_only_mask
        ]

    # only use the crown model for cells where crown probability is greater than
    # 0.99
    crown_only_mask = crown_probability > 0.99
    if crown_only_mask.any():
        rate_of_spread[crown_only_mask] = rate_of_spread_crown[crown_only_mask]

    # use the weighted average of the surface and crown models for cells where
    # crown probability is between 0.01 and 0.99
    ensemble_mask = (crown_probability > 0.01) & (crown_probability <= 0.99)
    if ensemble_mask.any():
        rate_of_spread[ensemble_mask] = (
            1 - crown_probability[ensemble_mask]
        ) * rate_of_spread_surface[ensemble_mask] + crown_probability[
            ensemble_mask
        ] * rate_of_spread_crown[
            ensemble_mask
        ]

    # TODO: at the moment this is completely ignoring the spread probability, so
    # doesn't match the behaviour described in the technical guide.
    # See https://gitlab.com/afdrs/afdrs-dev/packages/python-packages/fdrs_calcs/-/issues/20

    return rate_of_spread


def calc_fuel_load(
    wind_speed,
    time_since_fire,
    fuel_moisture,
    fuel_load_surface,
    fuel_load_canopy,
    k_surface,
    k_canopy,
):
    r"""Calculate fuel load (t/ha)

    ### Technical Guide

    Similar to calculating the rate of spread, the fuel load available for
    burning is calculated as a combination of a surface model and a crown model,
    where the combination of models is chosen based on the probability of the
    fire crowning:

    $$
    F = F_{surface} + \begin{cases}
    P_{crown} F_{crown} & \text{if } 0.01 < P_{crown} < 0.99 \\
    F_{crown} & \text{if } P_{crown} > 0.99 \\
    \end{cases}
    $$ {#eq-mallee-fuel-load}

    where $F_{surface}$ is the surface fuel load, and $F_{crown}$ is the crown
    fuel load, and $P_{crown}$ is the probability of the fire crowning.

    Both the surface and crown fuel loads are calculated based on the
    steady-state fuel loads and the time since fire using the accumulation
    curves from @olson1963:

    $$
    F = F_{ss} (1 - e^{-kt})
    $$ {#eq-mallee-fuel-load-accumulation}

    where $F_{ss}$ is the steady state fuel load (t/ha), $k$ is the accumulation
    rate, and $t$ is the time since fire (years).

    The steady state fuel loads and accumulation rates for both the surface and
    the crown are provided by the jurisdictions in the fuel parameters table for
    each sub fuel type.

    ### Implementation Details

    This function uses `common.calc_accumulation_since_fire` to calculate the
    accumulation since fire using @olson1963's accumulation curves.

    ### Usage

    ```python
    fuel_load = calc_fuel_load(
        wind_speed, time_since_fire, fuel_moisture,
        fuel_load_surface, fuel_load_canopy, k_surface, k_canopy
    )
    ```

    ### Parameters

    - **wind_speed** (*array-like*) - 10m wind speed (km/h)
    - **time_since_fire** (*array-like*) - time since fire (years)
    - **fuel_moisture** (*array-like*) - fuel moisture content (%)
    - **fuel_load_surface** (*float*) - steady state surface fuel load (t/ha)
    - **fuel_load_canopy** (*float*) - steady state crown fuel load (t/ha)
    - **k_surface** (*float*) - surface fuel accumulation rate (1/year)
    - **k_canopy** (*float*) - crown fuel accumulation rate (1/year)

    ### Returns

    - **fuel_load** (*array-like*) - fuel load (t/ha)
    """
    # calculate the probability of the fire crowning
    crown_probability = calc_crown_probability(wind_speed, fuel_moisture)

    # accumulate the surface fuel since the last fire
    adjusted_fuel_load_surface = common.calc_accumulation_since_fire(
        time_since_fire, fuel_load_surface, k_surface
    )

    # accumulate the crown fuel since the last fire
    adjusted_fuel_load_crown = common.calc_accumulation_since_fire(
        time_since_fire, fuel_load_canopy, k_canopy
    )

    # all cells include the surface fuel load
    fuel_load = adjusted_fuel_load_surface

    # add the crown fuel load in proportion to the probability of crown fire,
    # setting the proportion to 1 if it is over 0.99, and to 0 if it is below
    # or equal to 0.01
    crown_probability[crown_probability > 0.99] = 1.0
    crown_probability[crown_probability <= 0.01] = 0.0
    fuel_load += crown_probability * adjusted_fuel_load_crown

    return fuel_load


def calc_intensity(rate_of_spread, fuel_load):
    r"""Calculate mallee heath fireline intensity (kW/m)

    ### Technical Guide

    The fireline intensity is calculated using the @byram1959 equation:

    $$
    I = h \times F \times ROS
    $$ {#eq-mallee-intensity}

    where $h$ is the heat yied, assumed here to be 18,600 kJ/kg, $F$ is the fuel
    load in kg/m^2 and $ROS$ is the rate of spread in m/s.

    ### Implementation Details

    This function is just a light wrapper around the
    `common.calc_fire_intensity` function, which is used by multiple spread
    models.

    ### Usage

    ```python
    intensity = calc_intensity(rate_of_spread, fuel_load)
    ```

    ### Parameters

    - **rate_of_spread** (*array-like*) - rate of spread (m/h)
    - **fuel_load** (*array-like*) - fuel load (t/ha)

    ### Returns

    - **intensity** (*array-like*) - fireline intensity (kW/m)
    """
    return common.calc_fire_intensity(rate_of_spread, fuel_load, HEAT_CONTENT)


def calc_flame_height(intensity):
    r"""Calculate flame height in m

    ### Technical Guide

    The flame height (m) is calculated using the @cruz2013 equation:

    $$
    H = e^{-4.142} \times I^{0.633}
    $$ {#eq-mallee-flame-height}

    where $I$ is the fireline intensity in kW/m.

    ### Usage

    ```python
    flame_height = calc_flame_height(intensity)
    ```

    ### Parameters

    - **intensity** (*array-like*) - fireline intensity (kW/m)

    ### Returns

    - **flame_height** (*array-like*) - flame height (m)
    """
    return np.exp(-4.142) * np.power(intensity, 0.633)


def calc_spotting_distance(air_temperature):
    r"""
    Calculate spotting distance (m).

    ### Technical Guide

    A spotting model is not currently implemented for mallee heath.

    ### Implementation Details

    As a spotting function is not currently implemented for mallee heath, this
    function just returns an array of NaNs of the same shape as
    `air_temperature`.

    ### Usage

    ```python
    spotting_distance = calc_spotting_distance(air_temperature)
    ```

    ### Parameters

    - **air_temperature** (*array_like*) - air temperature (°C).

    ### Returns

    - **spotting_distance** (*array_like*) - spotting distance (m).
    """
    return np.full(air_temperature.shape, np.nan)


def calculate(
    dataset: MalleeHeathInputVariables,
    fuel_parameters: MalleeHeathFuelParameters,
) -> MalleeHeathOutputIndices:
    r"""
    Main entry point for mallee heath fire behaviour calculations.

    ### Usage

    ```python
    indices = calculate(dataset, fuel_parameters)
    ```

    ### Parameters

    - **dataset** (*dict*) - A dictionary of *array_like* containing the input
        variables.

        From these input variables, only the following are used by this model:

        - **T_SFC** - air temperature (°C)
        - **RH_SFC** - relative humidity (%)
        - **WindMagKmh_10m** : Wind magnitude at 10m (km/h)
        - **precipitation** - precipitation (mm) in the last 48 hours
        - **time_since_rain** - time since rain (hours)
        - **time_since_fire** - time since fire (years)
        - **months** - month of the year (1-12)
        - **hours** - hour of the day (0-23)

    - **fuel_parameters** A dictionary of scalars containing the fuel
      parameters.

        From these fuel parameters, only the following are used by this model:

        - **FL_s** - steady state surface fuel load (t/ha)
        - **FL_o** - steady state crown fuel load (t/ha)
        - **Fk_s** - surface fuel accumulation rate (1/year)
        - **Fk_o** - crown fuel accumulation rate (1/year)
        - **H_o** - over-storey height (m)
        - **Cov_o** - percent of over-storey cover (%)

    ### Returns

    - **indices** (*dict*) - A dictionary of *array_like* containing the
        output variables of the same shape as the input variables with the
        following keys:

        - **dead_fuel_moisture** - fuel moisture content (%)
        - **rate_of_spread** - rate of spread (m/h)
        - **crown_probability** - probability of crown fire
        - **spread_probability** - probability of fire spread
        - **flame_height** - flame height (m)
        - **intensity** - fireline intensity (kW/m)
        - **spotting_distance** - spotting distance (m)
        - **rating_1** - fire danger rating
        - **index_1** - fire behaviour index
    """
    # standardize the dataset variables
    dataset = standardize_dataset_variables(dataset)

    # calculate the fuel moisture
    fuel_moisture = calc_fuel_moisture(
        dataset["RH_SFC"],
        dataset["T_SFC"],
        (dataset["months"], dataset["hours"]),
        dataset["precipitation"],
        dataset["time_since_rain"],
    )

    # calculate the fuel load
    fuel_load = calc_fuel_load(
        dataset["WindMagKmh_10m"],
        dataset["time_since_fire"],
        fuel_moisture,
        fuel_parameters["FL_s"],
        fuel_parameters["FL_o"],
        fuel_parameters["Fk_s"],
        fuel_parameters["Fk_o"],
    )

    # calculate the spread probability
    spread_probability = calc_spread_probability(
        dataset["WindMagKmh_10m"], fuel_moisture, fuel_parameters["Cov_o"]
    )

    # calculate the crown probability
    crown_probability = calc_crown_probability(
        dataset["WindMagKmh_10m"], fuel_moisture
    )

    # calculate the rate of spread
    rate_of_spread = calc_rate_of_spread(
        dataset["WindMagKmh_10m"],
        fuel_moisture,
        fuel_parameters["Cov_o"],
        fuel_parameters["H_o"],
    )

    # calculate the intensity
    intensity = calc_intensity(rate_of_spread, fuel_load)

    # calculate the flame height
    flame_height = calc_flame_height(intensity)

    # calculate the spotting distance
    spotting_distance = calc_spotting_distance(dataset["T_SFC"])

    # calculate the fire danger rating and fire behaviour index
    index_1 = fire_behaviour_index.mallee_heath(
        spread_probability, crown_probability, intensity
    )
    rating_1 = fire_danger_rating.fire_danger_rating(index_1)

    return {
        "dead_fuel_moisture": fuel_moisture,
        "rate_of_spread": rate_of_spread,
        "crown_probability": crown_probability,
        "spread_probability": spread_probability,
        "flame_height": flame_height,
        "intensity": intensity,
        "spotting_distance": spotting_distance,
        "rating_1": rating_1,
        "index_1": index_1,
    }
