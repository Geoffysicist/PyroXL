
from pathlib import Path
import glob
import pandas as pd
import numpy as np


CWD = Path().absolute() / "fdrs_calcs"


products = pd.read_excel(CWD / 'Product_Identifiers.xlsx')[['Product', 'Variable Name', 'Variable Description', 'Variable', 'Units', 'Temporal Resolution', 'Product Code', 'Filename']]
products_md = products.to_markdown(index=False)
with open('products_list.md', 'w') as f:
    f.write(products_md)

variables = pd.read_excel(CWD / 'metadata_Identifiers.xlsx')
variables_md = variables.to_markdown(index=False)
with open('variables_list.md', 'w') as f:
    f.write(variables_md)


